<!--bottom-->
<div id="bottom">
	
<div style="float: left; width: 1000px; padding-top: 5px; text-align: center; padding: 15px 0;">
	<p><b><?php echo $display['copyright']; ?></b></p>
    <p><b><?php echo $display['info_com']; ?></b></p>
</div>
</div>
<!--end bottom-->