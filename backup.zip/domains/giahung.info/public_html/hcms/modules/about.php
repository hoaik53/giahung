<?php if (substr_count($_SERVER['PHP_SELF'],'/about.php')>0) die ("You can't access this file directly..."); ?>
<p class="topmenu" style="padding: 96 36 96 36">
<?php echo $strBCMS; ?>
</p>