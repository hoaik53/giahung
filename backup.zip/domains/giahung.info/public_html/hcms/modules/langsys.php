<div class="ui-widget-content">
    <h3 class="ui-widget-header"><?php echo $strChoicelang; ?></h3>
    <div class="ui-widget-body" style="text-align: center;">
    
        <div class="panel_item" onclick="window.location='?module=editlanglayout'">
            <img src="images/sheet.gif" />
            <h3><?=$strFontend?></h3>
        </div>
        <div class="panel_item" onclick="window.location='?module=editlang'">
            <img src="images/product_cat.gif" />
            <h3><?=$strBackend?></h3>
        </div>
    <div class="clear"></div>
    </div>
</div>
