<table width="100%" border="0" cellspacing="0" cellpadding="0">
	<tr>
		<td height="34" background="" style="background-color: #87B6D9;">
		<p align="center" class="topmenu" style="margin: 6px 0 0 0; color: #fff;"><?php echo $strCopyright; ?></p>
		</td>
	</tr>
</table>
